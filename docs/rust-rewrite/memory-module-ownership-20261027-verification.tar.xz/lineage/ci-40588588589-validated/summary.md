CI 40588588589: scored evidence admitted (68/68 attempts successful; 17 workloads).
Unscored ownership diagnostic: incomplete.

Present base pages; image/text views overlap and must not be summed.
| Case | Owner | Phase | Image | Text | Union |
|---|---|---|---:|---:|---:|
| scriptw/integer.js | program | after_transport_drop | 93 | 65 | 93 |
| scriptw/integer.js | program | after_instantiate | 93 | 65 | 93 |
| scriptw/integer.js | program | after_execution | 93 | 65 | 93 |
| scriptw/integer.js | program | after_store_drop | 93 | 65 | 93 |
| scriptw/integer.js | runtime | after_transport_drop | 82 | 15 | 82 |
| scriptw/integer.js | runtime | after_instantiate | 721 | 510 | 721 |
| scriptw/integer.js | runtime | after_execution | 721 | 510 | 721 |
| scriptw/integer.js | runtime | after_store_drop | 721 | 510 | 721 |
| scriptc/integer.js | program | after_transport_drop | 231 | 172 | 231 |
| scriptc/integer.js | program | after_instantiate | 231 | 172 | 231 |
| scriptc/integer.js | program | after_execution | 231 | 172 | 231 |
| scriptc/integer.js | program | after_store_drop | 231 | 172 | 231 |
| scriptw/retained-objects.js | program | after_transport_drop | 105 | 75 | 105 |
| scriptw/retained-objects.js | program | after_instantiate | 105 | 75 | 105 |
| scriptw/retained-objects.js | program | after_execution | 105 | 75 | 105 |
| scriptw/retained-objects.js | program | after_store_drop | 105 | 75 | 105 |
| scriptw/retained-objects.js | runtime | after_transport_drop | 82 | 15 | 82 |
| scriptw/retained-objects.js | runtime | after_instantiate | 1025 | 622 | 1025 |
| scriptw/retained-objects.js | runtime | after_execution | 1025 | 622 | 1025 |
| scriptw/retained-objects.js | runtime | after_store_drop | 1025 | 622 | 1025 |
| scriptc/retained-objects.js | program | after_transport_drop | 389 | 297 | 389 |
| scriptc/retained-objects.js | program | after_instantiate | 389 | 297 | 389 |
| scriptc/retained-objects.js | program | after_execution | 389 | 297 | 389 |
| scriptc/retained-objects.js | program | after_store_drop | 389 | 297 | 389 |

| Case | Phase | Host RX present pages |
|---|---|---:|

Transport drop is cold relative to the run loop. Other snapshots select observation16 after16 prior executions; last-sample growth cannot isolate or exclude Realm bootstrap.
Host function/page overlaps are nonexclusive and do not establish execution. No native executable or image was loaded, retained, or executed by this processor.
Unavailable/incomplete diagnostics supply no ownership conclusion and do not invalidate the scored cohort.
