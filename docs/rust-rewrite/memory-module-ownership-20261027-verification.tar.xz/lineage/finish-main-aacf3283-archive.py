"""Private archive-only completion of the source-pinned ownership ladder.

Prepare/review before running under CPU 0, <=1 GiB, no swap, grouped OOM.
This script never builds, runs tests, reads native payloads, or rewrites a
predecessor receipt. It admits the stopped command checkpoint, then archives
its inert evidence with narrowly bounded large Cargo JSONL streams.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = 'aacf3283ca1fd0b2dd47e7bd1aea6230bf140a1a'
STOP = BASE / 'verify-main-aacf3283-continuation'
STOP_SHA = '187daeaa1410b6e0be0c9e9de74a34040ce9743ef2c21b208ae3d3d31d0e8354'
PREFIX_SHA = '6d1d8684f4fe5589c8ba08bf197f4cda7b2c736e46cef81ac66ed2c719877746'
DRIVER_SHA = '5633ff219d4191a52b162adb60d01c47bb3747ed06ef3537617a15c61271f2d6'
REVIEW_SHA = '32cb6be6f7d8e0742a0355568b296135741962032b9b2843eea08cf2e0289f81'
LAUNCH_SHA = '3a2de553a0d3ab9a2a17e006142b19d36a4c789eff509ba8dd4036bf30eda869'
JOURNAL_SHA = '7641c3e047a1c5d18797b5d110cf70c9235d8f75b5ee934a27840a5ce498f0db'
COMPARISON_SHA = '58de0e69a5ee8748676861f13eb303e83dc8fa2c9be991cdcbf8d8afb9b416a3'
PROVENANCE_SHA = 'ad162d4ac6fb1dd129d9738ea8a504b91f7f7d65aa3d536d86e6c135f1d71746'
LARGE_STREAMS = {
    'inherited-prefix/default-workspace-check.stdout': 58717872,
    'default-example-build.stdout': 39177890,
    'enabled-controls-build.stdout': 39188014,
    'enabled-shared-host-build.stdout': 39177144,
}
LABELS = ['default-engine-doctests', 'default-example-build',
          'default-runtime_precompiled-inventory', 'default-runtime_precompiled-all',
          'default-compiler_precompiled_baseline-inventory', 'default-compiler_precompiled_baseline-all',
          'enabled-controls-build', 'enabled-engine-inventory', 'enabled-engine-positive',
          'enabled-runtime_precompiled-inventory', 'enabled-runtime_precompiled-all',
          'enabled-compiler_precompiled_baseline-inventory', 'enabled-compiler_precompiled_baseline-all',
          'enabled-shared-host-build']
POSITIVE = 'embedding::tests::benchmark_module_images::diagnostic_images_match_actual_program_runtime_and_survive_store_drop'
EXPECTED_NATIVE = {'Portable': '4dac02b8875bdaa6fba2938ed33dfa0142512bc7c515a390efc89bf13b6e1c71',
                   'NativeHost': 'cb39ffe5749d957b0cb2fc4bf72f0fe92ac9ee4b44e07a5199d3729736ddf3ff'}
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group
from native_test_protocol import parse_inventory, result_summaries


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path, cap=4 * 1024**2):
    path = Path(path)
    assert stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink() and path.stat().st_size <= cap
    return json.loads(path.read_text())


def resources(group):
    return {key: (group / key).read_text().strip() for key in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


def no_oom(before, after):
    for sample in (before, after):
        assert sample['memory.swap.max'] == '0' and sample['memory.oom.group'] == '1'
    counters = [dict(line.split() for line in value['memory.events'].splitlines()) for value in (before, after)]
    assert all(counters[0][key] == counters[1][key] == '0' for key in ('oom', 'oom_kill', 'oom_group_kill'))


def streams(directory, commands):
    for row in commands:
        assert row['exit_code'] == 0
        for channel in ('stdout', 'stderr'):
            assert row[channel] == row['label'] + '.' + channel
            path = directory / row[channel]
            assert path.stat().st_size <= 64 * 1024**2 and sha(path) == row[channel + '_sha256']


def cargo_rows(path):
    """Stream the large Cargo JSONL; retain only producer rows needed here."""
    retained, finished = [], []
    with path.open() as stream:
        for line in stream:
            assert len(line) <= 16 * 1024**2
            row = json.loads(line)
            if row.get('reason') in ('build-finished', 'build-script-executed', 'compiler-artifact'):
                if row.get('reason') == 'build-finished':
                    finished.append(row)
                elif row.get('reason') == 'build-script-executed' or row.get('executable'):
                    retained.append(row)
    assert finished == [dict(reason='build-finished', success=True)]
    return retained


def admit():
    assert sha(STOP / 'report.json') == STOP_SHA
    assert sha(BASE / 'continue-main-aacf3283.py') == DRIVER_SHA
    assert sha(BASE / 'continue-main-aacf3283-review.json') == REVIEW_SHA
    assert sha(BASE / 'main-aacf3283-continuation-launch.json') == LAUNCH_SHA
    review = read(BASE / 'continue-main-aacf3283-review.json')
    assert review['sha256'] == '207a3984d939fbd8c7c6183c59ac6766aae27b480d407f61b4be43eca695df00'
    assert review['reviewed'] is True
    launch = read(BASE / 'main-aacf3283-continuation-launch.json')
    assert launch['unit'] == 'scriptw-module-ownership-continuation-20261028.service' and launch['exit_code'] == 0
    journal = BASE / 'main-aacf3283-continuation-journal.stdout'
    assert sha(journal) == JOURNAL_SHA
    text = journal.read_text()
    assert 'line 312, in inert_archive' in text and 'assert path.stat().st_size <= 32 * 1024**2' in text
    assert 'status=1/FAILURE' in text
    stopped = read(STOP / 'report.json')
    assert stopped['source_commit'] == SOURCE and stopped['complete'] is False
    assert stopped['remaining_ladder_completed_before_archive'] is True and stopped['error_type'] == 'AssertionError'
    assert stopped['error'] == 'AssertionError()' and stopped['cpu_affinity'] == [0]
    assert stopped['before']['memory.max'] == stopped['after']['memory.max'] == '4294967296'
    no_oom(stopped['before'], stopped['after'])
    assert [row['label'] for row in stopped['commands']] == LABELS
    streams(STOP, stopped['commands'])
    origin = STOP / 'inherited-prefix'
    assert sha(origin / 'report.json') == PREFIX_SHA
    prefix = read(origin / 'report.json')
    assert prefix['complete'] is False and 'after' not in prefix and prefix['source_commit'] == SOURCE
    assert len(prefix['commands']) == stopped['original_prefix']['completed_commands'] == 9
    assert stopped['original_prefix']['parent_exit_code'] == 1
    assert stopped['original_prefix']['resource_after_available'] is False
    streams(origin, prefix['commands'])
    python = (origin / 'python63.stdout').read_text() + (origin / 'python63.stderr').read_text()
    assert re.findall(r'Ran (\d+) tests?', python) == ['63'] and re.search(r'^OK$', python, re.M)
    doc = (STOP / 'default-engine-doctests.stdout').read_text()
    assert re.search(r'^test .*embedding\.rs - embedding::EmbeddedRuntime .*compile fail \.\.\. ok$', doc, re.M)
    assert stopped['default_api_absence_compile_fail_executed'] is True
    logs = {'default': cargo_rows(STOP / 'default-example-build.stdout'),
            'enabled': cargo_rows(STOP / 'enabled-controls-build.stdout')}
    scopes = stopped['native_scopes']
    assert [row['label'] for row in scopes] == ['default-runtime_precompiled', 'default-compiler_precompiled_baseline',
        'enabled-engine', 'enabled-runtime_precompiled', 'enabled-compiler_precompiled_baseline']
    for scope in scopes:
        label = scope['label']
        inventory = parse_inventory((STOP / (label + '-inventory.stdout')).read_text())
        assert inventory == scope['inventory'] and inventory
        enabled = label.startswith('enabled-')
        producer = scope['cargo_producer']
        assert logs['enabled' if enabled else 'default'].count(producer) == 1
        assert producer['profile']['test'] is True
        assert producer['features'] == (['benchmark-module-images'] if enabled else [])
        execution = scope['executed']
        assert execution and len(set(execution)) == len(execution)
        assert set(execution) <= set(inventory)
        result = (STOP / (label + ('-positive.stdout' if label == 'enabled-engine' else '-all.stdout'))).read_text()
        assert re.findall(r'^test ([^\r\n]+) \.\.\. ok$', result, re.M) == execution
        assert result_summaries(result) == [('ok', str(len(execution)), '0', '0', '0', str(len(inventory)-len(execution)))]
        assert execution == ([POSITIVE] if label == 'enabled-engine' else inventory)
    for name in ('runtime_precompiled', 'compiler_precompiled_baseline'):
        default = next(row for row in scopes if row['label'] == 'default-' + name)
        enabled = next(row for row in scopes if row['label'] == 'enabled-' + name)
        assert set(default['inventory']) <= set(enabled['inventory'])
    proof = stopped['runtime_bytes_proof']
    assert set(proof) == {'default', 'enabled'}
    assert sha(STOP / 'admission/comparison.json') == COMPARISON_SHA
    assert sha(STOP / 'admission/native-identity-provenance.json') == PROVENANCE_SHA
    product_rows = cargo_rows(STOP / 'enabled-shared-host-build.stdout')
    default_rows = cargo_rows(origin / 'default-workspace-check.stdout')
    for label, rows in [('default', default_rows), ('enabled', product_rows)]:
        assert rows.count(proof[label]['cargo_producer']) == 1
        for mode, variant in proof[label]['variants'].items():
            assert mode in EXPECTED_NATIVE and variant['native_sha256'] == EXPECTED_NATIVE[mode]
            assert sha(STOP / variant['manifest']) == variant['manifest_sha256']
            admission = variant['native_stamp_admission']
            assert admission['current_native_sha256'] == EXPECTED_NATIVE[mode]
            assert admission['comparison_sha256'] == COMPARISON_SHA and admission['source_provenance_sha256'] == PROVENANCE_SHA
            assert admission['native_code_and_all_other_bytes_identical'] is True
            assert admission['current_engine']['version_offset'] == 66 and admission['current_engine']['version_bytes'] == 82
            other = proof['default']['variants'][mode]
            assert all(variant[key] == other[key] for key in ('wasm_sha256', 'native_sha256', 'package_sha256',
                'manifest_sha256', 'runtime_key', 'historical_header_reconstruction_sha256', 'native_stamp_admission'))
    assert product_rows.count(stopped['shared_host_product']['cargo_producer']) == 1
    assert stopped['test262_rerun'] is False and stopped['predecessor']['pinned_unique_executions'] == 6307
    return stopped


def build_archive(out):
    files, excluded = [], []
    paths = [(p.relative_to(STOP).as_posix(), p) for p in sorted(STOP.rglob('*')) if p.is_file()]
    paths += [('archive-only-driver.py', Path(__file__).resolve()),
              ('continuation-journal.stdout', BASE / 'main-aacf3283-continuation-journal.stdout'),
              ('continuation-driver-retained.py', BASE / 'continue-main-aacf3283.py'),
              ('continuation-driver-review.json', BASE / 'continue-main-aacf3283-review.json'),
              ('continuation-launch.json', BASE / 'main-aacf3283-continuation-launch.json')]
    for name, path in paths:
        assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
        with path.open('rb') as stream:
            magic = stream.read(8)
        if magic.startswith((b'\x7fELF', b'MZ', b'SWRTZ001', b'SCRWRB', b'SCRWEP', b'SCRWWA')):
            excluded.append(dict(path=name, bytes=path.stat().st_size, reason='native-or-packed-runtime-payload'))
            continue
        assert path.suffix in ('.json', '.stdout', '.stderr', '.py', '.rs', '.bin')
        cap = 64 * 1024**2 if name in LARGE_STREAMS else 32 * 1024**2
        assert path.stat().st_size <= cap
        if name in LARGE_STREAMS:
            assert path.stat().st_size == LARGE_STREAMS[name]
        if path.suffix == '.bin':
            assert magic == b'SCRWNR01' and path.stat().st_size <= 4096
        files.append(dict(path=name, source=path, bytes=path.stat().st_size, sha256=sha(path)))
    expanded = sum(row['bytes'] for row in files)
    assert expanded <= 320 * 1024**2 and len(files) <= 1024
    assert set(LARGE_STREAMS) <= {row['path'] for row in files}
    archive = out / 'inert-evidence.tar.xz'
    with archive.open('xb') as raw, lzma.LZMAFile(raw, 'w', filters=[dict(id=lzma.FILTER_LZMA2, preset=1, dict_size=16*1024**2)]) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as bundle:
            for row in files:
                member = tarfile.TarInfo(row['path']); member.size = row['bytes']; member.mode = 0o644
                with row['source'].open('rb') as payload:
                    bundle.addfile(member, payload)
    assert archive.stat().st_size <= 64 * 1024**2
    expected, seen, total = {row['path']: row for row in files}, set(), 0
    with tarfile.open(archive, 'r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name in expected and member.name not in seen
            row = expected[member.name]
            assert member.size == row['bytes']
            total += member.size
            assert total <= 320 * 1024**2
            with bundle.extractfile(member) as payload:
                assert hashlib.file_digest(payload, 'sha256').hexdigest() == row['sha256']
            seen.add(member.name)
    assert seen == set(expected) and total == expanded
    return dict(path=archive.name, sha256=sha(archive), bytes=archive.stat().st_size, expanded_bytes=expanded,
        members=[{k:v for k,v in row.items() if k != 'source'} for row in files], excluded_payloads=excluded,
        native_payloads_retained=False, roundtrip_hashes_verified=True, roundtrip_passes=1,
        maximum_member_bytes=64*1024**2, exceptional_large_streams=LARGE_STREAMS)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert args.expected_source == SOURCE
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0)) == [0]
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT)
    out = args.output.resolve()
    assert out.parent == BASE and not out.exists()
    group = kernel_group()
    before = resources(group)
    receipt = dict(schema='scriptw-module-ownership-archive-only-completion-v1', complete=False,
        source_commit=SOURCE, started_at=datetime.now(timezone.utc).isoformat(), cpu_affinity=[0], before=before,
        scope='Only inert command checkpoint admission and archive processing. No build, test, or native payload inspection.',
        driver_sha256=sha(Path(__file__)))
    out.mkdir()
    try:
        stopped = admit()
        receipt.update(original_prefix=stopped['original_prefix'], stopped_continuation=dict(
            report_sha256=STOP_SHA, complete=False, parent_exit_code=1, parent_exit_origin='systemd journal',
            journal_sha256=JOURNAL_SHA, resource_after_available=True, failure='32 MiB inert archive member cap',
            remaining_commands_passed=14), native_scopes=stopped['native_scopes'],
            original_completed_commands=9, remaining_completed_commands=14, runtime_bytes_proof=stopped['runtime_bytes_proof'],
            continuation_driver_provenance=dict(reviewed_sha256='207a3984d939fbd8c7c6183c59ac6766aae27b480d407f61b4be43eca695df00',
                current_retained_sha256=DRIVER_SHA, executed_driver_sha256=None,
                file_stat_observations={name:dict(bytes=(BASE / name).stat().st_size,
                    mtime_utc=datetime.fromtimestamp((BASE / name).stat().st_mtime, timezone.utc).isoformat(),
                    ctime_utc=datetime.fromtimestamp((BASE / name).stat().st_ctime, timezone.utc).isoformat())
                    for name in ('continue-main-aacf3283.py', 'continue-main-aacf3283-review.json', 'main-aacf3283-continuation-launch.json')},
                review_receipt_sha256=REVIEW_SHA, launch_receipt_sha256=LAUNCH_SHA,
                interpretation='The retained driver changed after the review receipt and before launch according to filesystem timestamps. Launch records its path and arguments but no digest. The exact bytes loaded by the prior interpreter are unrecorded; this receipt independently admits pinned command reports, raw streams, inventories and byte-proof receipts. The retained current driver is a reference, not a claim about exact executed bytes.'),
            predecessor=stopped['predecessor'], runtime_stamp_admission=stopped['runtime_stamp_admission'],
            actual_wasm_bytes_unchanged=True, serialized_native_bytes_unchanged=False,
            native_bytes_unchanged_except_exact_compatibility_stamp=True, default_enabled_native_bytes_identical=True,
            test262_rerun=False, inherited_pinned_unique_executions=6307,
            interpretation='Original prefix remains incomplete with no resource after; stopped continuation remains incomplete with archive-only failure and explicit after. All 23 original/remaining commands are admitted from pinned reports and rehashed streams; five actual native inventories/results and both runtime proofs are admitted without rerunning. Verified900 JS executions are inherited through the exact Wasm/package and narrowly pinned native stamp-only byte proof. This fresh before/after covers archive-only processing.')
        receipt['archive'] = build_archive(out)
        after = resources(group)
        no_oom(before, after)
        assert sha(STOP / 'report.json') == STOP_SHA
        receipt.update(complete=True, after=after, finished_at=datetime.now(timezone.utc).isoformat())
    except Exception as error:
        receipt.update(error=repr(error), error_type=type(error).__name__, after=resources(group),
                       finished_at=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        (out / 'report.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(complete=True, output=str(out), archive_sha256=receipt['archive']['sha256'])))


if __name__ == '__main__':
    main()
