from pathlib import Path
import subprocess,json,shutil,hashlib
root=Path.cwd();out=root/'target/performance-entry-bootstrap';folder=out/'product-semantics';folder.mkdir();fixture=root/'crates/scriptw-cli/tests/fixtures/wasm_runtime_key_prehash.js';records=[]
def run(label,argv):
 with (folder/(label+'.stdout')).open('wb') as stdout,(folder/(label+'.stderr')).open('wb') as stderr:r=subprocess.run(list(map(str,argv)),cwd=root,stdout=stdout,stderr=stderr,timeout=600)
 row=dict(label=label,argv=list(map(str,argv)),exit_code=r.returncode);records.append(row);(folder/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,row
run('cli',[out/'candidate/scriptw','--jobs','1','run',fixture]);assert 'boolean(true)' in (folder/'cli.stdout').read_text()
sources=folder/'sources';sources.mkdir();shutil.copy2(fixture,sources/fixture.name);(sources/'manifest.json').write_text(json.dumps(dict(execution=[dict(file=fixture.name,stdout='')])))
artifacts=folder/'artifacts';artifacts.mkdir();run('portable',[out/'candidate/runtime_baseline',sources,'7','10',fixture.name,artifacts]);report=json.loads((folder/'portable.stdout').read_text());rows=report['cases'][0]['observations'];assert len(rows)==17 and all(r['stdout']=='' for r in rows);assert all(r['module_loading']['runtime_cache']=='Hit' for r in rows if not r['warmup']);assert all(r['module_retention']['entries']<=1 and r['module_retention']['image_bytes']<=67108864 for r in rows)
(folder/'cache-proof.json').write_text(json.dumps(dict(scope='unscored exact semantic fixture',source_fingerprint=report['source_fingerprint'],source_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),observations=[dict(warmup=r['warmup'],runtime_cache=r['module_loading']['runtime_cache'],module_retention=r['module_retention'],module_loading=r['module_loading'],execution_ns=r['execution_ns']) for r in rows]),indent=2)+'\n')
run('no-interpreter',['sh','scripts/check-no-interpreter-in-product-graph.sh']);print('frozen CLI boolean(true), Portable normal exact-output, actual retained-R hits and product graph passed',flush=True)
