"""Read-only raw audit; run under limited_verification after cohorts finish.

Adapted from performance-scalar-regions-entry-gate/independent-audit.py.
No benchmark invocation, build, statistical exclusion, or acceptance override.
"""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
CORPUS = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
BASELINE_FP = 'ce4d1397299c945cffdc9ec80de0cb96c146fc4d7e83e63d24c437de6fea764b'
BASELINE_HOST = '7d88201ade1af7dcd6cb9878d38708ef3d7a4bbbe1af97ea95438dab410c6a31'
BASELINE_COMMIT = '39b6f24ac1eb01e0a1cd59907699810b81cf8900'
SCHEDULES = {
    'block0': ['baseline', 'candidate', 'candidate', 'baseline',
               'candidate', 'baseline', 'baseline', 'candidate'],
    'block1': ['candidate', 'baseline', 'baseline', 'candidate',
               'baseline', 'candidate', 'candidate', 'baseline'],
}
MEMORY, IMAGE_LIMIT = 4294967296, 67108864
HASHED = {}
P_IDENTITIES = collections.defaultdict(set)
P_CODE = {}
MAX_RSS = 0
MAX_DISCREPANCY = 0.0


def load(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(path):
    path = Path(path).resolve()
    if path not in HASHED:
        with path.open('rb') as stream:
            HASHED[path] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return HASHED[path]


def close(actual, reported):
    global MAX_DISCREPANCY
    assert math.isfinite(actual) and math.isfinite(reported)
    discrepancy = abs(actual - reported)
    MAX_DISCREPANCY = max(MAX_DISCREPANCY, discrepancy)
    assert discrepancy <= 1e-7, (actual, reported, discrepancy)


def uleb(data, position):
    value = shift = 0
    while True:
        byte = data[position]
        position += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, position
        shift += 7
        assert shift < 64


def wasm_code(data):
    assert data[:8] == b'\0asm\x01\0\0\0'
    position = 8
    result = (0, 0, 0, b'')
    found = False
    while position < len(data):
        kind = data[position]
        length, position = uleb(data, position + 1)
        end = position + length
        assert end <= len(data)
        if kind == 10:
            assert not found
            found = True
            code = data[position:end]
            count, position = uleb(data, position)
            sizes = []
            for _ in range(count):
                size, position = uleb(data, position)
                sizes.append(size)
                position += size
                assert position <= end
            assert position == end
            result = (count, sum(sizes), max(sizes, default=0), code)
        position = end
    assert position == len(data)
    return result


def corpus():
    record = load(BASE / 'corpus.json')
    assert file_hash(CORPUS / 'manifest.json') == record['manifest_sha256']
    assert load(CORPUS / 'manifest.json') == record['manifest']
    for name, expected in record['files_sha256'].items():
        assert file_hash(CORPUS / name) == expected
    cases = record['manifest']['execution']
    assert len(cases) == 17 and len({row['file'] for row in cases}) == 17
    return record, cases


def products():
    result = {}
    for label in ['baseline', 'baseline-aa', 'candidate']:
        directory = BASE / label
        identity = load(directory / 'identity.json')
        hosts = load(directory / 'host-products.json')
        original = load(directory / 'products.json')
        for name, row in hosts.items():
            path = directory / name
            assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            assert path.stat().st_size == row['bytes']
            assert file_hash(path) == row['sha256'] == original[name]['sha256']
        assert identity['executable_sha256'] == hosts['compiler_precompiled_baseline']['sha256']
        if label != 'candidate':
            assert identity['source_fingerprint'] == BASELINE_FP
            assert identity['source_commit'] == BASELINE_COMMIT
            assert hosts['runtime_baseline']['sha256'] == BASELINE_HOST
        result[label] = dict(identity=identity, hosts=hosts)
    source = load(BASE / 'candidate/source.json')
    assert source['head'] == result['candidate']['identity']['source_commit']
    assert source['fingerprint'] == result['candidate']['identity']['source_fingerprint']
    assert source['patch_sha256'] == file_hash(BASE / 'candidate/source.patch')
    # These hashes bind the build inputs, not the later checkout state.
    built = load(BASE / 'pre-build-sources.json')
    frozen = load(BASE / 'candidate/source-files.json')
    assert all(frozen.get(name) == expected for name, expected in built.items())
    return result


def runtimes(product_records):
    delta = load(BASE / 'runtime-profile-delta.json')
    result = {}
    old = ROOT / 'target/performance-scalar-regions-entry-gate/candidate/runtime-build'
    new = BASE / 'candidate/runtime-build'
    for label, directory in [('baseline', old), ('candidate', new)]:
        profiles = {}
        for suffix in ['', '-portable']:
            name = f'scriptw-runtime{suffix}-package.bin'
            package = (directory / name).read_bytes()
            assert package[:8] == b'SCRWRB01'
            assert struct.unpack_from('<I', package, 8)[0] == 42
            assert package[12:44].hex() == product_records[label]['identity']['source_fingerprint']
            wasm = package[136:-32]
            assert len(wasm) == struct.unpack_from('<Q', package, 128)[0]
            assert digest(package[:-32]) == package[-32:].hex()
            record = delta[name]
            prefix = '' if label == 'candidate' else 'previous_'
            assert len(wasm) == record[prefix + 'runtime_wasm_bytes']
            assert digest(wasm) == record[prefix + 'runtime_wasm_sha256']
            native_name = f'scriptw-runtime{suffix}-native.bin'
            native = directory / native_name
            native_record = delta[native_name]
            assert native.stat().st_size == native_record[prefix + 'bytes']
            assert file_hash(native) == native_record[prefix + 'sha256']
            profiles[suffix or 'native'] = dict(runtime_key=package[76:108].hex(),
                wasm_sha256=digest(wasm), wasm_bytes=len(wasm),
                native_sha256=file_hash(native), native_bytes=native.stat().st_size, abi=42)
        result[label] = profiles
    for suffix in ['', '-portable']:
        key = suffix or 'native'
        assert delta[f'scriptw-runtime{suffix}-package.bin']['runtime_wasm_identical'] == (
            result['baseline'][key]['wasm_sha256'] == result['candidate'][key]['wasm_sha256'])
        assert delta[f'scriptw-runtime{suffix}-native.bin']['native_identical'] == (
            result['baseline'][key]['native_sha256'] == result['candidate'][key]['native_sha256'])
    result['baseline-aa'] = result['baseline']
    return result


def test_correction(product_records):
    directory = BASE / 'test-correction'
    if not (directory / 'correction.json').exists():
        return None
    metadata = load(directory / 'independent-correction-metadata.json')
    correction = load(directory / 'correction.json')
    changed = metadata['changed_path']
    assert changed == 'crates/scriptw-aot-wasm/src/tests/runtime_error_for_throw.rs'
    before = (directory / 'original-runtime_error_for_throw.rs').read_bytes()
    after = (directory / 'independent-corrected-runtime_error_for_throw.rs').read_bytes()
    assert digest(before) == metadata['original_test_sha256'] == correction['original_test_sha256']
    assert digest(after) == metadata['corrected_test_sha256'] == correction['corrected_test_sha256']
    old, new = metadata['exact_old_line'].encode(), metadata['exact_new_line'].encode()
    assert before.count(old) == 1 and before.replace(old, new, 1) == after
    assert load(BASE / 'pre-build-sources.json')[changed] == digest(before)
    assert load(BASE / 'candidate/source-files.json')[changed] == digest(before)
    other_inputs = {name: value for name, value in load(BASE / 'pre-build-sources.json').items() if name != changed}
    assert metadata['other_recorded_build_inputs_unchanged_at_correction'] == other_inputs
    assert metadata['frozen_product_source_fingerprint'] == product_records['candidate']['identity']['source_fingerprint']
    for name, row in metadata['files'].items():
        path = directory / name
        assert path.stat().st_size == row['bytes'] and file_hash(path) == row['sha256']
    assert file_hash(directory / 'test-only.patch') == metadata['root_correction_patch_sha256']
    exclusion = metadata['fingerprint_exclusion']
    registry = ROOT / exclusion['registry']
    assert file_hash(registry) == exclusion['registry_sha256']
    test_only = registry.read_text().split('const TEST_ONLY_INPUTS: &[&str] = &[', 1)[1].split('];', 1)[0]
    assert '"' + exclusion['excluded_prefix'] + '"' in test_only
    assert Path(changed).is_relative_to(exclusion['excluded_prefix'])
    native = load(directory / 'independent-original-native-receipt.json')
    failures = [row for row in native if row['exit_code'] != 0]
    assert len(failures) == 1 and failures[0]['summaries'] == [['FAILED', '578', '1', '0', '0', '0']]
    assert failures[0]['executable_sha256'] == correction['original_binary_sha256']
    assert file_hash(directory / 'original-backend-tests') == correction['original_binary_sha256']
    assert correction['failed_test'] in failures[0]['selected_inventory']
    return dict(metadata=metadata, source_chain_verified=True,
        original_failure_and_binary_preserved=True,
        corrected_test_execution='Not inferred by this performance audit; see separate corrected-binary native receipt.')


def resource_check(command):
    global MAX_RSS
    assert command['exit_code'] == 0 and command['timed_out'] is False
    assert command['affinity'] == [0]
    assert 0 < command['peak_rss_bytes'] <= MEMORY
    MAX_RSS = max(MAX_RSS, command['peak_rss_bytes'])
    before, after = command['resources_before'], command['resources_after']
    for snapshot in [before, after]:
        assert snapshot['memory.max'].strip() == str(MEMORY)
        assert snapshot['memory.swap.max'].strip() == '0'
        assert snapshot['memory.oom.group'].strip() == '1'
        events = dict(line.split() for line in snapshot['memory.events'].splitlines())
        assert all(int(value) == 0 for value in events.values()), events
    assert before == after, 'resource policy or memory events changed'


def verify_identity(report, label, records, host):
    expected = records[label]
    identity = expected['identity']
    assert report['source_commit'] == identity['source_commit']
    assert report['source_fingerprint'] == identity['source_fingerprint']
    assert report['executable_sha256'] == expected['hosts'][host]['sha256']


def observations(report, expected_stdout, cp=False):
    obs = report['observations']
    assert len(obs) == 31
    assert [row['warmup'] for row in obs] == [True] * 10 + [False] * 21
    assert all(row['stdout'] == expected_stdout for row in obs)
    timings = [row['phases_ns']['execution'] if cp else row['execution_ns'] for row in obs]
    assert all(type(value) is int and value > 0 for value in timings)
    values = timings[10:]
    return dict(times=values, median=statistics.median(values), mean=statistics.mean(values))


def compare(analysis, groups, cases, aa, cp, targets):
    results, vetoes, targets_failed, any_blocks, repeated_all = [], [], [], [], []
    assert len(analysis['comparisons']) == 17
    indexed = {row['case']: row for row in analysis['comparisons']}
    assert set(indexed) == {row['file'] for row in cases}
    other = 'baseline-aa' if aa else 'candidate'
    for case in cases:
        name = case['file']
        recorded = indexed[name]
        control = cp or name not in targets
        if not cp:
            assert recorded['control'] == control
        blocks = []
        assert [row['block'] for row in recorded['blocks']] == list(SCHEDULES)
        for block in recorded['blocks']:
            block_name = block['block']
            stats = {}
            for product in ['baseline', other]:
                rows = groups[(name, block_name, product)]
                assert len(rows) == 4
                pooled = [value for row in rows for value in row['times']]
                actual = [statistics.median(row['median'] for row in rows),
                          statistics.mean(row['mean'] for row in rows),
                          statistics.median(pooled), statistics.mean(pooled)]
                published = block['products'][product]
                fields = ['block_median_ns', 'block_mean_ns'] if cp else [
                    'block_median_of_invocation_medians_ns', 'block_mean_of_invocation_means_ns',
                    'pooled_sample_median_ns', 'pooled_sample_mean_ns']
                for field, value in zip(fields, actual):
                    close(value, published[field])
                if not cp:
                    assert published['invocation_count'] == 4 and published['sample_count'] == 84
                refs = {row['raw']: row for row in published['invocations']}
                assert set(refs) == {row['raw'] for row in rows}
                for row in rows:
                    close(row['median'], refs[row['raw']]['median_ns'])
                    close(row['mean'], refs[row['raw']]['mean_ns'])
                    assert row['process_elapsed_ns'] == refs[row['raw']]['process_elapsed_ns']
                stats[product] = actual
            changes = [100 * (b / a - 1) for a, b in zip(stats['baseline'], stats[other])]
            fields = ['median_percent', 'mean_percent'] if cp else [
                'block_median_of_invocation_medians_percent', 'block_mean_of_invocation_means_percent',
                'pooled_sample_median_percent', 'pooled_sample_mean_percent']
            for field, value in zip(fields, changes):
                close(value, block['change_percent'][field])
            blocks.append(dict(block=block_name, process_median_percent=changes[0],
                process_mean_percent=changes[1], pooled_median_percent=changes[2],
                pooled_mean_percent=changes[3], absolute_stats_ns=stats))
            if control and changes[0] >= 3 and changes[1] >= 3:
                any_blocks.append((name, block_name))
        repeated = all(row['process_median_percent'] >= 3 and row['process_mean_percent'] >= 3 for row in blocks)
        if repeated:
            repeated_all.append(name)
            if control:
                vetoes.append(name)
        if not aa and not cp and not control and any(row['process_median_percent'] >= 0 for row in blocks):
            targets_failed.append(name)
        results.append(dict(case=name, control=control, blocks=blocks))
    reported_veto = 'vetoed_cases_both_blocks' if cp else 'controls_vetoed_in_both_blocks'
    assert sorted(vetoes) == analysis[reported_veto]
    assert set(any_blocks) == {(row['case'], row['block']) for row in analysis['vetoed_control_blocks']}
    if cp:
        assert sorted({name for name, _ in any_blocks}) == analysis['vetoed_cases_any_block']
    else:
        assert sorted(targets_failed) == analysis['targets_not_improved_both_blocks']
    return dict(comparisons=results, vetoed_controls_both_blocks=sorted(vetoes),
        targets_not_improved_both_blocks=sorted(targets_failed),
        repeated_slowdowns_all_17_cases=sorted(repeated_all),
        gate_pass=not vetoes and not targets_failed)


def ordinary(root, cases, records, runtime_records, targets, aa=False):
    root = root.resolve()
    analysis, plan = load(root / 'analysis.json'), load(root / 'plan.json')
    assert analysis['status'] == 'complete'
    assert plan['samples'] == 21 and plan['warmups'] == 10
    assert plan['cases'] == [row['file'] for row in cases]
    assert {row['block']: row['order'] for row in plan['schedules']} == SCHEDULES
    assert plan['corpus_sha256'] == file_hash(CORPUS / 'manifest.json')
    policy = plan['resource_policy']
    assert policy['memory_bytes'] == MEMORY and policy['swap_bytes'] == 0 and policy['affinity'] == [0]
    assert int(policy['module_cache_entries']) == 1 and int(policy['module_cache_bytes']) == IMAGE_LIMIT
    assert plan['cache']['limit_bytes'] == 1073741824
    assert file_hash(plan['process_accounting']['supervisor']) == plan['process_accounting']['supervisor_sha256']
    if aa:
        study = load(BASE / 'study-plan.json')
        assert file_hash(BASE / 'aa-runner.py') == study['product_hash_audit']['aa_runner_sha256']
    else:
        assert file_hash(BASE / 'run.py') == plan['runner_sha256']
    published_rows = {row['raw']: row for row in analysis['rows']}
    assert len(published_rows) == len(analysis['rows']) == 272
    groups, expected_stems = collections.defaultdict(list), set()
    diagnostics = collections.defaultdict(collections.Counter)
    retention_images = collections.defaultdict(set)
    for index, case in enumerate(cases):
        name = case['file']
        for block, schedule in SCHEDULES.items():
            for ordinal, original_label in enumerate(schedule):
                label = 'baseline-aa' if aa and original_label == 'candidate' else original_label
                stem = f'{block}-case{index:02}-{ordinal}-{label}-{name}'
                expected_stems.add(stem)
                row = published_rows[stem]
                assert (row['case'], row['block'], row['round'], row['product']) == (name, block, ordinal, label)
                report = load(root / 'raw' / (stem + '.stdout'))
                command = load(root / 'raw' / (stem + '.command.json'))
                resource_check(command)
                argv = command['argv']
                assert len(argv) == 6 and Path(argv[0]).resolve() == BASE / label / 'runtime_baseline'
                assert Path(argv[1]).resolve() == CORPUS and argv[2:5] == ['21', '10', name]
                verify_identity(report, label, records, 'runtime_baseline')
                planned = plan['product_identities'][label]
                for key in ['source_commit', 'source_fingerprint']:
                    assert planned[key] == report[key]
                assert planned['executed_host_sha256'] == report['executable_sha256']
                assert report['schema'] == 'scriptw-wasmtime-baseline-v2'
                assert report['requested_native_policy'] is None and report['samples'] == 21 and report['warmups'] == 10
                assert len(report['cases']) == 1
                actual = report['cases'][0]
                assert actual['file'] == name and actual['source_compilation_profile'] == 'portable'
                assert actual['source_sha256'] == file_hash(CORPUS / name)
                runtime = runtime_records[label]['-portable']
                assert actual['linked_runtime']['wasm_sha256'] == runtime['wasm_sha256']
                assert actual['linked_runtime']['wasm_bytes'] == runtime['wasm_bytes']
                assert actual['linked_runtime']['key'] == runtime['runtime_key']
                artifact = Path(argv[5]) / (name + '.wasm')
                assert artifact.resolve() == root / 'artifacts' / stem / (name + '.wasm')
                data = artifact.read_bytes()
                assert len(data) == actual['wasm_bytes'] and digest(data) == actual['wasm_sha256']
                functions, code_bytes, largest, code = wasm_code(data)
                assert (functions, code_bytes, largest) == tuple(actual['footprint'][key] for key in
                    ['defined_functions', 'code_body_bytes', 'largest_code_body_bytes'])
                identity = (actual['source_sha256'], actual['wasm_sha256'], len(data), code_bytes, largest, digest(code))
                P_IDENTITIES[(name, label)].add(identity)
                P_CODE[(name, label)] = code
                for number, observation in enumerate(actual['observations']):
                    diagnostics[label + ':P_cache'][observation['module_cache']] += 1
                    if label == 'candidate':
                        loading, retention = observation['module_loading'], observation['module_retention']
                        for field in ['runtime_ns', 'program_ns']:
                            assert type(loading[field]) is int and loading[field] >= 0
                        assert loading['runtime_cache'] in ['Hit', 'Miss', 'Bypassed']
                        assert retention['entry_limit'] == 1 and retention['image_byte_limit'] == IMAGE_LIMIT
                        assert type(retention['entries']) is int and 0 <= retention['entries'] <= 1
                        assert type(retention['image_bytes']) is int and 0 <= retention['image_bytes'] <= IMAGE_LIMIT
                        assert (retention['entries'] == 0) == (retention['image_bytes'] == 0)
                        diagnostics[label + ':R_cache'][loading['runtime_cache']] += 1
                        if number >= 10:
                            diagnostics[label + ':measured_R_cache'][loading['runtime_cache']] += 1
                        retention_images[label].add((retention['entries'], retention['image_bytes']))
                stats = observations(actual, case['stdout'])
                assert stats['times'] == row['times_ns']
                close(stats['median'], row['invocation_median_ns'])
                close(stats['mean'], row['invocation_mean_ns'])
                assert row['process_elapsed_ns'] == command['elapsed_ns']
                stats.update(raw=stem, process_elapsed_ns=command['elapsed_ns'])
                groups[(name, block, label)].append(stats)
    assert {path.name.removesuffix('.stdout') for path in (root / 'raw').glob('*.stdout')} == expected_stems
    assert set(published_rows) == expected_stems
    post = None
    if not aa:
        post = load(root / 'post-product-hash.json')
        assert post['status'] == 'verified'
        expected = {f'{label}/{name}': row['sha256'] for label in ['baseline', 'candidate']
                    for name, row in records[label]['hosts'].items()}
        assert post['hashes'] == expected
    result = compare(analysis, groups, cases, aa, False, targets)
    result.update(path=str(root), raw_invocations=272, measured_observations=5712, warmups=2720,
        actual_P_artifacts_hashed=272, diagnostic_counts=dict(diagnostics),
        retention_image_observations={key: sorted(value) for key, value in retention_images.items()},
        hash_audit='old A/A snapshot: repeated preflight checks; current files independently hashed' if aa else
        'new runner: frozen preflight identities and matching post-product hashes independently checked',
        analysis_sha256=file_hash(root / 'analysis.json'), plan_sha256=file_hash(root / 'plan.json'))
    return result


def cp_configuration(config):
    assert config['native_compilation_mode'] == 'size-optimized'
    assert config['register_allocation'] == 'backtracking'
    assert config['consumer_compiler_enabled'] is False
    assert config['gc_initial_bytes'] == 16777216 and config['wasmtime_version'] == '47.0.0'
    assert config['collector'] == 'copying'
    assert config['max_wasm_stack_bytes'] == 33554432 and config['worker_stack_bytes'] == 67108864
    assert config['runtime_policy'] == 'scriptw-required-wasmtime-experimental-v1'


def cp_control(root, cases, records, runtime_records, targets):
    root = root.resolve()
    lane = BASE / 'cp-control'
    plan, analysis = load(root / 'plan.json'), load(root / 'analysis.json')
    assert analysis['status'] == 'complete' and plan['samples'] == 21 and plan['warmups'] == 10
    assert 'KeyError: \'execution_ns\'' in (lane / 'run.log').read_text()
    reused = [line.removeprefix('reused captured invocation ') for line in
              (lane / 'resume.log').read_text().splitlines() if line.startswith('reused captured invocation ')]
    assert reused == ['block0-case00-0-baseline-sort-reverse-128.js']
    assert plan['cases'] == [row['file'] for row in cases]
    assert {row['block']: row['order'] for row in plan['schedules']} == SCHEDULES
    policy = plan['resource_policy']
    assert policy['memory_bytes'] == MEMORY and policy['swap_bytes'] == 0 and policy['affinity'] == [0]
    assert policy['module_cache_entries'] == 1 and policy['module_cache_bytes'] == IMAGE_LIMIT
    assert plan['prepared_sha256'] == file_hash(lane / 'prepared.json') == analysis['prepared_sha256']
    prepared = load(lane / 'prepared.json')
    assert prepared['status'] == 'complete' and prepared['manifest_sha256'] == file_hash(CORPUS / 'manifest.json')
    groups, stems, images, receipts = collections.defaultdict(list), set(), {}, {}
    producers = {}
    for label in ['baseline', 'candidate']:
        path = lane / 'prepared' / label / 'producer-receipt.json'
        receipt = load(path)
        producers[label] = receipt
        receipts[label] = file_hash(path)
        assert receipts[label] == plan['producer_receipt_hashes'][label]
        assert receipts[label] == prepared['products'][label]['producer_receipt_sha256']
        verify_identity(receipt['producer'], label, records, 'compiler_precompiled_baseline')
        verify_identity(plan['product_identities'][label], label, records, 'compiler_precompiled_baseline')
        verify_identity(analysis['product_identities'][label], label, records, 'compiler_precompiled_baseline')
        resource_check(receipt['producer_command'])
        cp_configuration(receipt['producer_configuration'])
        assert receipt['producer_configuration'] == records[label]['identity']['shared_configuration']
        assert receipt['producer_configuration_sha256'] == digest(json.dumps(
            receipt['producer_configuration'], sort_keys=True, separators=(',', ':')).encode())
        assert receipt['producer']['compiler_enabled'] is True
        assert receipt['producer']['manifest_sha256'] == file_hash(CORPUS / 'manifest.json')
        producer_raw = lane / 'prepare-run/raw' / f'prepare-{label}'
        assert file_hash(str(producer_raw) + '.stdout') == receipt['producer_stdout_sha256']
        assert file_hash(str(producer_raw) + '.stderr') == receipt['producer_stderr_sha256']
        assert load(str(producer_raw) + '.stdout') == receipt['producer']
        assert load(str(producer_raw) + '.command.json') == receipt['producer_command']
        argv = receipt['producer_command']['argv']
        assert len(argv) == 4 and Path(argv[0]).resolve() == BASE / label / 'compiler_precompiled_baseline'
        assert argv[1] == 'prepare-scriptw' and Path(argv[2]).resolve() == CORPUS
        assert Path(argv[3]).resolve() == lane / 'prepared' / label
        produced_cases = {row['file']: row for row in receipt['producer']['cases']}
        assert set(produced_cases) == {row['file'] for row in cases}
        for case in cases:
            assert receipt['source_hashes'][case['file']] == file_hash(CORPUS / case['file'])
            assert produced_cases[case['file']]['stdout'] == case['stdout']
        for name, image in receipt['image_files'].items():
            path = lane / 'prepared' / label / image['path']
            assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            assert path.stat().st_size == image['bytes'] and file_hash(path) == image['sha256']
            assert image['runtime_key'] == runtime_records[label]['-portable']['runtime_key']
            assert produced_cases[name]['image_sha256'] == image['sha256']
            assert produced_cases[name]['program_wasm_sha256'] == image['program_wasm_sha256']
            images[f'{label}/{name}'] = image['sha256']
    assert images == plan['prepared_image_hashes']
    for index, case in enumerate(cases):
        name = case['file']
        for block, schedule in SCHEDULES.items():
            for ordinal, label in enumerate(schedule):
                stem = f'{block}-case{index:02}-{ordinal}-{label}-{name}'
                stems.add(stem)
                report = load(root / 'raw' / (stem + '.stdout'))
                command = load(root / 'raw' / (stem + '.command.json'))
                resource_check(command)
                verify_identity(report, label, records, 'compiler_precompiled_baseline')
                receipt = producers[label]
                image = receipt['image_files'][name]
                argv = command['argv']
                assert len(argv) == 6 and Path(argv[0]).resolve() == BASE / label / 'compiler_precompiled_baseline'
                assert argv[1] == 'execute-scriptw' and argv[3:] == [case['stdout'], '21', '10']
                assert Path(argv[2]).resolve() == lane / 'prepared' / label / image['path']
                assert report['schema'] == 'scriptw-precompiled-execution-v1'
                assert report['samples'] == 21 and report['warmups'] == 10
                assert report['adapter'] == 'scriptw' and report['compiler_enabled'] is False
                assert report['comparison_cohort'] == 'scriptw-precompiled-comparison-v1'
                assert report['excluded_from_ordinary_cohorts'] is True
                assert report['shared_configuration'] == receipt['producer_configuration']
                for field in ['runtime_key', 'program_wasm_sha256', 'execution_facts_sha256']:
                    assert report[field] == image[field]
                assert report['image_sha256'] == image['sha256']
                assert all(row['matched'] is True for row in report['observations'])
                assert all(row['completion'] == 'normal' and row['stderr'] == '' for row in report['observations'])
                assert [row['index'] for row in report['observations']] == list(range(31))
                stats = observations(report, case['stdout'], cp=True)
                stats.update(raw=stem, process_elapsed_ns=command['elapsed_ns'])
                groups[(name, block, label)].append(stats)
    assert {path.name.removesuffix('.stdout') for path in (root / 'raw').glob('*.stdout')} == stems
    post = load(root / 'post-input-hashes.json')
    assert post['status'] == 'verified' and post['prepared_images'] == images
    assert post['producer_receipts'] == receipts and post['prepared_manifest_sha256'] == plan['prepared_sha256']
    assert post['host_products'] == {f'{label}/{name}': row['sha256'] for label in ['baseline', 'candidate']
                                   for name, row in records[label]['hosts'].items()}
    result = compare(analysis, groups, cases, False, True, targets)
    failed_prepare_path = lane / 'first-attempt-prepare-run/raw/prepare-baseline.command.json'
    failed_prepare = load(failed_prepare_path)
    assert failed_prepare['exit_code'] != 0
    result.update(path=str(root), raw_invocations=272, measured_observations=5712, warmups=2720,
        compiler_preparations=2, prepared_image_files_hashed=len(images),
        timing_field='observations[].phases_ns.execution',
        parser_correction=dict(reused_captured_invocations=reused,
            original_runner_sha256=file_hash(lane / 'runner-before-timing-fix.py'),
            resumed_runner_sha256=file_hash(lane / 'cp_control.py'),
            original_failure_log_sha256=file_hash(lane / 'run.log'),
            resume_log_sha256=file_hash(lane / 'resume.log'),
            failed_preparation_command_sha256=file_hash(failed_prepare_path),
            failed_preparation_exit_code=failed_prepare['exit_code'],
            note='One producer setup failure is outside timing; the first successful consumer invocation is preserved and counted exactly once after parser correction.'),
        scope='Separate hot-R precompiled consumer veto lane; no independent promotion claim',
        analysis_sha256=file_hash(root / 'analysis.json'), plan_sha256=file_hash(root / 'plan.json'))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ordinary', required=True, type=Path)
    parser.add_argument('--aa', type=Path)
    parser.add_argument('--cp', type=Path)
    parser.add_argument('--candidate-fingerprint')
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), 'preserve prior audit output'
    record, cases = corpus()
    study = load(BASE / 'study-plan.json')
    targets = set(study['primary_targets'])
    assert len(targets) == 9 and len(set(row['file'] for row in cases) - targets) == 8
    records = products()
    if args.candidate_fingerprint:
        assert records['candidate']['identity']['source_fingerprint'] == args.candidate_fingerprint
    runtime_records = runtimes(records)
    correction = test_correction(records)
    aa = args.aa or (BASE / load(BASE / 'aa-analysis.json')['analysis']).parent
    cohorts = dict(aa=ordinary(aa, cases, records, runtime_records, targets, aa=True),
        ordinary=ordinary(args.ordinary, cases, records, runtime_records, targets))
    if args.cp:
        cohorts['cp_control'] = cp_control(args.cp, cases, records, runtime_records, targets)
    assert all(len(value) == 1 for value in P_IDENTITIES.values())
    footprints = []
    for case in cases:
        name = case['file']
        identities = {label: next(iter(P_IDENTITIES[(name, label)]))
                      for label in ['baseline', 'baseline-aa', 'candidate']}
        assert identities['baseline'] == identities['baseline-aa'], 'A/A P copies differ'
        footprints.append(dict(case=name, identities=identities,
            P_bytes_equal=identities['baseline'][1] == identities['candidate'][1],
            exact_code_section_equal=P_CODE[(name, 'baseline')] == P_CODE[(name, 'candidate')]))
    report = dict(status='audited', audit_script_sha256=file_hash(__file__),
        corpus_sha256=record['manifest_sha256'], products=records, runtimes=runtime_records,
        excluded_test_source_correction=correction,
        cohorts=cohorts, P_footprint_fields=['source_sha256', 'wasm_sha256', 'wasm_bytes',
            'code_body_bytes', 'largest_body_bytes', 'code_section_sha256'], P_footprints=footprints,
        total_raw_invocations=sum(value['raw_invocations'] for value in cohorts.values()),
        maximum_recomputed_statistic_discrepancy=MAX_DISCREPANCY, peak_child_rss_bytes=MAX_RSS,
        hashed_files={str(path): value for path, value in HASHED.items()},
        limitations=[
            'Existing artifacts only; no measurements, tests, conformance or reference replay.',
            'A/A uses the preserved old runner and has no new post-product receipt.',
            'R intentionally changes; P package byte equality is descriptive, not a required gate.',
            'Runtime cache outcomes and retained-image accounting are not page-fault or GC attribution.',
            'CP native images are byte-hashed; their P Wasm/execution-fact identities are checked against the bound producer receipt, not re-extracted from native code.',
            'Scored units are independent processes; pooled samples remain descriptive.',
        ])
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(output=str(args.output), raw_invocations=report['total_raw_invocations'],
        gates={key: value['gate_pass'] for key, value in cohorts.items()},
        maximum_statistic_discrepancy=MAX_DISCREPANCY), indent=2))


if __name__ == '__main__':
    main()
