from pathlib import Path
import json, subprocess, sys, time
root=Path.cwd();out=root/'target/performance-entry-bootstrap';folder=out/'test-correction';sys.path.insert(0,str(root/'scripts'))
from benchmark_metrics import digest
from native_test_protocol import parse_inventory,result_summaries
rows=[json.loads(s) for s in (folder/'build.jsonl').read_text().splitlines()];assert rows[-1]=={'reason':'build-finished','success':True}
p=next(r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='scriptw_aot_wasm' and r['profile']['test']);exe=Path(p['executable']);sha=digest(exe)
selected=json.loads((folder/'correction.json').read_text())['failed_test'];listing=subprocess.check_output([exe,'--list'],text=True);inventory=parse_inventory(listing);assert selected in inventory
(folder/'corrected.inventory').write_text(listing);argv=[str(exe),'--exact',selected,'--test-threads=1','--nocapture'];start=time.monotonic()
with (folder/'corrected.stdout').open('wb') as stdout,(folder/'corrected.stderr').open('wb') as stderr:r=subprocess.run(argv,stdout=stdout,stderr=stderr,check=False)
summaries=result_summaries((folder/'corrected.stdout').read_text());receipt=dict(argv=argv,executable_sha256=sha,producer=p,selected_inventory=[selected],exit_code=r.returncode,summaries=summaries,elapsed_seconds=time.monotonic()-start);(folder/'corrected-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['exit_code'],summaries,flush=True)
assert r.returncode==0 and summaries==[('ok','1','0','0','0',str(len(inventory)-1))]
subprocess.run(['cp','--reflink=auto',str(exe),str(folder/'corrected-backend-tests')],check=True);assert digest(folder/'corrected-backend-tests')==sha
inputs=json.loads((out/'pre-build-sources.json').read_text());changed=[name for name,expected in inputs.items() if digest(root/name)!=expected];assert changed==['crates/scriptw-aot-wasm/src/tests/runtime_error_for_throw.rs'],changed
for name,row in json.loads((out/'candidate/products.json').read_text()).items():assert digest(out/'candidate'/name)==row['sha256']
(folder/'production-reuse.json').write_text(json.dumps(dict(status='unchanged',changed_source_paths=changed,excluded_by='crates/scriptw-engine/compiler_fingerprint.rs TEST_ONLY_INPUTS: crates/scriptw-aot-wasm/src/tests',production_source_fingerprint=json.loads((out/'candidate/identity.json').read_text())['source_fingerprint'],frozen_products_rehashed=True),indent=2)+'\n')
subprocess.run([sys.executable,'-B',str(out/'verify_native.py'),'--remaining'],check=True)
