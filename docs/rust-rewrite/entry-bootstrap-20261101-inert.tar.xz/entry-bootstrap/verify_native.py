from pathlib import Path
import json, subprocess, sys, time
root=Path.cwd();out=root/'target/performance-entry-bootstrap';sys.path.insert(0,str(root/'scripts'))
from benchmark_metrics import digest
from native_test_protocol import parse_inventory,result_summaries
artifacts={}
for line in (out/'native-build.jsonl').read_text().splitlines():
 row=json.loads(line)
 if row.get('reason')=='compiler-artifact' and row.get('executable') and row['profile']['test']:artifacts[row['target']['name']]=row
scopes=[('scriptw_engine','memory_module_cache::'),('scriptw_engine','wasm_runtime_link::tests::'),('scriptw_engine','runtime_profile::'),('scriptw_aot_wasm',None),('structure_language',None),('emission',None),('aot_language',None),('aot_gc_entries',None)]
folder=out/'native';folder.mkdir(exist_ok=True);records=[]
if '--remaining' in sys.argv:
 scopes=scopes[4:]
 records=json.loads((folder/'initial-receipt.json').read_text())
for target,selection in scopes:
 producer=artifacts[target];exe=Path(producer['executable']);sha=digest(exe);stem=target+('-'+selection.replace('::','_').strip('_') if selection else '')
 listing=subprocess.check_output([exe,'--list'],text=True);(folder/(stem+'.inventory')).write_text(listing);inventory=parse_inventory(listing)
 selected=[name for name in inventory if selection is None or selection in name];assert selected
 receipt=folder/(stem+'.json')
 if receipt.exists():
  old=json.loads(receipt.read_text())
  if old['exit_code']==0 and old['executable_sha256']==sha and old['selected_inventory']==selected:records.append(old);print(stem,'reuse',len(selected),flush=True);continue
 argv=[str(exe),'--test-threads=1'];argv+=[] if selection is None else [selection,'--nocapture']
 start=time.monotonic()
 with (folder/(stem+'.stdout')).open('wb') as stdout,(folder/(stem+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr,timeout=3600)
 summaries=result_summaries((folder/(stem+'.stdout')).read_text());row=dict(target=target,selection=selection,argv=argv,producer=producer,executable_sha256=sha,selected_inventory=selected,exit_code=result.returncode,summaries=summaries,elapsed_seconds=time.monotonic()-start)
 receipt.write_text(json.dumps(row,indent=2)+'\n');records.append(row);(folder/'receipt.json').write_text(json.dumps(records,indent=2)+'\n')
 print(stem,len(selected),result.returncode,summaries,flush=True)
 assert digest(exe)==sha
 assert result.returncode==0 and len(summaries)==1 and summaries[0][0]=='ok' and int(summaries[0][1])==len(selected) and int(summaries[0][2])==int(summaries[0][3])==0
