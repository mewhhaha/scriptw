"""Run the six pinned entry-bootstrap Test262 scopes without discarding outcomes."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
COHORT = OUT.parent
ROOT = COHORT.parents[1]
CLI = COHORT / "candidate/scriptw"
IDENTITY_PATH = COHORT / "candidate/identity.json"
HOST_PRODUCTS_PATH = COHORT / "candidate/host-products.json"
SUITE = ROOT / "test262/vendor/test262"
SNAPSHOT_ROOT = OUT / "snapshots"
SNAPSHOT_STEM = "entry-bootstrap"

SCOPES = [
    ("property-accessors", "language/expressions/property-accessors"),
    ("object-getownpropertynames", "built-ins/Object/getOwnPropertyNames"),
    ("map-get", "built-ins/Map/prototype/get"),
    ("set-has", "built-ins/Set/prototype/has"),
    ("error-tostring", "built-ins/Error/prototype/toString"),
    ("array-join", "built-ins/Array/prototype/join"),
]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def save_receipt(rows):
    path = OUT / "test262-entry-bootstrap-receipt.json"
    temporary = OUT / (path.name + ".tmp")
    temporary.write_text(json.dumps(rows, indent=2) + "\n")
    temporary.replace(path)


def snapshot_files(directory):
    found = []
    errors = []
    for path in sorted(directory.rglob("*.json")):
        try:
            value = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError) as error:
            errors.append(dict(path=str(path.relative_to(OUT)), error=str(error)))
            continue
        if value.get("snapshot_version") == 8:
            found.append((path, value))
    return found, errors


def run_scope(name, selection, identity, cli_sha256):
    directory = SNAPSHOT_ROOT / name
    directory.mkdir(parents=True, exist_ok=False)
    snapshot_name = f"{SNAPSHOT_STEM}-{name}-20261101"
    argv = [str(CLI), "--jobs", "1", "test262", "run", selection,
        "--execution-backend", "wasm-aot", "--suite-root", str(SUITE),
        "--snapshot-dir", str(directory), "--snapshot-name", snapshot_name,
        "--threads", "1", "--timeout-ms", "60000", "--reuse-case-workers"]
    stdout_path = OUT / f"{name}.stdout"
    stderr_path = OUT / f"{name}.stderr"
    started = time.monotonic()
    timed_out = False
    launch_error = None
    exit_code = None
    with stdout_path.open("x") as stdout, stderr_path.open("x") as stderr:
        try:
            result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr,
                timeout=7200, check=False)
            exit_code = result.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
            exit_code = 124
        except OSError as error:
            launch_error = str(error)
            exit_code = 127
    found, parse_errors = snapshot_files(directory)
    row = dict(selection=selection, argv=argv, cli_sha256=cli_sha256,
        expected_source_fingerprint=identity["source_fingerprint"], exit_code=exit_code,
        timed_out=timed_out, launch_error=launch_error,
        elapsed_seconds=time.monotonic() - started,
        stdout=str(stdout_path.relative_to(OUT)), stdout_sha256=sha(stdout_path),
        stderr=str(stderr_path.relative_to(OUT)), stderr_sha256=sha(stderr_path),
        snapshots=[], snapshot_parse_errors=parse_errors)
    for path, snapshot in found:
        compiler_identity = snapshot.get("compiler_identity", {})
        completed = snapshot.get("completed_test_ids", [])
        completed_bytes = json.dumps(completed, ensure_ascii=False,
            separators=(",", ":")).encode()
        row["snapshots"].append(dict(path=str(path.relative_to(OUT)),
            snapshot_version=snapshot.get("snapshot_version"),
            compiler_identity=compiler_identity,
            source_fingerprint_matches=(compiler_identity.get("source_fingerprint") == identity["source_fingerprint"]),
            execution_backend=snapshot.get("execution_backend"),
            pinned_revisions=snapshot.get("pinned_revisions"),
            manifest_hash=snapshot.get("manifest_hash"),
            total=snapshot.get("total"), passed=snapshot.get("passed"),
            counts_per_kind=snapshot.get("counts_per_kind"),
            counts_per_outcome=snapshot.get("counts_per_outcome"),
            completed_test_ids=completed,
            completed_test_ids_sha256=hashlib.sha256(completed_bytes).hexdigest(),
            failures=snapshot.get("failures"), timeout_test_ids=snapshot.get("timeout_test_ids")))
    row["scope_pass"] = (exit_code == 0 and not timed_out and launch_error is None
        and len(row["snapshots"]) == 1
        and row["snapshots"][0]["source_fingerprint_matches"]
        and row["snapshots"][0]["total"] > 0
        and row["snapshots"][0]["passed"] == row["snapshots"][0]["total"])
    return row


def main():
    OUT.mkdir(exist_ok=True)
    identity = json.loads(IDENTITY_PATH.read_text())
    products = json.loads(HOST_PRODUCTS_PATH.read_text())
    assert CLI.is_file() and not CLI.is_symlink() and CLI.stat().st_nlink == 1
    cli_sha256 = sha(CLI)
    assert products["scriptw"]["sha256"] == cli_sha256, "frozen CLI hash mismatch"
    assert identity["source_fingerprint"] and identity["source_commit"]
    SNAPSHOT_ROOT.mkdir(exist_ok=True)

    receipt = dict(status="running", snapshot_stem=SNAPSHOT_STEM,
        cli_sha256=cli_sha256, source_commit=identity["source_commit"],
        source_fingerprint=identity["source_fingerprint"], scopes=[])
    save_receipt(receipt)
    for name, selection in SCOPES:
        row = run_scope(name, selection, identity, cli_sha256)
        receipt["scopes"].append(row)
        receipt["status"] = "running"
        save_receipt(receipt)
        print(selection, "PASS" if row["scope_pass"] else "FAIL", flush=True)
    receipt["status"] = "complete" if all(row["scope_pass"] for row in receipt["scopes"]) else "failed"
    save_receipt(receipt)
    if receipt["status"] != "complete":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
