from pathlib import Path
import subprocess,json,hashlib,struct
root=Path.cwd();out=root/'target/performance-entry-bootstrap';folder=out/'program-inspection';folder.mkdir();tool=root/'target/performance-fresh-sort/tools/wasm-tools';run=out/'runs/20261101T042731Z-candidate-full17';analysis=json.loads((run/'analysis.json').read_text());records=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for case in ['numeric-loop-50000.js','sort-reverse-512.js','join-small-1024.js']:
 row=next(r for r in analysis['rows'] if r['case']==case and r['product']=='candidate');scriptw=run/'artifacts'/row['raw']/(case+'.wasm')
 for label,source in [('scriptw',scriptw),('scriptc',out/'scriptc-wasm'/(case+'.wasm'))]:
  wat=folder/(label+'-'+case+'.wat')
  with wat.open('wb') as stdout:subprocess.run([tool,'print',source],stdout=stdout,check=True)
  records.append(dict(product=label,case=case,source_wasm=str(source.relative_to(out)),wasm_sha256=sha(source),wat=wat.name,wat_sha256=sha(wat)))
package=out/'candidate/runtime-build/scriptw-runtime-portable-package.bin';data=package.read_bytes();wasm=data[136:-32];assert len(wasm)==struct.unpack_from('<Q',data,128)[0];runtime=folder/'runtime-portable-inspection-input.wasm';runtime.write_bytes(wasm)
process=subprocess.Popen([tool,'print',runtime],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);fragment=[];started=False
for line in process.stdout:
 if line.startswith('  (func $helper::pooled_string_resolve '):started=True
 if started:
  fragment.append(line);assert sum(map(len,fragment))<128*1024
  if line.rstrip()=='  )':break
assert started and fragment[-1].rstrip()=='  )';process.terminate();process.wait(timeout=10);assert process.returncode in (0,-15,-13)
path=folder/'runtime-pooled-string-resolve.wat-fragment';path.write_text(''.join(fragment));runtime.unlink()
assert 'i64.load' in path.read_text() and 'array.new_data' in path.read_text()
record=dict(source_fingerprint=json.loads((out/'candidate/identity.json').read_text())['source_fingerprint'],tool_version=subprocess.check_output([tool,'--version'],text=True).strip(),files=records,runtime_fragment=dict(runtime_wasm_sha256=hashlib.sha256(wasm).hexdigest(),path=path.name,sha256=sha(path),scope='Exact named function fragment printed from the frozen Portable R; function header and body retained; external type/global names require its original module. Other R bodies/data omitted.'))
(folder/'identity.json').write_text(json.dumps(record,indent=2)+'\n');print('inspected six actual P modules and frozen R resolver',flush=True)
