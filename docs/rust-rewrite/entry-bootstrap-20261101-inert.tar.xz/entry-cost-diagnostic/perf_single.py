from pathlib import Path
import subprocess, os, json, hashlib, collections, bisect, time
root=Path.cwd(); out=root/'target/performance-entry-cost/perf-singles';out.mkdir(exist_ok=True)
perf=root/'target/performance-fresh-sort/tools/perf/usr/bin/perf'
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(perf.parent.parent/'lib');env['SCRIPTW_PERF_MAP_DIR']='/tmp'
cli=root/'target/performance-entry-cost/products/scriptw';source=root/'target/performance-entry-cost/sources/print.js'
records=[];totals=collections.Counter();all_samples=0
for index in range(16):
    prefix=out/f'{index:02d}';data=prefix.with_suffix('.data')
    argv=[str(perf),'record','-e','cycles:u','-c','1000','-o',str(data),'--',str(cli),'--jobs','1','run',str(source)]
    start=time.monotonic()
    with prefix.with_suffix('.stdout').open('wb') as stdout,prefix.with_suffix('.stderr').open('wb') as stderr:
        subprocess.run(argv,env=env,stdout=stdout,stderr=stderr,check=True)
    assert prefix.with_suffix('.stdout').read_text()=='1\nrun outcome: RunOutcome { backend_used: WasmAot, note: \"wasm-aot completion: undefined(undefined)\" }\n'
    trace=subprocess.run([str(perf),'script','-i',str(data),'-F','pid,ip,sym'],env=env,check=True,capture_output=True,text=True)
    prefix.with_suffix('.script').write_text(trace.stdout)
    samples=[line.split() for line in trace.stdout.splitlines() if len(line.split())>=3]
    pids=collections.Counter(row[0] for row in samples);assert len(pids)==1,pids
    pid=next(iter(pids));mp=Path(f'/tmp/perf-{pid}.map')
    prefix.with_suffix('.map').write_bytes(mp.read_bytes());prefix.with_suffix('.map.identity').write_bytes(mp.with_suffix('.map.identity').read_bytes())
    mapping=[]
    for line in mp.read_text().splitlines():
        address,length,name=line.split(maxsplit=2);mapping.append((int(address,16),int(length,16),name))
    mapping.sort();starts=[row[0] for row in mapping];counts=collections.Counter()
    for row in samples:
        pc=int(row[1],16);slot=bisect.bisect_right(starts,pc)-1
        if slot>=0 and pc<starts[slot]+mapping[slot][1]:counts[mapping[slot][2]]+=1
    all_samples+=len(samples);totals.update(counts)
    records.append(dict(index=index,pid=pid,argv=argv,elapsed_seconds=time.monotonic()-start,samples=len(samples),guest_samples=sum(counts.values()),guest_counts=counts))
    print(index,len(samples),sum(counts.values()),flush=True)
summary=dict(scope='Unscored whole-process cycles:u self samples, period1000; each process executes one print program once. Own final R/P map per process; no callgraph, excludes unmapped host/Wasmtime costs. No isolated Realm total.',records=records,total_samples=all_samples,guest_samples=sum(totals.values()),guest_counts=totals.most_common(),cli_sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='records'},indent=2))
