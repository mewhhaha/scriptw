print(1);
