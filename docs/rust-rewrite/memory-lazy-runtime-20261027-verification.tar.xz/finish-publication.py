"""Publish the completed99 checkpoint, without changing any source or Git refs."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
source='99a4ff2e962b6efa8066a48447f3c077981c59ec'
conformance=json.loads((BASE/'conformance/report.json').read_text())
assert conformance['complete'] and conformance['total']==conformance['passed']==1589
assert json.loads((BASE/'remaining-verification/report.json').read_text())['complete']
subprocess.run([sys.executable,'-B',str(BASE/'publish-verification.py')],cwd=ROOT,check=True)
report,rows=p.publish(BASE/'github-40411932915/precompiled-evidence/report.json',ROOT,replace=True)
assert report['source_commit']==source
readme=ROOT/'README.md';text=readme.read_text()
text=text.replace('compiler `b1ffc3ffd`.','compiler `99a4ff2e9`.')
text=text.replace("**1.9–2.8× Scriptc's**", "**1.8–2.8× Scriptc's**")
for old,new in [('25.9 MiB','25.3 MiB'),('30.5 MiB','30.2 MiB'),('41.4 MiB','40.9 MiB'),('19.9 MiB','20.0 MiB')]:text=text.replace(old,new)
start=text.index('The current memory pass streams native runtime loading,')
end=text.index('\n\n[All measurements',start)
text=text[:start]+"""The current pass defers canonical runtime strings and noncanonical intrinsic
method functions, and probes packed Array indices before allocating property
keys. [Verification](docs/rust-rewrite/memory-lazy-runtime-20261027.md):
**4,503 native cases and 1,589 original pinned Test262 executions passed**.
The original long test process reached the 4-GiB cap; its unchanged inventory
was completed in smaller fresh-process groups under the same limit."""+text[end:]
text=text.replace('actions/runs/40401356113','actions/runs/40411932915')
readme.write_text(text)
record=json.loads((ROOT/'docs/rust-rewrite/memory-lazy-runtime-20261027.json').read_text())
a=record['archive']
doc=f"""# Lazy runtime allocation checkpoint

Source `{source}`, verified 2026-10-27.
The [matched precompiled comparison](precompiled-comparison.md) measures
Scriptw at **1.8–2.8 times Scriptc's post-execution RSS** across17 workloads.
Scriptc parity remains open.

| Workload | Scriptw RSS | Scriptc RSS |
| --- | ---: | ---: |
| Integer | 25.3 MiB | 13.4 MiB |
| Objects | 30.2 MiB | 14.2 MiB |
| Retained objects | 40.9 MiB | 20.0 MiB |

Three Sol reviews guided this batch. Canonical runtime strings now materialize
from their sealed UTF-16 rows on demand. Noncanonical intrinsic method data
properties retain their keys, attributes, aliases and defining Realm while
deferring the function allocation until a value is needed. Canonical slots,
constructors and accessors remain eager. Packed Array HasProperty probes avoid
string keys for present own data while retaining live fallback semantics.
The [allocation contract](contracts/lazy-runtime-values.md) records the
representation, snapshot handling and incompatible-layout rejection.

The workspace/all-targets type check passed. Fifteen source-identity recipes,
the source-only structural guards, the runtime-source profile guard and the
retired-JavaScript guard passed. Fifteen complete native scopes cover
**4,503 distinct cases**, with zero failures or ignored cases in the completed
inventory; focused checks overlap these totals. Both complete typed structural
targets are included (166 builtin and152 language cases).

The exact original pinned Test262 selection covers Array map/slice, Set aliases,
Math.abs, Object/Reflect descriptors, freeze/seal and string normalization.
**1,589 executions passed**, with zero failed, crashed or unsupported executions.
This is selected source-bound verification, not a full pinned-suite refresh.

Verification uses one CPU, a4-GiB process-tree cap, no swap, grouped OOM and
bounded module retention. The original engine-library process was killed at
that cap after237 individually recorded successes. The interrupted case passed
in a fresh process; the remaining802 cases then passed in groups of at most
eight against the same frozen Cargo-produced executable. The union covers its
full1,040-case inventory exactly. The failed command, kernel OOM journal and
all fresh-process results are retained. No source case was removed and the
limit was not raised. This establishes the completed inventory; it does not
establish that the original full-process invocation passes.

The [CI run](https://github.com/mewhhaha/scriptw/actions/runs/40411932915)
is the authoritative same-runner Scriptw/Scriptc measurement: compiler-disabled
consumers, two rounds, ten checked warmups and seven samples per round.
The README graphs show this latest matched cohort. Other runner revisions are
not controlled before/after evidence. RSS includes host/runtime, code and
warmup history; it is neither live JavaScript heap size nor peak memory.

[Verification record](memory-lazy-runtime-20261027.json) ·
[Lossless raw verification archive](memory-lazy-runtime-20261027-verification.tar.xz) ·
[Matched measurements and raw evidence](precompiled-comparison.md).

The verification archive contains{a['member_count']:,} regular files and
{a['expanded_bytes']:,} expanded bytes. Its recorded SHA-256, member hashes and
bounds permit checking without running native code. The64-MiB xz dictionary
compresses repeated Cargo diagnostics losslessly; expansion is bounded at2GiB,
with at most128MiB per member and32MiB compressed. Executables and serialized
native images are excluded. Failed preparatory checks remain in the archive.
"""
for old,new in [('across17','across 17'),('and152','and 152'),('a4-GiB','a 4-GiB'),('after237','after 237'),('remaining802','remaining 802'),('full1,040','full 1,040'),('contains{','contains {'),('The64-MiB','The 64-MiB'),('at2GiB','at 2 GiB'),('most128MiB','most 128 MiB'),('and32MiB','and 32 MiB')]:doc=doc.replace(old,new)
# f-string already expanded: preserve natural spacing around the archive count.
doc=doc.replace(f"contains{a['member_count']:,}",f"contains {a['member_count']:,}")
(ROOT/'docs/rust-rewrite/memory-lazy-runtime-20261027.md').write_text(doc)
subprocess.run([sys.executable,'-B',str(BASE/'check-publication.py')],cwd=ROOT,check=True)
