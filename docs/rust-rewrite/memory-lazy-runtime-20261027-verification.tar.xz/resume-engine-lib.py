from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
SOURCE='99a4ff2e962b6efa8066a48447f3c077981c59ec'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
OUT=BASE/'engine-lib-resume';OUT.mkdir(exist_ok=False)
BIN=(BASE/'engine-lib-frozen/engine-lib').resolve()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
provenance=json.loads((BASE/'engine-lib-frozen/provenance.json').read_text());assert sha(BIN)==provenance['executable_sha256']
group=kernel_group()
def resources():return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
report=dict(source_commit=SOURCE,complete=False,executable_sha256=sha(BIN),cpu_affinity=sorted(os.sched_getaffinity(0)),before=resources(),original_scope_result='oom-kill; original command streams retained',commands=[],source_provenance=provenance)
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args):
 row=dict(label=label,command=args,cwd=str(ROOT/'crates/scriptw-engine'),stdout=label+'.stdout',stderr=label+'.stderr')
 report['commands'].append(row);save();start=time.monotonic()
 with (OUT/row['stdout']).open('xb') as out,(OUT/row['stderr']).open('xb') as err:
  child=subprocess.run(args,cwd=ROOT/'crates/scriptw-engine',stdout=out,stderr=err,timeout=1800)
 row.update(exit_code=child.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(OUT/row['stdout']),stderr_sha256=sha(OUT/row['stderr']));save()
 assert child.returncode==0,label
 return (OUT/row['stdout']).read_text()
raw=run('inventory',[str(BIN),'--list'])
names=parse_inventory(raw)
assert len(names)==1040 and len(names)==len(set(names))
passed=set(provenance['individual_passes']);assert passed<=set(names)
capacity='runtime_profile::native_mode_cohort_tests::explicit_16_and_32_mib_controls_access_the_same_matching_image_owner'
probe=BASE/'engine-lib-fresh-capacity.stdout';text=probe.read_text()
assert re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)==[capacity]
assert 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 1039 filtered out;' in text
assert capacity not in passed
passed.add(capacity)
report['fresh_capacity_probe']=dict(test=capacity,exit_code_observed_via_tool=0,stdout_sha256=sha(probe),stderr_sha256=sha(BASE/'engine-lib-fresh-capacity.stderr'))
remaining=[n for n in names if n not in passed]
report.update(inventory=names,initial_unique_passes=len(passed),remaining=len(remaining),chunk_size=8);save()
for index in range(0,len(remaining),8):
 chunk=remaining[index:index+8];label=f'shard-{index//8:03d}'
 text=run(label,[str(BIN),'--exact','--include-ignored','--test-threads=1',*chunk])
 actual=re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)
 assert len(actual)==len(chunk) and set(actual)==set(chunk),(label,actual,chunk)
 results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
 assert results==[(str(len(chunk)),'0','0','0',str(len(names)-len(chunk)))],(label,results)
 assert not passed.intersection(actual);passed.update(actual)
 report['verified_unique_passes']=len(passed);save();print(label,len(passed),'/',len(names),flush=True)
assert passed==set(names) and sha(BIN)==provenance['executable_sha256']
report.update(complete=True,passed=len(passed),after=resources(),finished_at=datetime.now(timezone.utc).isoformat());save();print('engine library complete',len(passed),flush=True)
