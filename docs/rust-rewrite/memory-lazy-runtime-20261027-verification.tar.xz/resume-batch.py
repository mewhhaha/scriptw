from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
SOURCE='99a4ff2e962b6efa8066a48447f3c077981c59ec'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
original=json.loads((BASE/'native-verification/report.json').read_text())
engine=json.loads((BASE/'engine-lib-resume/report.json').read_text());assert engine['complete'] and engine['passed']==1040
OUT=BASE/'remaining-verification';OUT.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
group=kernel_group()
def resources():return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
report=dict(source_commit=SOURCE,complete=False,cpu_affinity=sorted(os.sched_getaffinity(0)),before=resources(),commands=[],scopes=[])
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,stdout=None,stderr=None):
 stdout=stdout or OUT/(label+'.stdout');stderr=stderr or OUT/(label+'.stderr')
 entry=dict(label=label,command=args,stdout=str(stdout.relative_to(BASE)),stderr=str(stderr.relative_to(BASE)))
 report['commands'].append(entry);save();print(label,'started',flush=True);start=time.monotonic()
 with stdout.open('xb') as out,stderr.open('xb') as err:child=subprocess.run(args,cwd=ROOT,stdout=out,stderr=err,timeout=3600)
 entry.update(exit_code=child.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr));save()
 print(label,'finished',child.returncode,flush=True)
 assert child.returncode==0,label
 return entry
for label,target in [('wasm-lib',['--lib']),('wasm-structure-builtins',['--test','structure_builtins']),('wasm-structure-language',['--test','structure_language'])]:
 row=run(label,['cargo','test','--locked','--offline','--release','--jobs','1','--target-dir',str(ROOT/'target/performance-work-20261024/build'),'-p','scriptw-aot-wasm',*target,'--message-format=json','--','--test-threads=1'])
 results=[];executables=[]
 for line in (BASE/row['stdout']).open():
  found=re.fullmatch(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in .+\n?',line)
  if found:results.append(dict(zip(['passed','failed','ignored','measured','filtered'],map(int,found.groups()))))
  if line.startswith('{') and '"reason":"compiler-artifact"' in line[:200]:
   x=json.loads(line)
   if x.get('executable') and x.get('profile',{}).get('test'):
    path=Path(x['executable']);executables.append(dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size,cargo_producer=x))
 assert len(results)==1 and results[0]['passed']>0 and all(results[0][k]==0 for k in ['failed','ignored','measured','filtered']),(label,results)
 assert executables,label
 report['scopes'].append(dict(**row,test_results=results,executables=executables,overlaps_full_scope=False));save()
completed=[x for x in original['scopes'] if x.get('exit_code')==0]
assert len(completed)+1==len(original['scopes'])
final=dict(source_commit=SOURCE,complete=True,original_attempt_report='native-verification/report.json',original_attempt_sha256=sha(BASE/'native-verification/report.json'),original_scope_result='engine-lib interrupted by4GiB groupedOOM; original streams retained',
 completed_original_scopes=completed,engine_lib_coverage_report='engine-lib-resume/report.json',engine_lib_coverage_sha256=sha(BASE/'engine-lib-resume/report.json'),engine_lib_passed=engine['passed'],remaining_scopes=report['scopes'],
 passed_disjoint_scopes=sum(x['test_results'][0]['passed'] for x in completed if not x['overlaps_full_scope'])+engine['passed']+sum(x['test_results'][0]['passed'] for x in report['scopes']))
(BASE/'native-final-report.json').write_text(json.dumps(final,indent=2)+'\n')
row=run('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',str(ROOT/'target/performance-work-20261024/build'),'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json'],BASE/'cargo-products.jsonl',BASE/'cargo-products.stderr')
run('test262-driver',[sys.executable,'-B',str(BASE/'test262.py')])
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=resources());save();print('remaining batch complete',flush=True)
