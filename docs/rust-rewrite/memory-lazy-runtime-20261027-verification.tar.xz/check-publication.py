"""Check retained evidence, recovered inventory, source-bound measurements and charts."""
import hashlib,json,re,sys,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
docs=ROOT/'docs/rust-rewrite'
record=json.loads((docs/'memory-lazy-runtime-20261027.json').read_text())
assert record['source_commit']=='99a4ff2e962b6efa8066a48447f3c077981c59ec'
archive=docs/record['archive']['file']
assert p.digest(archive)==record['archive']['sha256'] and archive.stat().st_size==record['archive']['bytes']<=32*1024**2
expected={x['path']:x for x in record['retained_files']}
assert len(expected)==len(record['retained_files'])
seen=set();expanded=0;special={}
reports={'native-final-report.json','engine-lib-resume/report.json','conformance/report.json','batch-report.json','remaining-verification/report.json','engine-lib-frozen/provenance.json'}
with tarfile.open(archive,'r|xz') as tar:
 for member in tar:
  assert member.isfile() and member.name in expected and member.name not in seen
  path=PurePosixPath(member.name)
  assert not path.is_absolute() and '..' not in path.parts
  assert member.size==expected[member.name]['bytes'] and member.size<=128*1024**2
  expanded+=member.size;assert expanded<=2*1024**3
  data=tar.extractfile(member);digest=hashlib.sha256();count=0;chunks=[]
  for chunk in iter(lambda:data.read(1024**2),b''):
   count+=len(chunk);digest.update(chunk)
   if member.name in reports:chunks.append(chunk)
  assert count==member.size and digest.hexdigest()==expected[member.name]['sha256']
  if chunks:special[member.name]=json.loads(b''.join(chunks))
  seen.add(member.name)
assert seen==set(expected) and len(seen)==record['archive']['member_count'] and expanded==record['archive']['expanded_bytes']
assert special['native-final-report.json']==record['native'] and special['conformance/report.json']==record['test262']
assert special['batch-report.json']==record['batch']['initial_attempt']
assert special['remaining-verification/report.json']==record['batch']['resumed_attempt']
assert record['batch']['original_exit_code']==137
engine=special['engine-lib-resume/report.json'];provenance=special['engine-lib-frozen/provenance.json']
assert engine['complete'] and engine['passed']==len(engine['inventory'])==1040
assert len(provenance['individual_passes'])==237 and engine['initial_unique_passes']==238 and engine['remaining']==802
assert engine['executable_sha256']==provenance['executable_sha256']
assert record['native']['passed_disjoint_scopes']==4503
assert record['test262']['total']==record['test262']['passed']==1589
assert all(x['returncode']==0 for x in record['test262']['commands'])
report,rows=p.load_report(docs/'precompiled-comparison.json',docs/'precompiled-comparison.tar.gz')
assert report['source_commit']==record['source_commit'] and len(rows)==17
readme=(ROOT/'README.md').read_text();ratios=[]
for row in rows:
 ratios.append(row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib'])
 if row['file'] in ('integer.js','objects.js','retained-objects.js'):
  for rt in p.RUNTIMES:assert f"{row['runtimes'][rt]['rss_mib']:.1f} MiB" in readme
assert f"**{min(ratios):.1f}–{max(ratios):.1f}× Scriptc's**" in readme
for metric,chart in p.CHARTS.items():
 content=p.render(report,rows,metric,Path(__file__).resolve().parent/f'preview-{metric}.png')
 assert content==(docs/'assets'/chart['filename']).read_bytes()
print(json.dumps(dict(verified=True,source_commit=report['source_commit'],workloads=17,verification_members=len(seen),expanded_bytes=expanded,native=4503,test262=1589)))
