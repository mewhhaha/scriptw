"""Sequential source-bound checks inside the caller's local resource scope."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group

require_kernel_budget(4 * 1024**3)
assert len(os.sched_getaffinity(0)) == 1
SOURCE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
OUTPUT = Path(__file__).resolve().parent / 'native-verification'
OUTPUT.mkdir(exist_ok=False)
GROUP = kernel_group()

def budget():
    return {k: (GROUP/k).read_text().strip() for k in
            ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

report = dict(source_commit=SOURCE, complete=False, cpu_affinity=sorted(os.sched_getaffinity(0)),
              started_at=datetime.now(timezone.utc).isoformat(), before=budget(), scopes=[])
def save():
    (OUTPUT/'report.json').write_text(json.dumps(report, indent=2)+'\n')

PLAN = [
    ('packed-focused', 'scriptw-engine', ['--test','aot_gc_entries'], 'aot_gc_packed_array_storage::', True),
    ('unicode-focused', 'scriptw-engine', ['--test','aot_gc_entries'], 'aot_gc_string_unicode_entries::', True),
    ('realm-focused', 'scriptw-engine', ['--test','aot_realm_modules'], 'aot_created_realm_array_iterator::', True),
    ('snapshot-focused', 'scriptw-engine', ['--test','structure'], 'rooted_completion_graph::', True),
    ('wasm-types-focused', 'scriptw-aot-wasm', ['--lib'], 'gc_types::type_registration_tests::', True),
    ('wasm-runtime-link', 'scriptw-aot-wasm', ['--test','runtime_link'], None, False),
    ('engine-builtins', 'scriptw-engine', ['--test','aot_builtins'], None, False),
    ('engine-gc-entries', 'scriptw-engine', ['--test','aot_gc_entries'], None, False),
    ('engine-realm-modules', 'scriptw-engine', ['--test','aot_realm_modules'], None, False),
    ('engine-language', 'scriptw-engine', ['--test','aot_language'], None, False),
    ('engine-async', 'scriptw-engine', ['--test','aot_async'], None, False),
    ('engine-generators', 'scriptw-engine', ['--test','aot_generators'], None, False),
    ('engine-regexp', 'scriptw-engine', ['--test','aot_regexp'], None, False),
    ('engine-intl', 'scriptw-engine', ['--test','aot_intl'], None, False),
    ('engine-temporal', 'scriptw-engine', ['--test','aot_temporal'], None, False),

    ('engine-structure', 'scriptw-engine', ['--test','structure'], None, False),
    ('engine-lib', 'scriptw-engine', ['--lib'], None, False),
    ('wasm-lib', 'scriptw-aot-wasm', ['--lib'], None, False),
    ('wasm-structure-builtins', 'scriptw-aot-wasm', ['--test','structure_builtins'], None, False),
    ('wasm-structure-language', 'scriptw-aot-wasm', ['--test','structure_language'], None, False),
]
save()
for label, package, target, selection, overlap in PLAN:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
    assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
    args=['cargo','test','--locked','--offline','--release','--jobs','1','--target-dir',str(ROOT/'target/performance-work-20261024/build'),'-p',package,*target,'--message-format=json']
    if selection:
        args.append(selection)
    args+=['--','--test-threads=1']
    stdout, stderr=OUTPUT/(label+'.stdout'), OUTPUT/(label+'.stderr')
    entry=dict(label=label,package=package,target=target,filter=selection,overlaps_full_scope=overlap,
               command=args,stdout=stdout.name,stderr=stderr.name,started_at=datetime.now(timezone.utc).isoformat())
    report['scopes'].append(entry)
    save()
    print(label, 'started', flush=True)
    started=time.monotonic()
    with stdout.open('xb') as out,stderr.open('xb') as err:
        process=subprocess.Popen(args,cwd=ROOT,stdout=out,stderr=err,start_new_session=True)
        try:
            returncode=process.wait(timeout=3600)
        except BaseException:
            if process.poll() is None:
                os.killpg(process.pid,signal.SIGKILL)
            process.wait()
            entry.update(exit_code=process.returncode,interrupted=True,seconds=time.monotonic()-started)
            save()
            raise
    entry.update(exit_code=returncode,seconds=time.monotonic()-started,
                 stdout_sha256=digest(stdout),stderr_sha256=digest(stderr),executables=[])
    text=stdout.read_text()
    for line in text.splitlines():
        if not line.startswith('{'):
            continue
        row=json.loads(line)
        if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('profile',{}).get('test'):
            path=Path(row['executable']).resolve(strict=True)
            entry['executables'].append(dict(path=str(path),sha256=digest(path),bytes=path.stat().st_size,cargo_producer=row))
    entry['test_results']=[dict(passed=int(m[0]),failed=int(m[1]),ignored=int(m[2]),measured=int(m[3]),filtered=int(m[4]))
        for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)]
    save()
    assert returncode==0 and entry['executables'] and len(entry['test_results'])==1, label+' failed; inspect retained streams'
    outcome=entry['test_results'][0]
    assert outcome['passed']>0 and outcome['failed']==0 and outcome['ignored']==0 and outcome['measured']==0
    print(label, outcome, flush=True)
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=budget(),
              passed_disjoint_scopes=sum(x['test_results'][0]['passed'] for x in report['scopes'] if not x['overlaps_full_scope']))
save()
print('complete',report['passed_disjoint_scopes'],'non-overlapping native cases',flush=True)
