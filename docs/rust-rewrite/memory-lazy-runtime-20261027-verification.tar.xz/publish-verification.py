from datetime import datetime, timezone
import hashlib
import json
import lzma
from pathlib import Path, PurePosixPath
import tarfile
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
DEST=ROOT/'docs/rust-rewrite'
STEM='memory-lazy-runtime-20261027'
SOURCE='99a4ff2e962b6efa8066a48447f3c077981c59ec'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
initial=read(BASE/'batch-report.json');resumed=read(BASE/'remaining-verification/report.json')
native=read(BASE/'native-final-report.json');engine=read(BASE/'engine-lib-resume/report.json');conformance=read(BASE/'conformance/report.json')
assert resumed['complete'] and native['complete'] and engine['complete'] and conformance['complete']
assert {x['source_commit'] for x in [initial,resumed,native,engine,conformance]}=={SOURCE}
assert all(x.get('exit_code')==0 for x in initial['commands'][:5])
assert all(x['exit_code']==0 for x in resumed['commands'])
assert native['passed_disjoint_scopes']==4503 and engine['passed']==1040
assert conformance['total']==conformance['passed'] and conformance['total']>0
batch=dict(initial_attempt=initial,resumed_attempt=resumed,original_exit_code=137,original_result='Grouped OOM at the unchanged 4-GiB cap; engine-lib inventory completed with 237 retained passes plus 803 fresh-process cases')
files=set()
def retain(p):
 p=Path(p); assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size<=128*1024**2
 rel=p.relative_to(BASE).as_posix();assert '..' not in PurePosixPath(rel).parts
 with p.open('rb') as stream: assert not stream.read(8).startswith((b'\x7fELF', b'MZ', b'SCRWEP01', b'SCRWWA01'))
 files.add(rel)
for name in ['batch-report.json','native-final-report.json','native-verification/report.json','engine-lib-resume/report.json','remaining-verification/report.json','conformance/report.json','verify-batch.py','verify-native.py','resume-batch.py','resume-engine-lib.py','test262.py','publish-verification.py','check-publication.py','finish-publication.py','review-next-steps.json','cargo-check.stdout','cargo-check.stderr','cargo-check-fixed.stdout','cargo-check-fixed.stderr','oom-scope-journal.txt','engine-lib-frozen/provenance.json','engine-lib-fresh-capacity.stdout','engine-lib-fresh-capacity.stderr','resume-engine-lib.stdout','resume-engine-lib.stderr','resume-batch.stdout','resume-batch.stderr']:
 retain(BASE/name)
def streams(rows,directory):
 for row in rows:
  for ch in ['stdout','stderr']:
   p=BASE/directory/row[ch]
   if ch+'_sha256' in row:assert sha(p)==row[ch+'_sha256']
   retain(p)
streams(initial['commands'],Path())
streams(resumed['commands'],Path())
streams(read(BASE/'native-verification/report.json')['scopes'],Path('native-verification'))
streams(engine['commands'],Path('engine-lib-resume'))
streams(conformance['commands'],Path('conformance'))
retain(BASE/'conformance/executions')
assert sha(BASE/'conformance/executions')==conformance['execution_list_sha256']
for row in conformance['snapshots']:
 p=BASE/'conformance'/row['file'];assert sha(p)==row['sha256'];retain(p)
for p in (BASE/'conformance/snapshots').rglob('*'):
 if p.is_file():retain(p)
for folder in ['source-guards','source-guards-final','source-guards-complete','source-guards-sealed']:
 for p in (BASE/folder).rglob('*'):
  if p.is_file() and p.name!='source-guards':retain(p)
identities=[dict(path=p,bytes=(BASE/p).stat().st_size,sha256=sha(BASE/p)) for p in sorted(files)]
expanded=sum(x['bytes'] for x in identities)
assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');assert not archive.exists()
with archive.open('xb') as out,lzma.LZMAFile(out,mode='w',format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':6,'dict_size':64*1024**2}]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for row in identities:
   info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=0o644
   with (BASE/row['path']).open('rb') as data:tar.addfile(info,data)
assert archive.stat().st_size<=32*1024**2
record=dict(schema='scriptw-lazy-runtime-memory-verification-v1',source_commit=SOURCE,recorded_at=datetime.now(timezone.utc).isoformat(),batch=batch,native=native,test262=conformance,
 interpretation='Selected source-bound verification; not a full pinned Test262 refresh. Matched performance evidence is published separately. Next-step reviews are source calculations, not measured savings.',
 archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(identities),max_expanded_bytes=2*1024**3,max_member_bytes=128*1024**2),retained_files=identities)
p=DEST/(STEM+'.json');assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(archive=record['archive'],native=native['passed_disjoint_scopes'],test262=conformance['passed']),indent=2))
