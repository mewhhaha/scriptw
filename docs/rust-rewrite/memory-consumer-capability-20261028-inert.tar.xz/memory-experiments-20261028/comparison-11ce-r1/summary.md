# Private shared-host before/after diagnostic

Each host consumes its own trusted images. Inputs and configuration match; sources may differ.
Two reversed rounds; ten warmups and seven measured Stores in each fresh process.
Memory is after-execution process residency, not live JS or allocation totals. No canonical publication.
Suite values are arithmetic means of case medians. Targeted cases remain separate.

| Workload / adapter | Build | Execution ms | RSS MiB | PSS MiB | Private dirty MiB |
| --- | --- | ---: | ---: | ---: | ---: |
| canonical-inputs-17 / scriptw | baseline | 4.054 | 21.398 | 18.880 | 4.530 |
| canonical-inputs-17 / scriptw | candidate | 3.992 | 21.573 | 19.058 | 4.501 |
| canonical-inputs-17 / wasi | baseline | 1.435 | 14.967 | 12.510 | 5.075 |
| canonical-inputs-17 / wasi | candidate | 1.435 | 14.813 | 12.356 | 5.074 |
| targeted-typed-sort-2 / scriptw | baseline | 145.313 | 25.327 | 22.815 | 7.072 |
| targeted-typed-sort-2 / scriptw | candidate | 148.369 | 26.137 | 23.614 | 7.312 |
| sort-reverse-128.js / scriptw | baseline | 0.917 | 20.693 | 18.180 | 3.863 |
| sort-reverse-128.js / scriptw | candidate | 0.887 | 21.475 | 18.973 | 3.840 |
| sort-reverse-128.js / wasi | baseline | 0.090 | 14.906 | 12.432 | 4.951 |
| sort-reverse-128.js / wasi | candidate | 0.091 | 14.645 | 12.176 | 4.953 |
| sort-reverse-512.js / scriptw | baseline | 2.891 | 23.295 | 20.775 | 6.471 |
| sort-reverse-512.js / scriptw | candidate | 2.870 | 23.588 | 21.087 | 6.443 |
| sort-reverse-512.js / wasi | baseline | 0.211 | 14.779 | 12.312 | 5.004 |
| sort-reverse-512.js / wasi | candidate | 0.208 | 14.789 | 12.329 | 5.004 |
| sort-sorted-512.js / scriptw | baseline | 1.524 | 21.361 | 18.843 | 4.197 |
| sort-sorted-512.js / scriptw | candidate | 1.499 | 21.219 | 18.713 | 4.170 |
| sort-sorted-512.js / wasi | baseline | 0.210 | 14.877 | 12.430 | 5.006 |
| sort-sorted-512.js / wasi | candidate | 0.213 | 14.715 | 12.250 | 5.004 |
| to-sorted-512.js / scriptw | baseline | 3.569 | 24.559 | 22.042 | 7.193 |
| to-sorted-512.js / scriptw | candidate | 3.580 | 25.008 | 22.511 | 7.166 |
| to-sorted-512.js / wasi | baseline | 0.229 | 14.812 | 12.358 | 5.016 |
| to-sorted-512.js / wasi | candidate | 0.226 | 14.764 | 12.295 | 5.012 |
| join-1024.js / scriptw | baseline | 1.613 | 21.232 | 18.703 | 3.781 |
| join-1024.js / scriptw | candidate | 1.579 | 20.986 | 18.477 | 3.750 |
| join-1024.js / wasi | baseline | 0.282 | 14.918 | 12.461 | 5.027 |
| join-1024.js / wasi | candidate | 0.285 | 14.846 | 12.381 | 5.025 |
| join-4096.js / scriptw | baseline | 5.526 | 22.799 | 20.289 | 5.521 |
| join-4096.js / scriptw | candidate | 5.310 | 23.330 | 20.801 | 5.492 |
| join-4096.js / wasi | baseline | 0.916 | 15.535 | 13.084 | 5.504 |
| join-4096.js / wasi | candidate | 0.926 | 15.271 | 12.828 | 5.502 |
| join-mixed-1024.js / scriptw | baseline | 1.765 | 20.678 | 18.167 | 3.754 |
| join-mixed-1024.js / scriptw | candidate | 1.781 | 21.303 | 18.789 | 3.727 |
| join-mixed-1024.js / wasi | baseline | 0.188 | 14.836 | 12.365 | 4.959 |
| join-mixed-1024.js / wasi | candidate | 0.185 | 14.734 | 12.264 | 4.959 |
| numeric-loop-10000.js / scriptw | baseline | 0.959 | 19.299 | 16.768 | 3.148 |
| numeric-loop-10000.js / scriptw | candidate | 0.952 | 19.506 | 17.005 | 3.115 |
| numeric-loop-10000.js / wasi | baseline | 0.073 | 14.211 | 11.764 | 4.287 |
| numeric-loop-10000.js / wasi | candidate | 0.071 | 14.078 | 11.606 | 4.287 |
| numeric-loop-50000.js / scriptw | baseline | 3.287 | 19.246 | 16.730 | 3.146 |
| numeric-loop-50000.js / scriptw | candidate | 3.345 | 19.477 | 16.959 | 3.121 |
| numeric-loop-50000.js / wasi | baseline | 0.142 | 14.168 | 11.701 | 4.289 |
| numeric-loop-50000.js / wasi | candidate | 0.149 | 14.064 | 11.624 | 4.289 |
| folded-string-4096.js / scriptw | baseline | 1.318 | 19.654 | 17.125 | 3.295 |
| folded-string-4096.js / scriptw | candidate | 1.282 | 19.633 | 17.104 | 3.268 |
| folded-string-4096.js / wasi | baseline | 0.427 | 14.090 | 11.647 | 4.301 |
| folded-string-4096.js / wasi | candidate | 0.433 | 13.924 | 11.472 | 4.305 |
| dynamic-string-4096.js / scriptw | baseline | 1.558 | 19.830 | 17.321 | 3.475 |
| dynamic-string-4096.js / scriptw | candidate | 1.548 | 20.127 | 17.607 | 3.451 |
| dynamic-string-4096.js / wasi | baseline | 0.175 | 14.135 | 11.693 | 4.287 |
| dynamic-string-4096.js / wasi | candidate | 0.174 | 14.072 | 11.622 | 4.289 |
| integer.js / scriptw | baseline | 2.284 | 19.998 | 17.503 | 3.172 |
| integer.js / scriptw | candidate | 2.301 | 19.658 | 17.126 | 3.146 |
| integer.js / wasi | baseline | 0.053 | 14.197 | 11.725 | 4.289 |
| integer.js / wasi | candidate | 0.053 | 14.039 | 11.587 | 4.287 |
| objects.js / scriptw | baseline | 1.295 | 20.562 | 18.074 | 3.586 |
| objects.js / scriptw | candidate | 1.256 | 20.838 | 18.328 | 3.562 |
| objects.js / wasi | baseline | 0.402 | 14.941 | 12.491 | 5.074 |
| objects.js / wasi | candidate | 0.403 | 14.809 | 12.351 | 5.074 |
| retained-objects.js / scriptw | baseline | 33.338 | 24.988 | 22.466 | 7.375 |
| retained-objects.js / scriptw | candidate | 32.651 | 25.025 | 22.496 | 7.314 |
| retained-objects.js / wasi | baseline | 20.625 | 20.783 | 18.329 | 10.818 |
| retained-objects.js / wasi | candidate | 20.607 | 20.525 | 18.079 | 10.816 |
| join-empty-1024.js / scriptw | baseline | 2.258 | 21.846 | 19.299 | 4.941 |
| join-empty-1024.js / scriptw | candidate | 2.230 | 21.588 | 19.086 | 4.920 |
| join-empty-1024.js / wasi | baseline | 0.171 | 14.836 | 12.387 | 4.873 |
| join-empty-1024.js / wasi | candidate | 0.162 | 14.527 | 12.084 | 4.875 |
| join-singleton-1024.js / scriptw | baseline | 2.343 | 21.908 | 19.383 | 5.035 |
| join-singleton-1024.js / scriptw | candidate | 2.344 | 21.879 | 19.354 | 5.012 |
| join-singleton-1024.js / wasi | baseline | 0.089 | 14.111 | 11.650 | 4.289 |
| join-singleton-1024.js / wasi | candidate | 0.088 | 14.055 | 11.587 | 4.289 |
| join-small-1024.js / scriptw | baseline | 2.465 | 21.824 | 19.287 | 5.055 |
| join-small-1024.js / scriptw | candidate | 2.454 | 22.109 | 19.577 | 5.027 |
| join-small-1024.js / wasi | baseline | 0.118 | 14.297 | 11.839 | 4.295 |
| join-small-1024.js / wasi | candidate | 0.115 | 13.965 | 11.516 | 4.295 |
| typed-sort-callback.js / scriptw | baseline | 187.729 | 25.686 | 23.171 | 7.186 |
| typed-sort-callback.js / scriptw | candidate | 190.732 | 26.982 | 24.462 | 7.850 |
| typed-sort-default.js / scriptw | baseline | 102.898 | 24.969 | 22.458 | 6.959 |
| typed-sort-default.js / scriptw | candidate | 106.005 | 25.291 | 22.765 | 6.773 |
