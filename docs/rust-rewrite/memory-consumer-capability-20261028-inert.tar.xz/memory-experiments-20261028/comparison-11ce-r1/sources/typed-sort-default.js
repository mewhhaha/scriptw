var sum = 0;
for (var pass = 0; pass < 20; ++pass) {
  var values = new Float64Array(1024);
  for (var i = 0; i < values.length; ++i) values[i] = values.length - i - 1;
  values.sort();
  sum += values[0] + values[values.length - 1];
}
print(sum);
