#!/usr/bin/env python3
"""Private local before/after diagnostic; never execute when imported.

Run only under limited_verification.py after native builds have stopped. Each
host consumes its own trusted producer images, so source revisions/layouts may
differ; the input fixtures, raw Scriptc Wasm and runtime configuration must not.
Hashes bind these local producers and measurements, not native-code authority.
"""
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import shutil
import statistics
import sys

BASE = Path(__file__).resolve().parent
REPOSITORY = BASE.parents[1]
SCRIPTS = REPOSITORY / 'scripts'
FIXTURES = BASE / 'fixtures'
ORIGINAL = REPOSITORY / 'target/benchmark-refresh-20261028/github-40674504933-scored/precompiled-evidence'
sys.path.insert(0, str(SCRIPTS))
spec = importlib.util.spec_from_file_location('consumer_capability', SCRIPTS / 'benchmark-consumer-capability.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
shared, budget = helper.shared, helper.budget
require, read_json, write_json = helper.require, helper.read_json, helper.write_json
VARIANTS = ('baseline', 'candidate')
TARGETED = {'typed-sort-callback.js', 'typed-sort-default.js'}
COHORT = 'scriptw-local-shared-host-before-after-diagnostic-v1'
MEMORY = shared.MEMORY_FIELDS


def stamp():
    return datetime.now(timezone.utc).isoformat()


def receipt(path):
    path = Path(path).resolve(strict=True)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=shared.digest(path))


def native_identity(raw, host, reference=None):
    require(raw.get('schema') == 'scriptw-precompiled-shared-host-v1'
            and raw.get('adapter') == 'shared', 'expected the ordinary shared host identity')
    require(all(shared._hex(raw.get(k), n) for k, n in
                [('source_commit', 40), ('source_fingerprint', 64), ('executable_sha256', 64)])
            and isinstance(raw.get('compiler_identity_scheme'), str), 'invalid source/executable identity')
    require(raw['executable_sha256'] == host['sha256'], 'host differs from its frozen producer receipt')
    config = raw.get('shared_configuration', {})
    require(all(config.get(k) == v for k, v in shared.SHARED_CONFIGURATION.items())
            and isinstance(config.get('target_triple'), str) and config['target_triple'],
            'shared host runtime configuration differs from the paired policy')
    expected = dict(source_commit=raw['source_commit'], source_fingerprint=raw['source_fingerprint'],
                    source_fingerprint_scheme=raw['compiler_identity_scheme'], shared_configuration=config,
                    tools=dict(consumer=host))
    shared._identity(raw, expected)
    if reference is not None:
        require(config == reference['shared_configuration']
                and raw['compiler_identity_scheme'] == reference['compiler_identity_scheme'],
                'before/after hosts must use the same configuration and source identity scheme')
    return expected


def inventory():
    manifest = read_json(FIXTURES / 'manifest.json')
    original = read_json(ORIGINAL / 'sources/manifest.json')
    canonical = original['execution']
    cases = manifest['execution']
    require(len(canonical) == 17 and len(cases) == 19
            and len({c['file'] for c in cases}) == 19
            and cases[:17] == canonical and {c['file'] for c in cases[17:]} == TARGETED,
            'expected the original 17 cases followed by precisely two TypedArray diagnostics')
    inputs = [receipt(FIXTURES / 'manifest.json'), receipt(ORIGINAL / 'sources/manifest.json')]
    for case in cases:
        require(Path(case['file']).name == case['file'] and isinstance(case['stdout'], str),
                'invalid fixture record')
        source = receipt(FIXTURES / case['file'])
        original_source = receipt((ORIGINAL / 'sources' if case['file'] not in TARGETED else
                                  REPOSITORY / 'target/allocation-memory-20261028') / case['file'])
        require(source['sha256'] == original_source['sha256'], 'original fixture source differs')
        case['source_sha256'] = source['sha256']
        case['group'] = 'targeted-typed-sort-2' if case['file'] in TARGETED else 'canonical-inputs-17'
        case['adapters'] = ['scriptw'] if case['file'] in TARGETED else ['scriptw', 'wasi']
        inputs += [source, original_source]
    return cases, inputs


def measurement_plan(cases):
    first = [dict(round=0, file=case['file'], adapter=adapter, variant=variant)
             for index, case in enumerate(cases)
             for adapter_index, adapter in enumerate(case['adapters'])
             for variant in (VARIANTS if (index + adapter_index) % 2 == 0 else VARIANTS[::-1])]
    return first + [dict(step, round=1) for step in reversed(first)]


def admit_side(directory, cases, output, variant, reference=None):
    directory = directory.resolve(strict=True)
    host = receipt(directory / 'host')
    identity_path = directory / 'identity.stdout'
    identity = read_json(identity_path)
    expected = native_identity(identity, host, reference)
    inputs = [host, receipt(identity_path)]
    shutil.copyfile(identity_path, output / f'{variant}-producer-identity.json')
    images = {}
    for adapter in ('scriptw', 'wasi'):
        selected = [c for c in cases if adapter in c['adapters']]
        producer_path = directory / adapter / 'producer.json'
        producer = read_json(producer_path)
        shared._identity(producer, expected)
        require(producer.get('shared_configuration') == expected['shared_configuration'],
                'producer shared configuration differs')
        require(len(producer['cases']) == len(selected)
                and {c['file'] for c in producer['cases']} == {c['file'] for c in selected},
                'producer case inventory differs')
        if adapter == 'scriptw':
            require(producer.get('compiler_enabled') is True
                    and producer.get('schema') == 'scriptw-precompiled-producer-v1',
                    'Scriptw native producer receipt is missing')
        inputs.append(receipt(producer_path))
        shutil.copyfile(producer_path, output / f'{variant}-{adapter}-producer.json')
        images[adapter] = helper.admit_images(directory / adapter, selected,
                            shared.digest(FIXTURES / 'manifest.json'), identity, adapter)
        for row in producer['cases']:
            image = images[adapter][row['file']]
            require(all(row.get(k) == image[v] for k, v in
                        [('image_bytes', 'bytes'), ('program_wasm_bytes', 'program_wasm_bytes'),
                         ('native_serialized_bytes', 'native_serialized_bytes')]),
                    'producer image lengths differ from actual framing')
            if adapter == 'wasi':
                shared._identity(row, expected)
                require(row.get('shared_configuration') == expected['shared_configuration']
                        and row.get('schema') == 'scriptw-precompiled-wasi-producer-v1'
                        and row.get('compiler_enabled') is True, 'WASI native producer receipt differs')
                wasm = ORIGINAL / 'wasm/scriptc' / (row['file'] + '.wasm')
                require(row.get('wasm_sha256') == image['program_wasm_sha256'], 'WASI source hash differs')
            else:
                wasm = (directory / adapter / shared.safe_name(row['wasm'])).resolve(strict=True)
                require(wasm.is_relative_to(directory / adapter), 'raw program escaped producer directory')
                for field in ('execution_facts_bytes', 'execution_facts_sha256'):
                    require(row.get(field) == image.get(field), 'producer execution registry differs')
            wasm_receipt = receipt(wasm)
            require(wasm_receipt['sha256'] == image['program_wasm_sha256']
                    and wasm_receipt['bytes'] == image['program_wasm_bytes'],
                    'image raw Wasm differs from its original producer input')
            inputs += [receipt(image['path']), wasm_receipt]
    return dict(directory=str(directory), host=host, identity=identity,
                validation=expected, images=images), inputs


def summarize(attempts, cases):
    rows = []
    for case in cases:
        for adapter in case['adapters']:
            row = dict(file=case['file'], group=case['group'], adapter=adapter)
            for variant in VARIANTS:
                selected = [a for a in attempts if a['file'] == case['file']
                            and a['adapter'] == adapter and a['variant'] == variant]
                if len(selected) != 2 or not all(a['admitted'] for a in selected):
                    row[variant] = dict(status='failed', samples=0)
                    continue
                observations = [v for a in selected for v in a['measured']]
                med = statistics.median
                row[variant] = dict(status='ok', samples=len(observations),
                    execution_ms=med(v['phases_ns']['execution'] for v in observations) / 1e6,
                    lifecycle={phase: {key: med(v['process_snapshots'][phase][key] for v in observations)
                                       for key in MEMORY} for phase in shared.PROCESS_PHASES},
                    phases_ms={phase: med(v['phases_ns'][phase] for v in observations) / 1e6
                               for phase in shared.TIME_PHASES},
                    gc_capacity_before_bytes=med(v['gc_capacity_before_bytes'] for v in observations),
                    gc_capacity_after_bytes=med(v['gc_capacity_after_bytes'] for v in observations))
                row[variant].update(row[variant]['lifecycle']['after_execution'])
            if all(row[v]['status'] == 'ok' for v in VARIANTS):
                row['candidate_over_baseline'] = {key: row['candidate'][key] / row['baseline'][key]
                    for key in ('execution_ms', *MEMORY) if row['baseline'][key] > 0}
            rows.append(row)
    suites = []
    for group, adapter in [('canonical-inputs-17', 'scriptw'), ('canonical-inputs-17', 'wasi'),
                           ('targeted-typed-sort-2', 'scriptw')]:
        selected = [r for r in rows if r['group'] == group and r['adapter'] == adapter]
        suite = dict(group=group, adapter=adapter, cases=len(selected),
                     aggregation='arithmetic mean of per-case medians; ratios use geometric mean of paired case ratios')
        for variant in VARIANTS:
            if not all(r[variant]['status'] == 'ok' for r in selected):
                suite[variant] = dict(status='failed')
                continue
            suite[variant] = dict(status='ok', **{key: statistics.fmean(r[variant][key] for r in selected)
                    for key in ('execution_ms', *MEMORY)},
                    lifecycle={phase: {key: statistics.fmean(r[variant]['lifecycle'][phase][key]
                                for r in selected) for key in MEMORY} for phase in shared.PROCESS_PHASES})
        if all(suite[v]['status'] == 'ok' for v in VARIANTS):
            suite['geometric_mean_candidate_over_baseline'] = {
                key: statistics.geometric_mean(r['candidate_over_baseline'][key] for r in selected)
                for key in ('execution_ms', *MEMORY)
                if all(key in r['candidate_over_baseline'] and r['candidate_over_baseline'][key] > 0
                       for r in selected)}
        suites.append(suite)
    return rows, suites


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('baseline-dir', 'candidate-dir', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--timeout', type=int, default=600)
    args = parser.parse_args()
    require(args.timeout > 0, 'timeout must be positive')
    budget.require_kernel_budget(4 * 1024**3)
    require(len(os.sched_getaffinity(0)) == 1, 'one CPU affinity required')
    require(not any(key in os.environ for key in shared.PHASE_BARRIER_ENV), 'phase barriers must be absent')
    output = args.output.resolve()
    require(output.is_relative_to(BASE) and output != BASE, 'output must remain in the private evidence directory')
    output.mkdir(parents=True, exist_ok=False)
    report = dict(schema=COHORT, comparison_cohort=COHORT, excluded_from_scored_cohorts=True,
                  excluded_from_ordinary_cohorts=True, canonical_publication=False,
                  started_at=stamp(), finished=False, passed=False, warmups=10, samples=7, rounds=2,
                  scope='local same-input before/after: each source owns its corresponding native P/R images; process endpoints are not live heap, allocation counters or peak',
                  allocation_metrics_available=False,
                  resources=dict(cpu_affinity=sorted(os.sched_getaffinity(0)), before=helper.resources()),
                  commands=[], attempts=[], failures=[], sides={}, inputs=[])
    save = lambda: write_json(output / 'report.json', report)
    save()
    environment = budget.limited_environment()

    def command(argv, **metadata):
        row = dict(argv=argv, started_at=stamp(), **metadata)
        index = len(report['commands'])
        report['commands'].append(row)
        save()
        try:
            row.update(helper.execute(argv, output, index, args.timeout, environment))
        finally:
            row['finished_at'] = stamp()
            for field in ('stdout', 'stderr'):
                path = output / f'{index:03}.{field}'
                if path.exists():
                    row[field] = path.name
                    row[field + '_sha256'] = shared.digest(path)
            save()
        require(row['returncode'] == 0 and not row['timed_out'], 'process failed or exceeded deadline')
        require((output / row['stderr']).stat().st_size == 0, 'unexpected host stderr')
        return read_json(output / row['stdout']), index

    try:
        cases, inputs = inventory()
        report['cases'] = cases
        report['manifest_sha256'] = shared.digest(FIXTURES / 'manifest.json')
        report['inputs'] = inputs + [receipt(path) for path in
            (Path(__file__), SCRIPTS / 'benchmark-consumer-capability.py',
             SCRIPTS / 'precompiled_comparison.py', SCRIPTS / 'limited_verification.py')]
        sources = output / 'sources'; sources.mkdir()
        for name in ('manifest.json', *[case['file'] for case in cases]):
            shutil.copyfile(FIXTURES / name, sources / name)
        shutil.copyfile(ORIGINAL / 'sources/manifest.json', output / 'original-manifest.json')
        for variant in VARIANTS:
            side, inputs = admit_side(getattr(args, variant + '_dir'), cases, output, variant,
                report['sides']['baseline']['identity'] if variant == 'candidate' else None)
            report['sides'][variant] = side
            report['inputs'] += inputs
        # Admit both complete inventories before executing either native host.
        save()
        for variant, side in report['sides'].items():
            actual, _ = command([side['host']['path'], 'identity'], kind='identity', variant=variant)
            native_identity(actual, side['host'], side['identity'])
            require(actual == side['identity'], 'actual frozen host identity differs from its producer receipt')
        report['plan'] = measurement_plan(cases)
        require(len(report['plan']) == 144, 'unexpected full diagnostic inventory')
        save()
        by_name = {case['file']: case for case in cases}
        for step in report['plan']:
            side = report['sides'][step['variant']]
            image = side['images'][step['adapter']][step['file']]
            case = by_name[step['file']]
            attempt = dict(step, admitted=False, command_index=len(report['commands']))
            report['attempts'].append(attempt)
            save()
            try:
                raw, _ = command([side['host']['path'], 'execute-' + step['adapter'],
                                  image['path'], case['stdout'], '7', '10'], kind='execute', **step)
                observations, matched = shared._consumer(raw, side['validation'], image, case,
                    'scriptw' if step['adapter'] == 'scriptw' else 'scriptc')
                require(matched, 'at least one original warmup or measurement output/completion differs')
                attempt.update(admitted=True, measured=observations[10:])
            except (ValueError, KeyError, OSError, TypeError) as error:
                attempt['failure'] = str(error)
                report['failures'].append(dict(step, error=str(error)))
            save()
            print(json.dumps({k: v for k, v in attempt.items() if k != 'measured'}), flush=True)
        for original in report['inputs']:
            require(receipt(original['path']) == original, 'admitted input changed during the diagnostic: ' + original['path'])
        report['resources']['after'] = helper.resources()
        shared._resources(dict(resources=report['resources'],
                          machine=dict(measurement_affinity=report['resources']['cpu_affinity'])))
        report['rows'], report['suites'] = summarize(report['attempts'], cases)
        report.update(finished=True, passed=not report['failures'], finished_at=stamp())
    except (ValueError, KeyError, OSError, TypeError) as error:
        report['failures'].append(dict(error=str(error)))
        save()
        raise
    save()
    lines = ['# Private shared-host before/after diagnostic', '',
        'Each host consumes its own trusted images. Inputs and configuration match; sources may differ.',
        'Two reversed rounds; ten warmups and seven measured Stores in each fresh process.',
        'Memory is after-execution process residency, not live JS or allocation totals. No canonical publication.',
        'Suite values are arithmetic means of case medians. Targeted cases remain separate.', '',
        '| Workload / adapter | Build | Execution ms | RSS MiB | PSS MiB | Private dirty MiB |',
        '| --- | --- | ---: | ---: | ---: | ---: |']
    for row in report['suites'] + report['rows']:
        for variant in VARIANTS:
            value = row[variant]
            cells = ([f'{value["execution_ms"]:.3f}'] + [f'{value[k] / 1024**2:.3f}' for k in MEMORY]
                     if value['status'] == 'ok' else ['failed'] * 4)
            lines.append('| ' + ' | '.join([row.get('file', row['group']) + ' / ' + row['adapter'], variant, *cells]) + ' |')
    (output / 'summary.md').write_text('\n'.join(lines) + '\n')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError, TypeError) as error:
        raise SystemExit('shared-host-before-after: ' + str(error))
