"""Prepared private verification driver; never autoruns when imported.

Run only after the other native build has ended, through limited_verification.py.
The 19 native targets retain their predecessor inventories, except one explicitly
retired prose assertion. CLI functions/typed_array are separate selected scopes.
Fresh actual inventories determine counts; focused IDs run once, before broad
remainders. A failed attempt keeps its original command streams and report.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPOSITORY = BASE.parents[1]
DEFAULT_WORKSPACE = BASE / 'baseline-source'
BUILD = REPOSITORY / 'target/performance-work-20261024/build'
REVIEWED_ANCESTOR = 'b0e90430825e4dbf058a4146ebe3ad0b647e098b'
PREDECESSOR = REPOSITORY / 'target/memory-runtime-error-tail-20261028-evidence/native-0658e6ae6/report.json'
PREDECESSOR_SHA = '0c8cbfa506606123b3a25b86c6bbcb299d8a3fdf14bdc956c66984366baa2e83'
HELPERS = REPOSITORY / 'target/memory-runtime-error-tail-20261028-evidence/native-runtime-error-tail-r1.py'
HELPERS_SHA = '194b6921c0312d51d69e0f78e1d616d9039e9b699c8c35643d039ea1953b6a43'
MIB = 1024**2
FEATURES = ['scriptw-engine/native-source-compiler']
PLAN = [
    ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib'),
    ('scriptw-engine', 'aot_realm_modules', 'test'),
    ('scriptw-engine', 'scriptw_engine', 'lib'),
    ('scriptw-aot-wasm', 'emission', 'test'),
    ('scriptw-engine', 'aot_regexp', 'test'),
    ('scriptw-engine', 'aot_gc_entries', 'test'),
    ('scriptw-aot-wasm', 'modules_realms', 'test'),
    ('scriptw-aot-wasm', 'intl_temporal', 'test'),
    ('scriptw-aot-wasm', 'runtime_link', 'test'),
    ('scriptw-aot-wasm', 'structure_builtins', 'test'),
    ('scriptw-engine', 'structure', 'test'),
    ('scriptw-engine', 'aot_language', 'test'),
    ('scriptw-engine', 'aot_generators', 'test'),
    ('scriptw-engine', 'aot_intl', 'test'),
    ('scriptw-engine', 'aot_builtins', 'test'),
    ('scriptw-engine', 'aot_temporal', 'test'),
    ('scriptw-engine', 'aot_async', 'test'),
    ('scriptw-aot-wasm', 'structure_language', 'test'),
    ('scriptw-aot-wasm', 'structure_async', 'test'),
]
REMOVED = {
    ('scriptw-aot-wasm', 'structure_builtins', 'test'): {
        'regexp_unicode_sets_class_strings_structure::verified_status_preserves_baseline_and_exact_scope'
    },
}
AOT_FOCUS_OWNERS = ('typed_array_sort_snapshots', 'ordered_bootstrap_allocation',
                    'intrinsic_accessor_allocation')
CLI_FOCUS = {
    'functions': 'run_wasm_backend_preserves_lazy_native_function_source',
    'typed_array': 'run_wasm_backend_keeps_typedarray_sort_snapshots_across_arguments_mutation_and_gc',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def source_tests(path, prefix):
    names = re.findall(r'#\[test\]\s*(?:#\[[^\n]+\]\s*)*fn\s+(\w+)\s*\(', path.read_text())
    require(names and len(names) == len(set(names)), 'source test owner is empty/ambiguous: ' + str(path))
    return sorted(prefix + name for name in names)


def no_other_native_builder():
    active = []
    for item in Path('/proc').iterdir():
        if not item.name.isdigit():
            continue
        try:
            if item.stat().st_uid == os.getuid():
                name = (item / 'comm').read_text().strip()
                if name in ('cargo', 'rustc', 'rust-lld', 'lld', 'ld.lld'):
                    active.append((int(item.name), name))
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            pass
    require(not active, 'another native builder is active; do not compile concurrently: ' + repr(active))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument('--expected-source', required=True, help='exact clean candidate SHA, including any later compile fix')
    parser.add_argument('--output', type=Path, required=True, help='new directory beneath this evidence parent')
    args = parser.parse_args()
    root = args.workspace.resolve(strict=True)
    source_sha = args.expected_source
    require(re.fullmatch('[0-9a-f]{40}', source_sha), 'expected source must be a complete SHA')
    output = args.output.resolve()
    require(output.is_relative_to(BASE) and output != BASE and not output.exists(), 'fresh private output required')
    require(sha(HELPERS) == HELPERS_SHA, 'reviewed bounded command helper changed')
    output.mkdir(parents=True, exist_ok=False)
    helper_copy = output / 'bounded_command_helpers.py'
    shutil.copyfile(HELPERS, helper_copy)
    require(sha(helper_copy) == HELPERS_SHA, 'helper copy differs')
    helper = load_module(helper_copy, 'memory_experiments_bounded_helpers')
    sys.path.insert(0, str(root / 'scripts'))
    from limited_verification import kernel_group, require_kernel_budget
    from native_test_protocol import parse_inventory, result_summaries

    report = dict(schema='scriptw-memory-experiments-native-verification-v1', complete=False,
                  source_commit=source_sha, reviewed_ancestor=REVIEWED_ANCESTOR,
                  source_checkout=str(root), build_directory=str(BUILD), started_at=helper.stamp(),
                  driver_sha256=sha(Path(__file__)), bounded_helper_sha256=HELPERS_SHA,
                  commands=[], scopes=[], cli_families=[], features=FEATURES,
                  default_features=False, predecessor_binary_reuse=False, inherited_passes=0,
                  plan=[dict(package=p, target=t, kind=k) for p, t, k in PLAN],
                  scope='19 complete native target inventories plus CLI functions:: and typed_array:: only; oracle disabled, native-source capability enabled. Focused tests are counted once. No full CLI, Test262, ignored docs or all-feature acceptance claim.')
    helper.save(output, report)
    live_cli = None

    def source():
        require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == source_sha,
                'isolated checkout differs from expected source')
        require(not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=normal'], cwd=root),
                'source checkout must be clean, including untracked inputs')

    def scope(*, check_cli=False):
        require_kernel_budget(4 * 1024**3)
        require(len(os.sched_getaffinity(0)) == 1, 'native verification requires one CPU')
        require(all(os.environ.get(key) == '1' for key in
                    ('CARGO_BUILD_JOBS', 'RUST_TEST_THREADS', 'SCRIPTW_JOBS', 'RAYON_NUM_THREADS')),
                'Cargo, libtest and native compilation workers must remain serial')
        require(os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES') == '1'
                and os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES') == str(64 * MIB),
                'retained module cache must remain one entry / 64 MiB')
        require(os.environ.get('SCRIPTW_EXPECTED_SOURCE') == source_sha, 'expected-source environment differs')
        if check_cli and live_cli is not None:
            require(sha(live_cli[0]) == live_cli[1], 'CLI executable embedded in test harness changed')

    def budget():
        group = kernel_group()
        return {key: (group / key).read_text().strip() for key in
                ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}

    def run(label, command, cwd=root, *, timeout=3600, cargo=False, test_ids=None, check_cli=False):
        source()
        scope(check_cli=check_cli)
        require(sha(PREDECESSOR) == PREDECESSOR_SHA and sha(helper_copy) == HELPERS_SHA,
                'admitted evidence/helper changed')
        row = dict(label=label, command=list(map(str, command)), cwd=str(cwd),
                   stdout=label + '.stdout', stderr=label + '.stderr')
        if test_ids is not None:
            row['expected_test_ids'] = list(test_ids)
        report['commands'].append(row)
        helper.save(output, report)
        print(label, 'started', flush=True)
        try:
            helper.run_command(row, output, timeout=timeout,
                               stdout_limit=(128 if cargo else 4) * MIB,
                               stderr_limit=(32 if cargo else 4) * MIB)
        finally:
            try:
                if test_ids is not None and (output / row['stdout']).exists():
                    text = (output / row['stdout']).read_text()
                    row['reported_passing_test_ids'] = [name.removesuffix(' - should panic') for name in
                        re.findall(r'^test ([^\r\n]+) \.\.\. ok$', text, re.M)]
                    row['reported_result_summaries'] = result_summaries(text)
            finally:
                helper.save(output, report)
        source()
        scope(check_cli=check_cli)
        helper.no_oom(report['before'], budget())
        require(row.get('exit_code') == 0 and not row['timed_out'] and not row['output_limit_exceeded']
                and not row.get('pipe_cleanup_incomplete'), label + ' failed; original streams retained')
        print(label, 'finished', flush=True)
        return row, (output / row['stdout']).read_text()

    def cargo_records(label, command):
        no_other_native_builder()
        _, text = run(label, command, timeout=10800, cargo=True)
        rows = [json.loads(line) for line in text.splitlines()]
        require(rows and rows[-1] == dict(reason='build-finished', success=True)
                and sum(row.get('reason') == 'build-finished' for row in rows) == 1,
                'Cargo did not report one successful build closure')
        require(all('spec-exec-oracle' not in row.get('features', [])
                    and row.get('target', {}).get('name') not in ('boa_engine', 'scriptw_spec_exec')
                    for row in rows), 'developer interpreter unexpectedly entered selected Cargo graph')
        return rows

    def producer(rows, package, target, kind, test):
        prefix = 'path+file://' + str(root / 'crates' / package) + '#'
        found = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')
                 and row['package_id'].startswith(prefix) and row['target']['name'] == target
                 and row['target']['kind'] == [kind] and row['profile']['test'] is test]
        require(len(found) == 1, 'missing/ambiguous actual Cargo producer: ' + package + '/' + target)
        found = found[0]
        expected_features = ['native-source-compiler'] if package == 'scriptw-engine' else []
        require(found['features'] == expected_features and found['profile']['opt_level'] == '3',
                'Cargo producer features/profile differ: ' + package + '/' + target)
        require(Path(found['target']['src_path']).resolve().is_relative_to(root / 'crates' / package),
                'Cargo source is outside selected package')
        return found

    def freeze(selected, name):
        original = Path(selected['executable'])
        require(original.resolve() == original and original.is_relative_to(BUILD)
                and stat.S_ISREG(original.lstat().st_mode), 'Cargo executable must be regular in selected build directory')
        original_sha = sha(original)
        directory = output / name
        directory.mkdir()
        binary = directory / 'executable'
        with original.open('rb') as src, binary.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        binary.chmod(0o500)
        require(sha(binary) == original_sha == sha(original) and binary.stat().st_nlink == 1
                and binary.stat().st_mode & 0o222 == 0, 'frozen executable differs/is writable/shared')
        return binary, original_sha

    def execute(target, binary, ids, label, phase):
        require(ids and len(ids) == len(set(ids)) and set(ids) <= set(target['inventory']), 'empty/invalid exact IDs')
        require(not set(ids).intersection(target['passed_test_ids']), 'native ID would run twice')
        row, text = run(label, [binary, '--exact', '--include-ignored', '--test-threads=1', '--color=never', *ids],
                        root / 'crates' / target['package'], test_ids=ids, check_cli=target['package'] == 'scriptw-cli')
        passed = row['reported_passing_test_ids']
        require(len(passed) == len(set(passed)) == len(ids) and set(passed) == set(ids), 'passing exact-name IDs differ')
        total = target.get('full_target_inventory_count', len(target['inventory']))
        require(result_summaries(text) == [('ok', str(len(ids)), '0', '0', '0', str(total - len(ids)))],
                'terminal summary differs from actual target inventory')
        target['passed_test_ids'] += sorted(passed)
        target[phase + '_test_ids'] += sorted(passed)
        target['passed'] = len(target['passed_test_ids'])
        helper.save(output, report)

    def finish_scope(target, binary, *, chunk_size=None):
        remaining = [name for name in target['inventory'] if name not in set(target['focused_test_ids'])]
        size = chunk_size or max(1, len(remaining))
        for offset in range(0, len(remaining), size):
            execute(target, binary, remaining[offset:offset + size], target['label'] + f'-broad-{offset:04d}', 'broad')
        require(len(target['passed_test_ids']) == len(set(target['passed_test_ids'])) == len(target['inventory'])
                and set(target['passed_test_ids']) == set(target['inventory'])
                and sha(binary) == target['executable_sha256'], 'scope coverage/executable closure differs')
        target['complete'] = True
        helper.save(output, report)

    def target_row(package, target, kind, selected, binary, digest, label):
        return dict(package=package, target=target, kind=kind, label=label, cargo_producer=selected,
                    binary=str(binary.relative_to(output)), executable_sha256=digest, complete=False,
                    passed=0, passed_test_ids=[], focused_test_ids=[], broad_test_ids=[])

    try:
        scope()
        source()
        report.update(cpu_affinity=sorted(os.sched_getaffinity(0)), before=budget())
        require(Path(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], cwd=root, text=True).strip()).resolve() == root,
                'workspace must be the checkout root')
        require(subprocess.run(['git', 'merge-base', '--is-ancestor', REVIEWED_ANCESTOR, source_sha], cwd=root).returncode == 0,
                'candidate must retain reviewed change ancestry')
        require(sha(PREDECESSOR) == PREDECESSOR_SHA, 'predecessor receipt changed')
        old = json.loads(PREDECESSOR.read_text())
        baseline = {(row['package'], row['target'], row['kind']): row for row in old['scopes']}
        require(old['complete'] and len(old['scopes']) == len(baseline) == len(PLAN) == 19
                and set(baseline) == set(PLAN), 'complete exact predecessor target set required')
        for row in baseline.values():
            require(row['complete'] and len(row['inventory']) == len(set(row['inventory'])) == row['passed'],
                    'predecessor has incomplete scope')
        require(old['passed_disjoint_scopes'] == sum(row['passed'] for row in baseline.values()),
                'predecessor aggregate differs from actual inventories')
        report['predecessor'] = dict(path=str(PREDECESSOR), sha256=PREDECESSOR_SHA,
                                    source_commit=old['source_commit'], inventory_total=old['passed_disjoint_scopes'],
                                    inherited_passes=0)
        require(subprocess.run(['git', 'merge-base', '--is-ancestor', old['source_commit'], source_sha], cwd=root).returncode == 0,
                'predecessor is not an ancestor of selected source')
        focus = []
        for owner in AOT_FOCUS_OWNERS:
            focus += source_tests(root / 'crates/scriptw-aot-wasm/src/tests' / (owner + '.rs'), 'tests::' + owner + '::')
        report['focused_aot_ids'] = focus
        cli_source_ids = {family: source_tests(root / 'crates/scriptw-cli/tests/cli' / (family + '.rs'), family + '::')
                          for family in CLI_FOCUS}
        for family, name in CLI_FOCUS.items():
            require(family + '::' + name in cli_source_ids[family], 'new CLI fixture is missing from its owner')
        helper.save(output, report)

        common = ['--locked', '--offline', '--release', '--jobs', '1', '--target-dir', BUILD,
                  '--no-default-features', '--features', ','.join(FEATURES)]
        command = ['cargo', 'test', *common, '-p', 'scriptw-engine', '-p', 'scriptw-aot-wasm', '--lib']
        for name in sorted({name for _, name, kind in PLAN if kind == 'test'}):
            command += ['--test', name]
        rows = cargo_records('cargo-native-19', command + ['--no-run', '--message-format=json'])
        frozen = {}
        for key in PLAN:
            package, name, kind = key
            selected = producer(rows, *key, True)
            old_source = Path(baseline[key]['cargo_producer']['target']['src_path'])
            old_root = Path(old['source_checkout'])
            require(Path(selected['target']['src_path']) == root / old_source.relative_to(old_root),
                    'actual native target source changed ownership')
            label = package + '-' + name
            binary, digest = freeze(selected, label)
            target = target_row(*key, selected, binary, digest, label)
            report['scopes'].append(target)
            frozen[key] = target, binary
        selected_native = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')
                           and row['profile']['test'] and any(row['package_id'].startswith('path+file://' + str(root / 'crates' / p) + '#')
                           for p in ('scriptw-engine', 'scriptw-aot-wasm'))]
        require(len(selected_native) == len(PLAN) and all(row in [t['cargo_producer'] for t, _ in frozen.values()]
                                                       for row in selected_native), 'unplanned native test producer')
        for key, (target, binary) in frozen.items():
            _, text = run(target['label'] + '-inventory', [binary, '--list', '--color=never'], root / 'crates' / key[0])
            inventory = parse_inventory(text)
            previous = set(baseline[key]['inventory'])
            removed = previous - set(inventory)
            require(removed == REMOVED.get(key, set()), 'unreviewed missing/reintroduced predecessor IDs: ' + target['label'] + repr(sorted(removed)))
            target.update(inventory=inventory, baseline_inventory_count=len(previous),
                          added_test_ids=sorted(set(inventory) - previous), removed_test_ids=sorted(removed))
            helper.save(output, report)
        report['observed_native_inventory_total'] = sum(len(t['inventory']) for t, _ in frozen.values())
        aot, aot_binary = frozen[PLAN[0]]
        execute(aot, aot_binary, focus, 'aot-changed-allocation-focused', 'focused')
        report['aot_focused_complete'] = True
        helper.save(output, report)

        cli_rows = cargo_records('cargo-cli-test', ['cargo', 'test', *common, '-p', 'scriptw-cli',
                                                  '--test', 'cli', '--no-run', '--message-format=json'])
        cli_producer = producer(cli_rows, 'scriptw-cli', 'cli', 'test', True)
        cli_binary, cli_digest = freeze(cli_producer, 'scriptw-cli-cli')
        bin_rows = cargo_records('cargo-scriptw-bin', ['cargo', 'build', *common, '-p', 'scriptw-cli',
                                                     '--bin', 'scriptw', '--message-format=json'])
        bin_producer = producer(bin_rows, 'scriptw-cli', 'scriptw', 'bin', False)
        scriptw_binary, scriptw_digest = freeze(bin_producer, 'scriptw-cli-scriptw')
        live_cli = (Path(bin_producer['executable']), scriptw_digest)
        report['cli_product'] = dict(cargo_producer=bin_producer, binary=str(scriptw_binary.relative_to(output)),
                                     executable_sha256=scriptw_digest, guarded_compile_time_path=str(live_cli[0]))
        _, text = run('cli-complete-inventory', [cli_binary, '--list', '--color=never'], root / 'crates/scriptw-cli', check_cli=True)
        cli_inventory = parse_inventory(text)
        report['cli_full_inventory'] = cli_inventory
        for family in CLI_FOCUS:
            inventory = [name for name in cli_inventory if name.startswith(family + '::')]
            require(inventory == cli_source_ids[family] and inventory, 'CLI family source/compiled IDs differ: ' + family)
            target = target_row('scriptw-cli', 'cli', 'test', cli_producer, cli_binary, cli_digest, 'cli-' + family)
            target.update(family=family, inventory=inventory, full_target_inventory_count=len(cli_inventory))
            report['cli_families'].append(target)
            execute(target, cli_binary, [family + '::' + CLI_FOCUS[family]], 'cli-' + family + '-focused', 'focused')
        report['focused_complete'] = True
        helper.save(output, report)

        for key, (target, binary) in frozen.items():
            finish_scope(target, binary, chunk_size=8 if key[1] in ('scriptw_engine', 'aot_gc_entries') else None)
        for target in report['cli_families']:
            finish_scope(target, cli_binary, chunk_size=8)
        source()
        scope(check_cli=True)
        report['after'] = budget()
        helper.no_oom(report['before'], report['after'])
        all_scopes = report['scopes'] + report['cli_families']
        require(len(report['scopes']) == 19 and len(report['cli_families']) == 2 and all(t['complete'] for t in all_scopes),
                'selected scope closure differs')
        native_passes = sum(t['passed'] for t in report['scopes'])
        cli_passes = sum(t['passed'] for t in report['cli_families'])
        focused_passes = sum(len(t['focused_test_ids']) for t in all_scopes)
        require(native_passes == report['observed_native_inventory_total'], 'native aggregate differs from actual inventory')
        report.update(complete=True, finished_at=helper.stamp(), passed_disjoint_scopes=native_passes,
                      passed_cli_families=cli_passes, executed_disjoint_passes=native_passes + cli_passes,
                      focused_passes_included=focused_passes,
                      broad_remainder_passes=native_passes + cli_passes - focused_passes,
                      repeated_native_test_ids=0, inherited_disjoint_passes=0)
        return 0
    except BaseException as error:
        report.update(error=str(error), error_type=type(error).__name__, finished_at=helper.stamp())
        return 1
    finally:
        if 'before' in report and 'after' not in report:
            try:
                report['after'] = budget()
                helper.no_oom(report['before'], report['after'])
            except (OSError, ValueError) as error:
                report['resource_after_error'] = str(error)
        helper.save(output, report)
        print(json.dumps(dict(complete=report['complete'], native_passed=report.get('passed_disjoint_scopes'),
                              cli_passed=report.get('passed_cli_families'), error=report.get('error'),
                              output=str(output))), flush=True)


if __name__ == '__main__':
    raise SystemExit(main())
