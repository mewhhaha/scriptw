from pathlib import Path
import hashlib,json,shutil,subprocess,sys
base=Path(__file__).resolve().parent
name=sys.argv[1];host=Path(sys.argv[2]).resolve();out=base/name;out.mkdir(exist_ok=False)
frozen=out/'host';shutil.copy2(host,frozen)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(args,label):
 with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
  p=subprocess.run([str(frozen),*map(str,args)],stdout=stdout,stderr=stderr,timeout=900)
 if p.returncode:raise RuntimeError(f'{label} failed: {p.returncode}')
 return json.loads((out/(label+'.stdout')).read_text())
identity=run(['identity'],'identity')
print(name,identity['source_commit'],identity['source_fingerprint'],flush=True)
fixtures=base/'fixtures'
if not fixtures.exists():
 origin=base.parent/'benchmark-refresh-20261028/github-40674504933-scored/precompiled-evidence/sources'
 shutil.copytree(origin,fixtures)
 manifest=json.loads((fixtures/'manifest.json').read_text())
 for kind in ['callback','default']:
  source=base.parent/f'allocation-memory-20261028/typed-sort-{kind}.js'
  shutil.copy2(source,fixtures/source.name)
  manifest['execution'].append(dict(file=source.name,stdout='20460\n',work='excluded TypedArray allocation diagnostic'))
 (fixtures/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
scriptw=run(['prepare-scriptw',fixtures,out/'scriptw'],'prepare-scriptw')
print(name,'Scriptw images',len(scriptw['cases']),flush=True)
wasi=out/'wasi';wasi.mkdir()
manifest=json.loads((fixtures/'manifest.json').read_text())
wasm=base.parent/'benchmark-refresh-20261028/github-40674504933-scored/precompiled-evidence/wasm/scriptc'
rows=[]
for case in manifest['execution']:
 source=wasm/(case['file']+'.wasm')
 if not source.exists():continue
 report=run(['prepare-wasi',source,wasi/(case['file']+'.swpc')],'wasi-'+case['file'])
 rows.append(dict(report,file=case['file'],stdout=case['stdout'],source_sha256=sha(fixtures/case['file'])))
report=dict(identity,manifest_sha256=sha(fixtures/'manifest.json'),cases=rows)
(wasi/'producer.json').write_text(json.dumps(report,indent=2)+'\n')
print(name,'WASI images',len(rows),flush=True)
