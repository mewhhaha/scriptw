#!/usr/bin/env python3
"""Private, source-bound Test262 replay; invoke under limited_verification.py.

Uses a completed native report's frozen CLI. Lists actual execution variants,
then runs four original suite subtrees serially without building or publishing.
"""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
MIB = 1024**2
SCOPES = (
    ('function-tostring', 'built-ins/Function/prototype/toString'),
    ('typedarray-sort', 'built-ins/TypedArray/prototype/sort'),
    ('typedarray-tosorted', 'built-ins/TypedArray/prototype/toSorted'),
    ('typedarray-inherited-sort', 'built-ins/TypedArrayConstructors/prototype/sort'),
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def execution_ids(text, prefix):
    lines = text.splitlines()
    require(lines and re.fullmatch(r'count: [0-9]+', lines[0]), 'inventory count missing')
    ids = lines[1:]
    require(len(ids) == int(lines[0].split(': ')[1]) > 0, 'zero or truncated inventory')
    require(len(ids) == len(set(ids)), 'duplicate inventory execution IDs')
    for item in ids:
        mode, separator, path = item.partition(':')
        require(separator and mode in ('sloppy-script', 'strict-script', 'raw-script', 'module', 'raw-module')
                and path.startswith(prefix + '/') and path.endswith('.js'),
                'inventory escaped the selected original Test262 subtree: ' + item)
    return ids


def snapshot_result(directory, label, ids, source, binary_hash, pins, scope):
    paths = list(directory.glob('*.json'))
    require(len(paths) == 1, 'expected exactly one scoped snapshot JSON')
    path = paths[0]
    snapshot = read_json(path)
    scope['snapshot'] = dict(path=str(path), sha256=digest(path),
                            identity={key: snapshot.get(key) for key in (
                                'snapshot_version', 'compiler_identity', 'producer',
                                'matrix_strategy_version', 'execution_backend',
                                'pinned_revisions', 'manifest_hash', 'run_kind')},
                            total=snapshot.get('total'), passed=snapshot.get('passed'),
                            counts_per_kind=snapshot.get('counts_per_kind'),
                            counts_per_outcome=snapshot.get('counts_per_outcome'),
                            failures=snapshot.get('failures'),
                            timeout_test_ids=snapshot.get('timeout_test_ids'),
                            completed_test_ids=snapshot.get('completed_test_ids'))
    summary = path.with_suffix('.txt')
    require(summary.is_file(), 'snapshot text summary missing')
    scope['snapshot']['summary'] = dict(path=str(summary), sha256=digest(summary))
    require(path.name == f"{label}-{snapshot['manifest_hash']}.json", 'snapshot family differs')
    require(snapshot.get('snapshot_version') == 8 and snapshot.get('producer') == 'scriptw'
            and snapshot.get('matrix_strategy_version') == 3
            and snapshot.get('execution_backend') == 'wasm-aot', 'snapshot schema/backend differs')
    identity = snapshot.get('compiler_identity', {})
    require(identity.get('source_revision') == dict(kind='git-commit', commit=source)
            and identity.get('executable_sha256') == binary_hash
            and identity.get('source_fingerprint_scheme') == 'scriptw-program-cache-compiler-v3'
            and re.fullmatch('[0-9a-f]{64}', identity.get('source_fingerprint', '')),
            'snapshot does not belong to the frozen CLI/source')
    require(snapshot.get('pinned_revisions') == pins, 'original suite/spec pins differ')
    # The CLI calls an unsharded filtered run "full". Its actual selected IDs,
    # not this label, prove that the receipt covers only the requested subtree.
    require(snapshot.get('run_kind') == 'full' and 'checkpoint_identity' not in snapshot
            and all(snapshot.get(key) == [] for key in
                    ('matrix_path', 'completed_nodes', 'aggregate_entries')),
            'snapshot is incomplete or belongs to a matrix/shard')
    completed = snapshot.get('completed_test_ids')
    require(isinstance(completed, list) and len(completed) == len(set(completed)) == len(ids)
            and set(completed) == set(ids) and snapshot.get('total') == len(ids),
            'completed execution variants differ from the listed selected inventory')
    require(snapshot.get('passed') == len(ids) and snapshot.get('failures') == []
            and snapshot.get('timeout_test_ids') == [], 'scoped Test262 executions did not all pass')
    require(snapshot.get('counts_per_outcome') == dict(Bug=0, Crash=0,
                                                     NotImplemented=0, Success=len(ids)),
            'failure, crash or unimplemented outcome exists')
    kinds = snapshot.get('counts_per_kind')
    require(isinstance(kinds, dict) and set(kinds) == {
        'EarlyError', 'HostHarness', 'Lowering', 'Parser', 'Runtime', 'Unsupported', 'WasmBackend'
    } and all(value == 0 for value in kinds.values()), 'failure-kind counts differ')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-report', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True, help='fresh private evidence directory')
    args = parser.parse_args()
    receipt = args.native_report.resolve(strict=True)
    native = read_json(receipt)
    require(native.get('schema') == 'scriptw-memory-experiments-native-verification-v1'
            and native.get('complete') is True and not native.get('error'),
            'native producer report must be completed and passing')
    source = native['source_commit']
    require(re.fullmatch('[0-9a-f]{40}', source), 'producer source is not an exact commit')
    root = Path(native['source_checkout']).resolve(strict=True)
    product = native['cli_product']
    binary = (receipt.parent / product['binary']).resolve(strict=True)
    require(binary.is_relative_to(receipt.parent) and digest(binary) == product['executable_sha256'],
            'frozen CLI differs from native producer report')
    binary_hash, receipt_hash = product['executable_sha256'], digest(receipt)
    helper_path = receipt.parent / 'bounded_command_helpers.py'
    require(digest(helper_path) == native['bounded_helper_sha256'], 'bounded helper differs')
    output = args.output.resolve()
    require(output.is_relative_to(BASE) and output != BASE and not output.exists()
            and not output.is_relative_to(root), 'fresh evidence output outside checkout required')
    output.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(receipt, output / 'native-producer-report.json')
    shutil.copyfile(helper_path, output / 'bounded_command_helpers.py')
    spec = importlib.util.spec_from_file_location('test262_focus_bounded', helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    sys.path.insert(0, str(root / 'scripts'))
    from limited_verification import kernel_group, require_kernel_budget

    report = dict(schema='scriptw-memory-experiments-test262-focus-v1', complete=False,
                  source_commit=source, source_checkout=str(root), binary=str(binary),
                  executable_sha256=binary_hash, native_report=str(receipt),
                  native_report_sha256=receipt_hash, driver_sha256=digest(Path(__file__)),
                  bounded_helper_sha256=digest(helper_path), started_at=helper.stamp(),
                  commands=[], scopes=[], full_suite=False, published=False,
                  scope='Four original Test262 subtrees; actual execution variants from frozen CLI inventory.')
    helper.save(output, report)

    def guard():
        require_kernel_budget(4 * 1024**3)
        require(len(os.sched_getaffinity(0)) == 1, 'verification requires one CPU')
        require(all(os.environ.get(key) == '1' for key in (
            'CARGO_BUILD_JOBS', 'RUST_TEST_THREADS', 'SCRIPTW_JOBS', 'RAYON_NUM_THREADS')),
            'verification workers must remain serial')
        require(os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES') == '1'
                and os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES') == str(64 * MIB),
                'retained module cache must be one entry / 64 MiB')
        require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == source
                and not subprocess.check_output(
                    ['git', 'status', '--porcelain', '--untracked-files=all'], cwd=root),
                'isolated source checkout changed')
        require(digest(receipt) == receipt_hash and digest(binary) == binary_hash
                and digest(helper_path) == native['bounded_helper_sha256'],
                'frozen producer, CLI or bounded helper changed')

    def budget():
        group = kernel_group()
        return {key: (group / key).read_text().strip() for key in (
            'memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}

    def run(label, command, timeout):
        guard()
        row = dict(label=label, command=list(map(str, command)), cwd=str(root),
                   stdout=label + '.stdout', stderr=label + '.stderr')
        report['commands'].append(row)
        helper.save(output, report)
        print(label, 'started', flush=True)
        try:
            helper.run_command(row, output, timeout=timeout,
                               stdout_limit=4 * MIB, stderr_limit=4 * MIB)
        finally:
            helper.save(output, report)
        guard()
        helper.no_oom(report['before'], budget())
        require(not row.get('timed_out') and not row.get('output_limit_exceeded')
                and not row.get('pipe_cleanup_incomplete') and not row.get('error'),
                'bounded command failed: ' + label)
        return row

    try:
        guard()
        report.update(before=budget(), cpu_affinity=sorted(os.sched_getaffinity(0)))
        suite = root / 'test262/vendor/test262'
        pins_source = read_json(root / 'crates/scriptw-test262/src/source-pins.json')
        pins = dict(ecma262=pins_source['ecma262'], test262=pins_source['test262_tree'])
        require(subprocess.check_output(['git', 'rev-parse', 'HEAD:test262/vendor/test262'],
                                        cwd=root, text=True).strip() == pins['test262'],
                'selected suite is not the original pinned tree')
        report.update(suite_root=str(suite), pinned_revisions=pins)
        all_ids = set()
        for label, prefix in SCOPES:
            scope = dict(label=label, filter=prefix, complete=False)
            report['scopes'].append(scope)
            inventory = run(label + '-inventory', [binary, '--jobs', '1', 'test262',
                            'list-all', prefix, '--suite-root', suite], 120)
            require(inventory.get('exit_code') == 0, 'inventory command failed')
            ids = execution_ids((output / inventory['stdout']).read_text(), prefix)
            require(not all_ids.intersection(ids), 'selected subtree inventories overlap')
            all_ids.update(ids)
            scope.update(inventory=ids, inventory_count=len(ids),
                         execution_mode_counts=dict(Counter(item.split(':', 1)[0] for item in ids)))
            snapshots = output / label / 'snapshots'
            row = run(label + '-run', [binary, '--jobs', '1', 'test262', 'run', prefix,
                      '--execution-backend', 'wasm-aot', '--suite-root', suite,
                      '--threads', '1', '--timeout-ms', '60000',
                      '--snapshot-dir', snapshots, '--snapshot-name', label], len(ids) * 65 + 120)
            try:
                snapshot_result(snapshots, label, ids, source, binary_hash, pins, scope)
                require(row.get('exit_code') == 0, 'CLI reported a non-passing verdict')
                scope.update(complete=True, passed=len(ids))
            except ValueError as error:
                scope['error'] = str(error)
            helper.save(output, report)
            print(label, 'passed' if scope['complete'] else scope['error'], flush=True)
        guard()
        report['after'] = budget()
        helper.no_oom(report['before'], report['after'])
        report.update(selected_execution_count=len(all_ids),
                      passed=sum(scope.get('passed', 0) for scope in report['scopes']))
        require(len(report['scopes']) == 4 and all(scope['complete'] for scope in report['scopes']),
                'one or more focused Test262 scopes failed')
        report['complete'] = True
        return 0
    except BaseException as error:
        report.update(error=str(error), error_type=type(error).__name__)
        return 1
    finally:
        report['finished_at'] = helper.stamp()
        if 'before' in report and 'after' not in report:
            try:
                report['after'] = budget()
                helper.no_oom(report['before'], report['after'])
            except (OSError, ValueError) as error:
                report['resource_after_error'] = str(error)
        helper.save(output, report)
        print(json.dumps(dict(complete=report['complete'], passed=report.get('passed'),
                              error=report.get('error'), output=str(output))), flush=True)


if __name__ == '__main__':
    raise SystemExit(main())
