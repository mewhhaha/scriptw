# Consumer capability diagnostic

Identical trusted native images; two rounds, ten warmups and seven samples per round.
Process endpoints include runtime, host and allocation history. Compiler dependencies remain.
Excluded from canonical performance publications.

| Workload / adapter | Capability | Execution ms | RSS MiB | PSS MiB | Private dirty MiB |
| --- | --- | ---: | ---: | ---: | ---: |
| sort-reverse-128.js / scriptw | enabled | 0.907 | 21.414 | 18.913 | 3.863 |
| sort-reverse-128.js / scriptw | disabled | 0.909 | 19.207 | 16.666 | 3.459 |
| sort-reverse-128.js / wasi | enabled | 0.091 | 15.191 | 12.739 | 4.951 |
| sort-reverse-128.js / wasi | disabled | 0.090 | 14.598 | 12.132 | 4.555 |
| sort-reverse-512.js / scriptw | enabled | 2.915 | 24.105 | 21.577 | 6.473 |
| sort-reverse-512.js / scriptw | disabled | 2.901 | 21.932 | 19.416 | 6.068 |
| sort-reverse-512.js / wasi | enabled | 0.211 | 15.281 | 12.844 | 5.002 |
| sort-reverse-512.js / wasi | disabled | 0.209 | 14.889 | 12.438 | 4.605 |
| sort-sorted-512.js / scriptw | enabled | 1.529 | 21.605 | 19.103 | 4.195 |
| sort-sorted-512.js / scriptw | disabled | 1.522 | 19.754 | 17.222 | 3.803 |
| sort-sorted-512.js / wasi | enabled | 0.216 | 15.232 | 12.791 | 5.004 |
| sort-sorted-512.js / wasi | disabled | 0.214 | 14.654 | 12.185 | 4.604 |
| to-sorted-512.js / scriptw | enabled | 3.579 | 25.029 | 22.514 | 7.193 |
| to-sorted-512.js / scriptw | disabled | 3.588 | 22.822 | 20.293 | 6.801 |
| to-sorted-512.js / wasi | enabled | 0.233 | 15.191 | 12.731 | 5.016 |
| to-sorted-512.js / wasi | disabled | 0.229 | 14.793 | 12.361 | 4.615 |
| join-1024.js / scriptw | enabled | 1.634 | 21.525 | 19.006 | 3.779 |
| join-1024.js / scriptw | disabled | 1.604 | 19.330 | 16.812 | 3.381 |
| join-1024.js / wasi | enabled | 0.281 | 15.348 | 12.914 | 5.025 |
| join-1024.js / wasi | disabled | 0.287 | 15.025 | 12.582 | 4.625 |
| join-4096.js / scriptw | enabled | 5.414 | 23.449 | 20.925 | 5.521 |
| join-4096.js / scriptw | disabled | 5.389 | 21.094 | 18.576 | 5.119 |
| join-4096.js / wasi | enabled | 0.929 | 15.646 | 13.181 | 5.500 |
| join-4096.js / wasi | disabled | 0.922 | 15.686 | 13.228 | 5.104 |
| join-mixed-1024.js / scriptw | enabled | 1.793 | 21.719 | 19.216 | 3.754 |
| join-mixed-1024.js / scriptw | disabled | 1.800 | 19.287 | 16.760 | 3.355 |
| join-mixed-1024.js / wasi | enabled | 0.181 | 15.053 | 12.604 | 4.961 |
| join-mixed-1024.js / wasi | disabled | 0.183 | 14.928 | 12.479 | 4.559 |
| numeric-loop-10000.js / scriptw | enabled | 0.952 | 19.883 | 17.393 | 3.145 |
| numeric-loop-10000.js / scriptw | disabled | 0.946 | 17.453 | 14.930 | 2.742 |
| numeric-loop-10000.js / wasi | enabled | 0.071 | 14.389 | 11.933 | 4.285 |
| numeric-loop-10000.js / wasi | disabled | 0.070 | 14.119 | 11.643 | 3.885 |
| numeric-loop-50000.js / scriptw | enabled | 3.290 | 19.781 | 17.253 | 3.145 |
| numeric-loop-50000.js / scriptw | disabled | 3.287 | 17.787 | 15.257 | 2.744 |
| numeric-loop-50000.js / wasi | enabled | 0.143 | 14.789 | 12.344 | 4.289 |
| numeric-loop-50000.js / wasi | disabled | 0.144 | 14.090 | 11.632 | 3.891 |
| folded-string-4096.js / scriptw | enabled | 1.326 | 20.549 | 18.032 | 3.295 |
| folded-string-4096.js / scriptw | disabled | 1.303 | 18.055 | 15.538 | 2.895 |
| folded-string-4096.js / wasi | enabled | 0.428 | 14.354 | 11.899 | 4.303 |
| folded-string-4096.js / wasi | disabled | 0.426 | 14.199 | 11.747 | 3.904 |
| dynamic-string-4096.js / scriptw | enabled | 1.541 | 20.449 | 17.925 | 3.475 |
| dynamic-string-4096.js / scriptw | disabled | 1.546 | 17.832 | 15.297 | 3.078 |
| dynamic-string-4096.js / wasi | enabled | 0.169 | 14.734 | 12.270 | 4.287 |
| dynamic-string-4096.js / wasi | disabled | 0.174 | 14.170 | 11.743 | 3.891 |
| integer.js / scriptw | enabled | 2.306 | 20.504 | 17.997 | 3.174 |
| integer.js / scriptw | disabled | 2.333 | 18.332 | 15.800 | 2.773 |
| integer.js / wasi | enabled | 0.054 | 14.273 | 11.822 | 4.289 |
| integer.js / wasi | disabled | 0.054 | 13.920 | 11.474 | 3.891 |
| objects.js / scriptw | enabled | 1.268 | 21.555 | 19.040 | 3.582 |
| objects.js / scriptw | disabled | 1.267 | 18.832 | 16.327 | 3.182 |
| objects.js / wasi | enabled | 0.399 | 15.387 | 12.940 | 5.076 |
| objects.js / wasi | disabled | 0.406 | 14.998 | 12.542 | 4.678 |
| retained-objects.js / scriptw | enabled | 31.379 | 25.328 | 22.854 | 7.377 |
| retained-objects.js / scriptw | disabled | 31.377 | 23.211 | 20.691 | 6.979 |
| retained-objects.js / wasi | enabled | 20.286 | 20.938 | 18.500 | 10.818 |
| retained-objects.js / wasi | disabled | 20.431 | 20.590 | 18.149 | 10.420 |
| join-empty-1024.js / scriptw | enabled | 2.240 | 22.230 | 19.724 | 4.943 |
| join-empty-1024.js / scriptw | disabled | 2.240 | 19.959 | 17.450 | 4.543 |
| join-empty-1024.js / wasi | enabled | 0.161 | 15.031 | 12.562 | 4.873 |
| join-empty-1024.js / wasi | disabled | 0.163 | 14.703 | 12.231 | 4.475 |
| join-singleton-1024.js / scriptw | enabled | 2.356 | 22.562 | 20.037 | 5.027 |
| join-singleton-1024.js / scriptw | disabled | 2.315 | 20.275 | 17.748 | 4.637 |
| join-singleton-1024.js / wasi | enabled | 0.088 | 14.537 | 12.076 | 4.287 |
| join-singleton-1024.js / wasi | disabled | 0.087 | 14.115 | 11.674 | 3.891 |
| join-small-1024.js / scriptw | enabled | 2.441 | 22.480 | 19.960 | 5.047 |
| join-small-1024.js / scriptw | disabled | 2.462 | 20.387 | 17.852 | 4.654 |
| join-small-1024.js / wasi | enabled | 0.118 | 14.555 | 12.086 | 4.297 |
| join-small-1024.js / wasi | disabled | 0.115 | 14.230 | 11.785 | 3.898 |
