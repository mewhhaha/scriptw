"""Run only reviewed Portable-compatible tests from a frozen feature-off harness.

Prepared separately from execution. Invoke under scripts/limited_verification.py,
only after all other native compilation/verification has ended. The input binary
must have a sibling producer.json with its Cargo artifact and SHA256. This driver
does not build, modify source, or claim the full ordinary Engine API suite passes.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPOSITORY = BASE.parents[1]
DEFAULT_WORKSPACE = BASE / 'baseline-source'
HELPERS = REPOSITORY / 'target/memory-runtime-error-tail-20261028-evidence/native-runtime-error-tail-r1.py'
HELPERS_SHA = '194b6921c0312d51d69e0f78e1d616d9039e9b699c8c35643d039ea1953b6a43'
MIB = 1024**2
ENGINE_SOURCE = 'crates/scriptw-engine/src/'
# Every test in these owners uses Portable emission or compiler-independent
# host/cache state. Their full actual compiled inventories must match source.
OWNERS = [
    ('precompiled', 'embedding::precompiled::tests::', 'embedding/precompiled/tests.rs'),
    ('embedding', 'embedding::tests::', 'embedding/tests.rs'),
    ('transfer-retained', 'embedding::tests::transfer_retained::', 'embedding/tests/transfer_retained.rs'),
    ('async-operations', 'embedding::tests::async_operations::', 'embedding/tests/async_operations.rs'),
    ('realm-async', 'embedding::tests::realm_async::', 'embedding/tests/realm_async.rs'),
    ('compact-records', 'embedding::tests::compact_records::', 'embedding/tests/compact_records.rs'),
    ('async-host', 'embedding::async_host::tests::', 'embedding/async_host.rs'),
    ('module-cache', 'memory_module_cache::tests::', 'memory_module_cache.rs'),
    ('engine-cache', 'memory_module_cache::native_templates::tests::', 'memory_module_cache/native_templates/tests.rs'),
]
EXACT = [
    ('compiler-imports', 'wasm_gc_host::tests::', 'wasm_gc_host/tests.rs', [
        'emitted_portable_and_native_r_keep_actual_compiler_import_domains',
        'feature_off_rejects_all_native_compiler_import_names_before_binding',
    ]),
    ('source-profile', 'source_compilation_profile_tests::', 'source_compilation_profile_tests.rs', [
        'portable_prepared_code_runs_and_unprepared_source_rejects_outside_javascript',
        'linked_program_source_profile_cannot_be_substituted_before_instantiation',
    ]),
    ('agent-lifecycle', 'agent_failure_tests::', 'agent_failure_tests.rs', [
        'broadcast_retains_a_disconnected_worker_until_its_failure_is_joined',
        'broadcast_waits_for_every_retrieval_without_holding_the_worker_registry',
        'a_worker_that_drops_a_queued_receipt_keeps_its_failure_owner',
    ]),
    ('gc-weak-policy', 'tests::', 'tests.rs', [
        'engine_error_wasmtime_capabilities_share_policy_authority',
        'product_wasmtime_profiles_require_copying_weak_capability',
        'required_runtime_rejects_disabled_gc_support',
        'required_runtime_refuses_implicit_collector_selection',
    ]),
]
FOCUS = [
    'wasm_gc_host::tests::feature_off_rejects_all_native_compiler_import_names_before_binding',
    'embedding::precompiled::tests::feature_off_precompiled_agent_start_has_no_source_compilation_authority',
    'embedding::precompiled::tests::precompiled_standalone_executes_on_an_engine_that_cannot_compile_wasm',
    'memory_module_cache::native_templates::tests::native_template_cache_requires_actual_engine_and_keeps_original_aggregate_limits',
]
ABSENT_PREFIXES = ('native_direct_eval_compiler_tests::', 'native_function_compiler_tests::',
                   'native_global_script_compiler_tests::', 'native_language_feature_policy_tests::',
                   'wasm_native_direct_eval_compiler::', 'wasm_native_function_compiler::',
                   'wasm_native_global_script_compiler::', 'wasm_native_program_template::',
                   'wasm_native_source_compiler::', 'memory_module_cache::native_templates::instances::')
ABSENT_IDS = (
    'wasm_gc_host::tests::present_compiler_names_preserve_wrong_signature_kind_and_duplicate_rejection',
    'wasm_gc_host::tests::native_compilers_still_arm_after_linking_before_all_three_dynamic_calls',
    'source_compilation_profile_tests::public_exports_remain_portable_after_native_source_execution_warms_the_runtime',
)


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source_names(path):
    names = re.findall(r'#\[test\]\s*(?:#\[[^\n]+\]\s*)*fn\s+(\w+)\s*\(', path.read_text())
    require(names and len(names) == len(set(names)), 'empty/ambiguous source owner: ' + str(path))
    return names


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workspace', type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument('--producer', type=Path, help='defaults to producer.json beside the frozen binary')
    args = parser.parse_args()
    root = args.workspace.resolve(strict=True)
    binary = args.binary.resolve(strict=True)
    receipt = (args.producer or binary.parent / 'producer.json').resolve(strict=True)
    output = args.output.resolve()
    require(re.fullmatch('[0-9a-f]{40}', args.expected_source), 'expected source must be a complete SHA')
    require(output.is_relative_to(BASE) and output != BASE and not output.exists(), 'fresh private output required')
    require(sha(HELPERS) == HELPERS_SHA, 'reviewed bounded subprocess helper changed')
    output.mkdir(parents=True, exist_ok=False)
    spec = importlib.util.spec_from_file_location('feature_off_bounded_helpers', HELPERS)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    sys.path.insert(0, str(root / 'scripts'))
    from limited_verification import kernel_group, require_kernel_budget
    from native_test_protocol import parse_inventory, result_summaries
    report = dict(schema='scriptw-feature-off-portable-native-tests-v1', complete=False,
                  source_commit=args.expected_source, source_checkout=str(root), binary=str(binary),
                  started_at=helper.stamp(), commands=[], scopes=[], driver_sha256=sha(Path(__file__)),
                  helper_sha256=HELPERS_SHA, inherited_passes=0,
                  limitation='Selected Portable-compatible engine lib tests only. Static compiler/Cranelift dependencies remain. No NativeHost Engine API or separate weak/finalization reachability integration-suite claim.')
    helper.save(output, report)

    def source():
        require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == args.expected_source,
                'source checkout differs from exact admitted source')
        require(not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=normal'], cwd=root),
                'source checkout must remain clean')
        require(os.environ.get('SCRIPTW_EXPECTED_SOURCE') == args.expected_source, 'expected-source environment differs')

    def scope():
        require_kernel_budget(4 * 1024**3)
        require(len(os.sched_getaffinity(0)) == 1, 'verification must retain one CPU')
        require(all(os.environ.get(key) == '1' for key in
                    ('CARGO_BUILD_JOBS', 'RUST_TEST_THREADS', 'SCRIPTW_JOBS', 'RAYON_NUM_THREADS')),
                'compilation and test worker counts must stay serial')
        require(os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES') == '1'
                and os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES') == str(64 * MIB),
                'retained cache differs from one entry / 64 MiB')

    def budget():
        group = kernel_group()
        return {key: (group / key).read_text().strip() for key in
                ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}

    def run(label, command, ids=None):
        source()
        scope()
        require(sha(receipt) == report['producer_receipt_sha256'] and sha(HELPERS) == HELPERS_SHA,
                'producer receipt or command helper changed')
        row = dict(label=label, command=list(map(str, command)), cwd=str(root / 'crates/scriptw-engine'),
                   stdout=label + '.stdout', stderr=label + '.stderr')
        if ids is not None:
            row['expected_test_ids'] = ids
        report['commands'].append(row)
        helper.save(output, report)
        print(label, 'started', flush=True)
        try:
            helper.run_command(row, output, timeout=3600, stdout_limit=4 * MIB, stderr_limit=4 * MIB)
        finally:
            try:
                if ids is not None and (output / row['stdout']).exists():
                    text = (output / row['stdout']).read_text()
                    row['reported_passing_test_ids'] = [name.removesuffix(' - should panic') for name in
                        re.findall(r'^test ([^\r\n]+) \.\.\. ok$', text, re.M)]
                    row['reported_result_summaries'] = result_summaries(text)
            finally:
                helper.save(output, report)
        source()
        scope()
        helper.no_oom(report['before'], budget())
        require(row.get('exit_code') == 0 and not row['timed_out'] and not row['output_limit_exceeded']
                and not row.get('pipe_cleanup_incomplete'), label + ' failed; original streams retained')
        print(label, 'finished', flush=True)
        return row, (output / row['stdout']).read_text()

    try:
        source()
        scope()
        report.update(before=budget(), cpu_affinity=sorted(os.sched_getaffinity(0)),
                      producer_receipt_sha256=sha(receipt), producer_receipt=str(receipt))
        frozen = json.loads(receipt.read_text())
        producer = frozen['cargo_producer']
        require(producer['reason'] == 'compiler-artifact' and producer['target']['kind'] == ['lib']
                and producer['target']['name'] == 'scriptw_engine' and producer['profile']['test']
                and producer['profile']['opt_level'] == '3' and producer['features'] == [],
                'actual engine harness must have source capability and oracle features disabled')
        require(Path(producer['target']['src_path']).resolve() == root / 'crates/scriptw-engine/src/lib.rs'
                and producer['package_id'].startswith('path+file://' + str(root / 'crates/scriptw-engine') + '#'),
                'Cargo producer belongs to a different source checkout')
        info = binary.stat()
        require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_mode & 0o222 == 0,
                'input must be an independent readonly frozen executable')
        require(sha(binary) == frozen['executable_sha256'], 'frozen binary differs from its producer receipt')
        report.update(cargo_producer=producer, executable_sha256=frozen['executable_sha256'],
                      external_build=True, build_not_rerun=True)
        _, text = run('engine-feature-off-inventory', [binary, '--list', '--color=never'])
        inventory = parse_inventory(text)
        require(not any(name.startswith(ABSENT_PREFIXES) for name in inventory)
                and not set(ABSENT_IDS).intersection(inventory), 'native-source-only controls entered feature-off harness')
        report['full_inventory'] = inventory
        inventory_set = set(inventory)
        selected = set()
        for label, prefix, path in OWNERS:
            expected = sorted(prefix + name for name in source_names(root / (ENGINE_SOURCE + path)))
            actual = [name for name in inventory if name.startswith(prefix) and '::' not in name[len(prefix):]]
            require(actual == expected, 'source/actual owner inventory mismatch: ' + label)
            require(not selected.intersection(actual), 'selected owner scopes overlap')
            selected.update(actual)
            report['scopes'].append(dict(label=label, source=ENGINE_SOURCE + path, inventory=actual,
                                         passed_test_ids=[], complete=False))
        for label, prefix, path, names in EXACT:
            expected = sorted(prefix + name for name in names)
            declared = set(source_names(root / (ENGINE_SOURCE + path)))
            require(set(names) <= declared and set(expected) <= inventory_set, 'required exact source/test IDs absent: ' + label)
            require(not selected.intersection(expected), 'exact scopes overlap')
            selected.update(expected)
            report['scopes'].append(dict(label=label, source=ENGINE_SOURCE + path, inventory=expected,
                                         passed_test_ids=[], complete=False))
        require(selected and set(FOCUS) <= selected, 'feature-off focus controls absent')
        report.update(selected_inventory=sorted(selected), full_inventory_count=len(inventory),
                      selected_inventory_count=len(selected), outside_selected_scope_count=len(inventory) - len(selected),
                      focused_test_ids=FOCUS, passed_test_ids=[])
        helper.save(output, report)

        def execute(ids, label):
            require(ids and len(ids) == len(set(ids)) and set(ids) <= selected
                    and not set(ids).intersection(report['passed_test_ids']), 'empty, repeated or outside-scope IDs')
            row, text = run(label, [binary, '--exact', '--include-ignored', '--test-threads=1', '--color=never', *ids], ids)
            passed = row['reported_passing_test_ids']
            require(len(passed) == len(set(passed)) == len(ids) and set(passed) == set(ids), 'actual passing exact IDs differ')
            require(result_summaries(text) == [('ok', str(len(ids)), '0', '0', '0', str(len(inventory) - len(ids)))],
                    'terminal summary does not match actual harness inventory')
            report['passed_test_ids'] += sorted(passed)
            for selected_scope in report['scopes']:
                selected_scope['passed_test_ids'] += sorted(set(passed).intersection(selected_scope['inventory']))
                selected_scope['complete'] = set(selected_scope['passed_test_ids']) == set(selected_scope['inventory'])
            helper.save(output, report)

        execute(FOCUS, 'compiler-absence-and-cache-focused')
        report['focused_complete'] = True
        helper.save(output, report)
        for selected_scope in report['scopes']:
            remainder = [name for name in selected_scope['inventory'] if name not in FOCUS]
            for offset in range(0, len(remainder), 8):
                execute(remainder[offset:offset + 8], selected_scope['label'] + f'-part-{offset:03d}')
        source()
        scope()
        require(len(report['passed_test_ids']) == len(set(report['passed_test_ids'])) == len(selected)
                and set(report['passed_test_ids']) == selected and all(row['complete'] for row in report['scopes']),
                'selected Portable scope closure differs')
        require(sha(binary) == report['executable_sha256'], 'frozen executable changed')
        report['after'] = budget()
        helper.no_oom(report['before'], report['after'])
        report.update(complete=True, passed=len(selected), focused_passes_included=len(FOCUS),
                      broad_remainder_passes=len(selected) - len(FOCUS), repeated_ids=0, finished_at=helper.stamp())
        return 0
    except BaseException as error:
        report.update(error=str(error), error_type=type(error).__name__, finished_at=helper.stamp())
        return 1
    finally:
        if 'before' in report and 'after' not in report:
            try:
                report['after'] = budget()
                helper.no_oom(report['before'], report['after'])
            except (OSError, ValueError) as error:
                report['resource_after_error'] = str(error)
        helper.save(output, report)
        print(json.dumps(dict(complete=report['complete'], selected=report.get('selected_inventory_count'),
                              passed=report.get('passed'), error=report.get('error'), output=str(output))), flush=True)


if __name__ == '__main__':
    raise SystemExit(main())
