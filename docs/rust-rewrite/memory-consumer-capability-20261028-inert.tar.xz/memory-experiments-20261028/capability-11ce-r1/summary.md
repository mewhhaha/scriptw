# Consumer capability diagnostic

Identical trusted native images; two rounds, ten warmups and seven samples per round.
Process endpoints include runtime, host and allocation history. Compiler dependencies remain.
Excluded from canonical performance publications.

| Workload / adapter | Capability | Execution ms | RSS MiB | PSS MiB | Private dirty MiB |
| --- | --- | ---: | ---: | ---: | ---: |
| sort-reverse-128.js / scriptw | enabled | 0.890 | 20.182 | 17.646 | 3.836 |
| sort-reverse-128.js / scriptw | disabled | 0.910 | 18.254 | 15.745 | 3.445 |
| sort-reverse-128.js / wasi | enabled | 0.091 | 14.285 | 11.865 | 4.955 |
| sort-reverse-128.js / wasi | disabled | 0.094 | 14.297 | 11.838 | 4.559 |
| sort-reverse-512.js / scriptw | enabled | 2.867 | 22.855 | 20.347 | 6.443 |
| sort-reverse-512.js / scriptw | disabled | 2.834 | 20.301 | 17.813 | 6.053 |
| sort-reverse-512.js / wasi | enabled | 0.209 | 14.514 | 12.059 | 5.006 |
| sort-reverse-512.js / wasi | disabled | 0.213 | 14.209 | 11.769 | 4.605 |
| sort-sorted-512.js / scriptw | enabled | 1.496 | 20.543 | 18.048 | 4.168 |
| sort-sorted-512.js / scriptw | disabled | 1.508 | 18.404 | 15.896 | 3.775 |
| sort-sorted-512.js / wasi | enabled | 0.220 | 14.641 | 12.178 | 5.002 |
| sort-sorted-512.js / wasi | disabled | 0.216 | 14.502 | 12.026 | 4.609 |
| to-sorted-512.js / scriptw | enabled | 3.516 | 23.934 | 21.412 | 7.168 |
| to-sorted-512.js / scriptw | disabled | 3.546 | 21.463 | 18.947 | 6.771 |
| to-sorted-512.js / wasi | enabled | 0.228 | 14.658 | 12.200 | 5.018 |
| to-sorted-512.js / wasi | disabled | 0.229 | 14.514 | 12.066 | 4.623 |
| join-1024.js / scriptw | enabled | 1.607 | 20.439 | 17.903 | 3.750 |
| join-1024.js / scriptw | disabled | 1.599 | 17.947 | 15.411 | 3.352 |
| join-1024.js / wasi | enabled | 0.285 | 14.789 | 12.330 | 5.023 |
| join-1024.js / wasi | disabled | 0.279 | 14.166 | 11.701 | 4.625 |
| join-4096.js / scriptw | enabled | 5.236 | 22.035 | 19.506 | 5.492 |
| join-4096.js / scriptw | disabled | 5.269 | 19.896 | 17.364 | 5.096 |
| join-4096.js / wasi | enabled | 0.931 | 15.160 | 12.709 | 5.500 |
| join-4096.js / wasi | disabled | 0.917 | 14.295 | 11.836 | 5.105 |
| join-mixed-1024.js / scriptw | enabled | 1.768 | 20.354 | 17.831 | 3.723 |
| join-mixed-1024.js / scriptw | disabled | 1.757 | 17.795 | 15.276 | 3.328 |
| join-mixed-1024.js / wasi | enabled | 0.185 | 14.760 | 12.311 | 4.957 |
| join-mixed-1024.js / wasi | disabled | 0.186 | 13.887 | 11.451 | 4.561 |
| numeric-loop-10000.js / scriptw | enabled | 0.953 | 18.639 | 16.128 | 3.117 |
| numeric-loop-10000.js / scriptw | disabled | 0.937 | 16.334 | 13.817 | 2.721 |
| numeric-loop-10000.js / wasi | enabled | 0.070 | 13.928 | 11.463 | 4.287 |
| numeric-loop-10000.js / wasi | disabled | 0.070 | 13.818 | 11.357 | 3.891 |
| numeric-loop-50000.js / scriptw | enabled | 3.289 | 18.609 | 16.108 | 3.119 |
| numeric-loop-50000.js / scriptw | disabled | 3.279 | 16.740 | 14.220 | 2.719 |
| numeric-loop-50000.js / wasi | enabled | 0.146 | 14.094 | 11.633 | 4.285 |
| numeric-loop-50000.js / wasi | disabled | 0.145 | 13.316 | 10.869 | 3.895 |
| folded-string-4096.js / scriptw | enabled | 1.288 | 18.713 | 16.165 | 3.271 |
| folded-string-4096.js / scriptw | disabled | 1.296 | 17.004 | 14.471 | 2.875 |
| folded-string-4096.js / wasi | enabled | 0.424 | 13.994 | 11.560 | 4.303 |
| folded-string-4096.js / wasi | disabled | 0.426 | 13.494 | 11.029 | 3.908 |
| dynamic-string-4096.js / scriptw | enabled | 1.532 | 19.340 | 16.820 | 3.451 |
| dynamic-string-4096.js / scriptw | disabled | 1.528 | 16.711 | 14.210 | 3.053 |
| dynamic-string-4096.js / wasi | enabled | 0.173 | 13.797 | 11.339 | 4.287 |
| dynamic-string-4096.js / wasi | disabled | 0.168 | 13.484 | 11.043 | 3.893 |
| integer.js / scriptw | enabled | 2.295 | 19.027 | 16.508 | 3.148 |
| integer.js / scriptw | disabled | 2.330 | 17.201 | 14.689 | 2.760 |
| integer.js / wasi | enabled | 0.052 | 13.789 | 11.338 | 4.287 |
| integer.js / wasi | disabled | 0.053 | 13.432 | 10.990 | 3.893 |
| objects.js / scriptw | enabled | 1.255 | 19.859 | 17.356 | 3.561 |
| objects.js / scriptw | disabled | 1.255 | 17.584 | 15.079 | 3.168 |
| objects.js / wasi | enabled | 0.405 | 14.809 | 12.340 | 5.078 |
| objects.js / wasi | disabled | 0.410 | 14.395 | 11.932 | 4.680 |
| retained-objects.js / scriptw | enabled | 32.701 | 24.365 | 21.833 | 7.316 |
| retained-objects.js / scriptw | disabled | 32.066 | 21.869 | 19.362 | 6.922 |
| retained-objects.js / wasi | enabled | 20.307 | 20.447 | 17.984 | 10.820 |
| retained-objects.js / wasi | disabled | 20.414 | 19.854 | 17.394 | 10.422 |
| join-empty-1024.js / scriptw | enabled | 2.197 | 20.639 | 18.134 | 4.920 |
| join-empty-1024.js / scriptw | disabled | 2.190 | 18.752 | 16.223 | 4.521 |
| join-empty-1024.js / wasi | enabled | 0.162 | 14.293 | 11.833 | 4.873 |
| join-empty-1024.js / wasi | disabled | 0.165 | 13.986 | 11.526 | 4.479 |
| join-singleton-1024.js / scriptw | enabled | 2.327 | 21.160 | 18.659 | 5.012 |
| join-singleton-1024.js / scriptw | disabled | 2.277 | 18.180 | 15.669 | 4.615 |
| join-singleton-1024.js / wasi | enabled | 0.088 | 14.207 | 11.740 | 4.287 |
| join-singleton-1024.js / wasi | disabled | 0.088 | 13.668 | 11.223 | 3.895 |
| join-small-1024.js / scriptw | enabled | 2.433 | 21.137 | 18.636 | 5.021 |
| join-small-1024.js / scriptw | disabled | 2.424 | 18.822 | 16.293 | 4.633 |
| join-small-1024.js / wasi | enabled | 0.116 | 13.688 | 11.253 | 4.295 |
| join-small-1024.js / wasi | disabled | 0.117 | 13.312 | 10.856 | 3.900 |
