"""Freeze the existing benchmark hosts and compare both runtime profiles."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
from run import OUT, ROOT, digest, load, save_new

destination = OUT / 'candidate'
destination.mkdir()
products = {}
for name in ['scriptw', 'runtime_baseline', 'compiler_precompiled_baseline', 'wasi_baseline']:
    source = ROOT / 'target/release/examples' / name
    if name == 'scriptw':
        source = ROOT / 'target/release/scriptw'
    path = destination / name
    subprocess.run(['cp', '--reflink=auto', '--preserve=mode,timestamps', source, path], check=True)
    assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
    products[name] = dict(sha256=digest(path), bytes=path.stat().st_size)
with (destination / 'identity.stdout').open('xb') as stdout, (destination / 'identity.stderr').open('xb') as stderr:
    subprocess.run([destination / 'compiler_precompiled_baseline', 'identity'], cwd=ROOT,
                   stdout=stdout, stderr=stderr, check=True)
identity = load(destination / 'identity.stdout')
assert identity['executable_sha256'] == products['compiler_precompiled_baseline']['sha256']
save_new(destination / 'identity.json', identity)
save_new(destination / 'products.json', products)
save_new(destination / 'host-products.json', products)
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT)
(destination / 'source.patch').write_bytes(patch)
save_new(destination / 'source.json', dict(head=identity['source_commit'],
    patch_sha256=hashlib.sha256(patch).hexdigest(), fingerprint=identity['source_fingerprint']))
files = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
save_new(destination / 'source-files.json', {name: digest(ROOT / name) for name in files})

build = ROOT / 'target/release/build/scriptw-runtime-image-f4bdc99efd9bf0e2/out'
baseline = ROOT / 'target/performance-fresh-sort/baseline/runtime-build'
frozen = destination / 'runtime-build'
frozen.mkdir()
receipts = {}
for profile in ['', '-portable']:
    package = f'scriptw-runtime{profile}-package.bin'
    native = f'scriptw-runtime{profile}-native.bin'
    for name in [package, native]:
        subprocess.run(['cp', '--reflink=auto', build / name, frozen / name], check=True)
    current, previous = (frozen / package).read_bytes(), (baseline / package).read_bytes()
    assert current[:8] == previous[:8] == b'SCRWRB01'
    assert struct.unpack_from('<I', current, 8)[0] == struct.unpack_from('<I', previous, 8)[0] == 42
    assert current[12:44].hex() == identity['source_fingerprint']
    assert previous[12:44].hex() == load(OUT / 'baseline/identity.json')['source_fingerprint']
    current_wasm, previous_wasm = current[136:-32], previous[136:-32]
    assert len(current_wasm) == struct.unpack_from('<Q', current, 128)[0]
    assert len(previous_wasm) == struct.unpack_from('<Q', previous, 128)[0]
    assert hashlib.sha256(current[:-32]).digest() == current[-32:]
    assert hashlib.sha256(previous[:-32]).digest() == previous[-32:]
    assert current_wasm == previous_wasm
    assert digest(frozen / native) == digest(baseline / native)
    receipts[package] = dict(source_fingerprint=identity['source_fingerprint'],
        runtime_abi=42, runtime_wasm_identical=True, runtime_wasm_bytes=len(current_wasm),
        runtime_wasm_sha256=hashlib.sha256(current_wasm).hexdigest())
    receipts[native] = dict(native_identical=True, bytes=(frozen / native).stat().st_size,
                          sha256=digest(frozen / native))
save_new(OUT / 'runtime-invariance.json', receipts)
print(json.dumps(dict(source_fingerprint=identity['source_fingerprint'], products=products,
                     runtime_invariance=receipts), indent=2))
