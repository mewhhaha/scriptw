"""Same-machine original-source controls; never publish the historical charts."""
from pathlib import Path
import json
import os
import shutil
import statistics
import subprocess
from reference_support import OUT, ROOT, SAMPLES, WARMUPS, invoke, load, save, verify_product
from benchmark_metrics import digest
from compiler_comparison import ADAPTER

if __name__ == '__main__':
    os.environ['PATH'] = str(OUT/'tools/zig-x86_64-linux-0.16.0') + os.pathsep + os.environ['PATH']
    os.environ['SCRIPTC_TARGET'] = 'wasm32-wasi'
    os.environ['SCRIPTC_RUNTIME_PACK'] = str(OUT/'tools/scriptc/node_modules/@scriptc/runtime-wasm32-wasi')
    scriptc = OUT/'tools/scriptc/node_modules/.bin/scriptc'
    wasi = OUT/'candidate/wasi_baseline'
    assert subprocess.check_output(['zig','version'],text=True).strip() == '0.16.0'
    assert subprocess.check_output([scriptc,'--version'],text=True).strip() == '0.4.5'
    for label in ['baseline','candidate']: verify_product(label)
    cases = load(OUT/'retained-sources/manifest.json')['execution']
    adapted = OUT/'adapted-scriptc'
    adapted.mkdir()
    wasm = OUT/'scriptc-wasm'
    wasm.mkdir()
    available = {}
    for case in cases:
        name=case['file']
        source=adapted/name
        source.write_text(ADAPTER+(OUT/'sources'/name).read_text())
        event=invoke('reference-compile-'+name,[scriptc,'build',source,'-o',wasm/(name+'.wasm')],allow_failure=True)
        available[name]=dict(compile=event,wasm_sha256=digest(wasm/(name+'.wasm')) if event['exit_code']==0 else None)
    attempts=[]
    for round_index in range(2):
        for i,case in enumerate(cases if round_index==0 else list(reversed(cases))):
            name=case['file']
            order=['baseline','v8','candidate','scriptc']
            offset=(i+round_index)%4
            order=order[offset:]+order[:offset]
            if round_index: order.reverse()
            for runtime in order:
                stem=f'reference-r{round_index}-{runtime}-{name}'
                if runtime=='scriptc':
                    if available[name]['compile']['exit_code']!=0:
                        attempts.append(dict(round=round_index,runtime=runtime,file=name,status='compile-failed'))
                        continue
                    argv=[wasi,wasm/(name+'.wasm'),OUT/'expected'/name,str(SAMPLES),str(WARMUPS)]
                elif runtime=='v8':
                    argv=['node',ROOT/'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs',OUT/'sources',str(SAMPLES),str(WARMUPS),name]
                else:
                    artifacts=OUT/(stem+'-artifacts')
                    artifacts.mkdir()
                    argv=[OUT/runtime/'runtime_baseline',OUT/'sources',str(SAMPLES),str(WARMUPS),name,artifacts]
                event=invoke(stem,argv,allow_failure=runtime=='scriptc')
                if event['exit_code']!=0:
                    attempts.append(dict(round=round_index,runtime=runtime,file=name,status='run-failed',raw=stem+'.stdout'))
                    continue
                report=load(OUT/'raw'/(stem+'.stdout'))
                rows=report['observations'] if runtime=='scriptc' else report['cases'][0]['observations']
                if runtime=='scriptc' and not all(row['matched'] for row in rows):
                    attempts.append(dict(round=round_index,runtime=runtime,file=name,status='checksum-mismatch',raw=stem+'.stdout'))
                    continue
                assert len(rows)==SAMPLES+WARMUPS
                assert all(row['stdout']==case['stdout'] for row in rows)
                measured=[row for row in rows if not row['warmup']]
                if runtime in ['baseline','candidate']:
                    assert report['source_fingerprint']==load(OUT/runtime/'identity.json')['source_fingerprint']
                    times=[row['execution_ns'] for row in measured]
                    rss=[row['memory']['process_rss']['final_rss_bytes'] for row in measured]
                elif runtime=='v8':
                    times=[row['execution_ns'] for row in measured]
                    rss=[row['memory']['after']['rss'] for row in measured]
                else:
                    times=[row['execution_ns'] for row in measured]
                    rss=[row['rss_after_bytes'] for row in measured]
                attempts.append(dict(round=round_index,runtime=runtime,file=name,status='ok',times_ns=times,rss_bytes=rss,raw=stem+'.stdout'))
    summary=[]
    for case in cases:
        row=dict(file=case['file'],runtimes={})
        for runtime in ['baseline','candidate','v8','scriptc']:
            selected=[entry for entry in attempts if entry['file']==case['file'] and entry['runtime']==runtime]
            if any(entry['status']!='ok' for entry in selected):
                row['runtimes'][runtime]=dict(statuses=[entry['status'] for entry in selected])
                continue
            times=[n for entry in selected for n in entry['times_ns']]
            rss=[n for entry in selected for n in entry['rss_bytes']]
            row['runtimes'][runtime]=dict(median_ns=statistics.median(times),mean_ns=statistics.mean(times),median_rss_bytes=statistics.median(rss))
        summary.append(row)
    save(OUT/'reference-analysis.json',dict(samples=SAMPLES,warmups=WARMUPS,rounds=2,
        tools=dict(node=subprocess.check_output(['node','--version'],text=True).strip(),v8=subprocess.check_output(['node','-p','process.versions.v8'],text=True).strip(),scriptc='0.4.5',zig='0.16.0',wasi_host_sha256=digest(wasi),scriptc_package_lock_sha256=digest(OUT/'tools/scriptc/package-lock.json')),
        attempts=attempts,summary=summary,compilation=available,
        policy='Original17 unchanged workloads, with the established Scriptc print adapter. Ordinary Fast/16MiB/SinglePass Wasmtime vs V8 fresh contexts and Scriptc/WASI Fast. Compilation/setup excluded from execution. Scriptw Realm bootstrap remains timed. RSS is post-execution process endpoint; Scriptc JS frontend is a separate process. Descriptive local observations, not conformance or updated published charts.'))
