"""Original pinned affected subtrees; never publish a partial status matrix."""
import json
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
cli = OUT / 'candidate/scriptw'
identity = json.loads((OUT / 'candidate/identity.json').read_text())
scopes = [
    ('for', 'language/statements/for'),
    ('property-access', 'language/expressions/property-accessors'),
    ('sort', 'built-ins/Array/prototype/sort'),
    ('to-sorted', 'built-ins/Array/prototype/toSorted'),
]
receipts = []
for name, selection in scopes:
    directory = OUT / ('test262-' + name)
    directory.mkdir()
    argv = [str(cli), '--jobs', '1', 'test262', 'run', selection,
            '--execution-backend', 'wasm-aot', '--suite-root', 'test262/vendor/test262',
            '--snapshot-dir', str(directory), '--snapshot-name', 'numeric-array-' + name + '-20261101',
            '--threads', '1', '--timeout-ms', '60000', '--reuse-case-workers']
    started = time.monotonic()
    with (OUT / ('test262-' + name + '.stdout')).open('w') as stdout, (OUT / ('test262-' + name + '.stderr')).open('w') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=7200)
    snapshots = []
    for path in directory.glob('*.json'):
        value = json.loads(path.read_text())
        if value.get('snapshot_version') == 8:
            snapshots.append((path, value))
    assert len(snapshots) == 1, (selection, snapshots)
    path, snapshot = snapshots[0]
    assert snapshot['compiler_identity']['source_fingerprint'] == identity['source_fingerprint']
    row = dict(selection=selection, argv=argv, exit_code=result.returncode,
               elapsed_seconds=time.monotonic() - started, snapshot=str(path.relative_to(OUT)),
               passed=snapshot['passed'], total=snapshot['total'],
               counts_per_outcome=snapshot['counts_per_outcome'], failures=snapshot['failures'])
    receipts.append(row)
    (OUT / 'test262-receipt.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(selection, row['passed'], '/', row['total'], 'exit', result.returncode, flush=True)
assert all(row['exit_code'] == 0 and row['total'] > 0 and row['passed'] == row['total'] for row in receipts)
