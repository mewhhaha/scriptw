"""Run Cargo-selected native scopes serially, retaining raw inventories."""
import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import digest
from native_test_protocol import parse_inventory

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=['focused', 'broad'])
parser.add_argument('--resume', action='store_true')
args = parser.parse_args()
artifacts = {}
for line in (OUT / 'native-build.jsonl').read_text().splitlines():
    row = json.loads(line)
    if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['profile']['test']:
        artifacts[row['target']['name']] = row
targets = [('scriptw_aot_wasm', 'tests::scalar_regions::'),
           ('aot_language', 'aot_numeric_call_rows::'),
           ('aot_builtins', 'aot_array_private_buffers::'),
           ('aot_gc_entries', 'aot_gc_packed_array_storage::')]
if args.action == 'broad':
    targets = [(name, None) for name in ['scriptw_aot_wasm', 'structure_language', 'emission', 'aot_language']]
folder = OUT / ('native-' + args.action)
folder.mkdir(exist_ok=args.resume)
receipts = []
for name, selection in targets:
    producer = artifacts[name]
    path = Path(producer['executable'])
    identity = digest(path)
    listed = subprocess.check_output([path, '--list'], text=True, cwd=ROOT)
    (folder / (name + '.inventory')).write_text(listed)
    inventory = parse_inventory(listed)
    selected = [test for test in inventory if selection is None or selection in test]
    assert selected, (name, selection)
    previous = folder / (name + '.receipt.json')
    if args.resume and previous.exists():
        earlier = json.loads(previous.read_text())
        if earlier['exit_code'] == 0 and earlier['executable_sha256'] == identity and earlier['selected_inventory'] == selected:
            receipts.append(earlier)
            print(name, len(selected), 'passed scope reused; executable unchanged', flush=True)
            continue
    argv = [str(path), '--test-threads=1']
    if args.action == 'focused':
        argv.append('--nocapture')
    if selection:
        argv.append(selection)
    with (folder / (name + '.stdout')).open('w') as stdout, (folder / (name + '.stderr')).open('w') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=3600)
    summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;.*?(\d+) filtered out;', (folder / (name + '.stdout')).read_text())
    receipt = dict(target=name, selection=selection, argv=argv, executable_sha256=identity,
                   producer=producer, selected_inventory=selected, exit_code=result.returncode, summaries=summaries)
    receipts.append(receipt)
    (folder / (name + '.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    assert digest(path) == identity
    assert result.returncode == 0 and len(summaries) == 1 and int(summaries[0][1]) == len(selected), receipt
    print(name, len(selected), 'passed', flush=True)
(folder / 'receipt.json').write_text(json.dumps(receipts, indent=2) + '\n')
