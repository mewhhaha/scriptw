"""Existing three-runtime reference driver, using this frozen source cohort."""
import json
import os
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SAMPLES, WARMUPS = 7, 10
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import measure_process
from limited_verification import kernel_group, require_kernel_budget
from run import check_product as verify_product, load, save_new as save


def invoke(stem, argv, *, allow_failure=False):
    require_kernel_budget(4096 * 1024 * 1024)
    raw = OUT / 'raw'
    raw.mkdir(exist_ok=True)
    fields = ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max', 'memory.events']
    group = kernel_group()
    before = {name: (group / name).read_text() for name in fields}
    env = dict(os.environ, NODE_DISABLE_COMPILE_CACHE='1', SCRIPTW_CACHE_DIR=str(OUT / 'cache'),
               SCRIPTW_CACHE_LIMIT_BYTES=str(1024 ** 3))
    assert not env.get('NODE_OPTIONS')
    env.pop('NODE_COMPILE_CACHE', None)
    with (raw / (stem + '.stdout')).open('xb') as stdout, (raw / (stem + '.stderr')).open('xb') as stderr:
        result = measure_process(list(map(str, argv)), cwd=ROOT, env=env, stdout=stdout,
                                 stderr=stderr, timeout=900, time_binary=OUT / 'tools/time')
    after = {name: (group / name).read_text() for name in fields}
    result.update(argv=list(map(str, argv)), resources_before=before, resources_after=after,
                  affinity=sorted(os.sched_getaffinity(0)))
    save(raw / (stem + '.command.json'), result)
    assert all(before[name] == after[name] for name in fields if name != 'memory.events')
    a = dict(line.split() for line in before['memory.events'].splitlines())
    b = dict(line.split() for line in after['memory.events'].splitlines())
    assert all(a[name] == b[name] for name in ['oom', 'oom_kill', 'oom_group_kill'])
    assert not result['timed_out']
    if not allow_failure:
        assert result['exit_code'] == 0, stem
    print(stem, result['exit_code'], flush=True)
    return result
