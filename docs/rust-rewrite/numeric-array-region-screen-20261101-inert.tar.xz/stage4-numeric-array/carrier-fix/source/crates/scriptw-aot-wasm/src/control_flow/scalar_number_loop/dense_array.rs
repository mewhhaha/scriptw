//! One immutable dense Number borrow belongs to the complete scalar region.
use super::*;

pub(super) enum ArrayRead {
    Length,
    Element,
}

/// Construction fixes the sole receiver, induction binding and loop shape.
pub(super) struct DenseNumberArrayLoop {
    array: LocalBindingId,
    counter: LocalBindingId,
}

fn private_local(builder: &FunctionBuilder<'_>, expression: &TypedExpr) -> Option<LocalBindingId> {
    let ExprIr::Identifier(name) = &expression.expr else {
        return None;
    };
    if name == LEXICAL_THIS_NAME || builder.is_script_global_binding(name) {
        return None;
    }
    let BindingStorage::Local(id) = builder.lookup_binding(name)? else {
        return None;
    };
    Some(id)
}

fn is_length(key: &PropertyKeyIr) -> bool {
    match key {
        PropertyKeyIr::ArrayLength => true,
        PropertyKeyIr::StaticString(key) => key == "length",
        PropertyKeyIr::ArrayIndex(_) | PropertyKeyIr::StringExpr(_) => false,
    }
}

impl DenseNumberArrayLoop {
    pub(super) fn new(
        builder: &FunctionBuilder<'_>,
        test: &TypedExpr,
        update: Option<&TypedExpr>,
    ) -> Option<Self> {
        let (lhs, rhs) = match &test.expr {
            ExprIr::CompareNumber {
                op: RelationalBinaryOp::LessThan,
                lhs,
                rhs,
            }
            | ExprIr::CompareValue {
                op: RelationalBinaryOp::LessThan,
                lhs,
                rhs,
            } => (lhs, rhs),
            _ => return None,
        };
        let counter = private_local(builder, lhs)?;
        let ExprIr::PropertyRead { target, key } = &rhs.expr else {
            return None;
        };
        if !is_length(key) {
            return None;
        }
        let array = private_local(builder, target)?;
        let ExprIr::UpdateIdentifier {
            name,
            op: NumericUpdateOp::Increment,
            value_kind,
            ..
        } = &update?.expr
        else {
            return None;
        };
        if matches!(value_kind, NumericUpdateValueKind::BigInt)
            || builder.is_script_global_binding(name)
            || !matches!(builder.lookup_binding(name), Some(BindingStorage::Local(id)) if id == counter)
            || array == counter
        {
            return None;
        }
        Some(Self { array, counter })
    }

    pub(super) fn is_array(&self, id: LocalBindingId) -> bool {
        self.array == id
    }

    pub(super) fn counter(&self, bindings: &[NumberBinding]) -> Option<usize> {
        bindings
            .iter()
            .position(|binding| binding.id == self.counter)
    }

    pub(super) fn read(
        &self,
        builder: &FunctionBuilder<'_>,
        target: &TypedExpr,
        key: &PropertyKeyIr,
    ) -> Option<ArrayRead> {
        if private_local(builder, target)? != self.array {
            return None;
        }
        if is_length(key) {
            return Some(ArrayRead::Length);
        }
        let (PropertyKeyIr::ArrayIndex(index) | PropertyKeyIr::StringExpr(index)) = key else {
            return None;
        };
        if private_local(builder, index)? != self.counter {
            return None;
        }
        Some(ArrayRead::Element)
    }

    pub(super) fn body_preserves_counter(
        &self,
        bindings: &[NumberBinding],
        body: &[NumberExpression],
    ) -> bool {
        let Some(counter) = self.counter(bindings) else {
            return false;
        };
        let mut writes = vec![None; bindings.len()];
        for expression in body {
            expression.collect_writes(&mut writes);
        }
        writes[counter].is_none()
    }
}

/// Only this guarded constructor can root the private region's receiver and
/// backing. Nullable roots stay empty whenever the original loop must run.
pub(super) struct DenseArrayBorrow {
    array: GcLocal<ArrayObject, Nullable>,
    numbers: GcLocal<NumberBitsI64Array, Nullable>,
    length: I64Local,
    slot: I32Local,
}

impl DenseArrayBorrow {
    pub(super) fn new(
        plan: &DenseNumberArrayLoop,
        builder: &mut FunctionBuilder<'_>,
        accepted: I32Local,
        function: &mut Function,
    ) -> Self {
        let s = builder.runtime_schema();
        let borrow = Self {
            array: s.reserve_gc_local(function).initialize_null(s, function),
            numbers: s.reserve_gc_local(function).initialize_null(s, function),
            length: s.reserve_i64_local(function),
            slot: s.reserve_i32_local(function),
        };
        borrow.length.set_constant(0, function);
        accepted.load(function);
        builder.open_frame(ControlFrameKind::If, function);
        accepted.set_constant(0, function);
        let decline = builder.open_frame(ControlFrameKind::Block, function);
        let source = builder.local_binding(plan.array);
        if let Some(initialized) = source.initialization_check() {
            initialized.load(function);
            function.instruction(&Instruction::I32Eqz);
            builder.emit_branch_if_to_target(decline, function);
        }
        builder
            .local_binding(plan.array)
            .value()
            .tag()
            .load(function);
        function.instruction(&Instruction::I32Const(WasmRuntimeValueTag::Array.tag()));
        function.instruction(&Instruction::I32Ne);
        builder.emit_branch_if_to_target(decline, function);
        builder
            .local_binding(plan.array)
            .value()
            .reference()
            .load(function);
        function.instruction(&Instruction::RefTestNonNull(
            s.reference_type::<ArrayObject>(crate::gc_types::GcNullability::NonNullable)
                .heap_type,
        ));
        function.instruction(&Instruction::I32Eqz);
        builder.emit_branch_if_to_target(decline, function);
        borrow.array.replace(
            builder
                .local_binding(plan.array)
                .value()
                .cast_reference::<ArrayObject>(s, function)
                .nullable(),
            function,
        );
        s.field(ArrayObjectSchema::MODE)
            .read(&borrow.array, s, function);
        function.instruction(&Instruction::I32Const(
            ArrayIndexedStorageMode::PackedNumbers.encode(),
        ));
        function.instruction(&Instruction::I32Ne);
        builder.emit_branch_if_to_target(decline, function);
        s.field(ArrayObjectSchema::LENGTH)
            .read(&borrow.array, s, function)
            .store_i64(borrow.length, function);
        borrow.length.load(function);
        function.instruction(&Instruction::I64Const(1 << 20));
        function.instruction(&Instruction::I64GtU);
        builder.emit_branch_if_to_target(decline, function);
        s.field(ArrayObjectSchema::COUNT)
            .read(&borrow.array, s, function);
        borrow.length.load(function);
        function.instruction(&Instruction::I64Ne);
        builder.emit_branch_if_to_target(decline, function);
        borrow.numbers.replace(
            s.field(ArrayObjectSchema::NUMBERS)
                .read(&borrow.array, s, function)
                .reference()
                .nullable(),
            function,
        );
        s.array_type::<NumberBitsI64Array>()
            .length(&borrow.numbers, s, function);
        function.instruction(&Instruction::I64ExtendI32U);
        borrow.length.load(function);
        function.instruction(&Instruction::I64LtU);
        builder.emit_branch_if_to_target(decline, function);
        let counter = builder.local_binding(plan.counter).value().scalar();
        // The enclosing scalar guard established this initialized Number.
        // Keep binary64 storage so an untouched negative zero stays negative.
        counter.load(function);
        function.instruction(&Instruction::F64ReinterpretI64);
        function.instruction(&Instruction::F64Const(Ieee64::from(0.0)));
        function.instruction(&Instruction::F64Ge);
        function.instruction(&Instruction::I32Eqz);
        builder.emit_branch_if_to_target(decline, function);
        counter.load(function);
        function.instruction(&Instruction::F64ReinterpretI64);
        borrow.length.load(function);
        function.instruction(&Instruction::F64ConvertI64U);
        function.instruction(&Instruction::F64Le);
        function.instruction(&Instruction::I32Eqz);
        builder.emit_branch_if_to_target(decline, function);
        counter.load(function);
        function.instruction(&Instruction::F64ReinterpretI64);
        counter.load(function);
        function.instruction(&Instruction::F64ReinterpretI64);
        function.instruction(&Instruction::F64Trunc);
        function.instruction(&Instruction::F64Ne);
        builder.emit_branch_if_to_target(decline, function);
        accepted.set_constant(1, function);
        builder.pop_control(ControlFrameKind::Block);
        function.instruction(&Instruction::End);
        builder.pop_control(ControlFrameKind::If);
        function.instruction(&Instruction::End);
        accepted.load(function);
        function.instruction(&Instruction::I32Eqz);
        builder.open_frame(ControlFrameKind::If, function);
        borrow.array.set_null(s, function);
        borrow.numbers.set_null(s, function);
        builder.pop_control(ControlFrameKind::If);
        function.instruction(&Instruction::End);
        borrow
    }

    pub(super) fn emit_length(&self, function: &mut Function) {
        self.length.load(function);
        function.instruction(&Instruction::F64ConvertI64U);
    }

    pub(super) fn emit_element(
        &self,
        counter: LoopLocal,
        builder: &FunctionBuilder<'_>,
        function: &mut Function,
    ) {
        let s = builder.runtime_schema();
        counter.load_number(function);
        function.instruction(&Instruction::I32TruncSatF64U);
        self.slot.store(function);
        // Entry plus the unchanged i < length / i++ shape proves this own
        // Number exists. No admitted operation can mutate or expose the borrow.
        s.array_type::<NumberBitsI64Array>()
            .read(&self.numbers, self.slot, s, function);
        function.instruction(&Instruction::F64ReinterpretI64);
    }

    pub(super) fn release(self, builder: &FunctionBuilder<'_>, function: &mut Function) {
        let s = builder.runtime_schema();
        self.numbers.clear(function);
        self.array.clear(function);
        s.release_i32_local(self.slot, function);
        s.release_i64_local(self.length, function);
    }
}
