from pathlib import Path

view='''/// A borrowed projection of the two canonical property-read carriers. It
/// recognizes syntax only; the sealed Array plan still admits the exact key,
/// receiver and induction binding before any read can enter a Number region.
#[derive(Clone, Copy)]
pub(super) struct PropertyReadView<'a> {
    pub(super) target: &'a TypedExpr,
    pub(super) key: ReadKey<'a>,
}

#[derive(Clone, Copy)]
pub(super) enum ReadKey<'a> {
    StaticString(&'a str),
    Computed(&'a TypedExpr),
    Length,
}

impl ReadKey<'_> {
    fn is_length(self) -> bool {
        match self {
            Self::Length => true,
            Self::StaticString(key) => key == "length",
            Self::Computed(_) => false,
        }
    }
}

impl<'a> PropertyReadView<'a> {
    pub(super) fn of(value: &'a TypedExpr) -> Option<Self> {
        let (target, key) = match &value.expr {
            ExprIr::PropertyRead { target, key } => {
                let key = match key {
                    PropertyKeyIr::StaticString(key) => ReadKey::StaticString(key),
                    PropertyKeyIr::StringExpr(key) | PropertyKeyIr::ArrayIndex(key) => ReadKey::Computed(key),
                    PropertyKeyIr::ArrayLength => ReadKey::Length,
                };
                (target.as_ref(), key)
            }
            ExprIr::SpecOperation { operation: SpecOperationIr::GetV, operands } => {
                let [target, key] = operands.as_slice() else { return None; };
                let key = match &key.expr {
                    ExprIr::String(key) => ReadKey::StaticString(key),
                    ExprIr::Identifier(_) => ReadKey::Computed(key),
                    _ => return None,
                };
                (target, key)
            }
            _ => return None,
        };
        Some(Self { target, key })
    }
}

'''

def update_dense(path, draft):
    s=path.read_text()
    start=s.index('fn is_length(')
    end=s.index('\nimpl ',start)
    s=s[:start]+view+s[end:]
    old='''        let ExprIr::PropertyRead { target, key } = &rhs.expr else {
            return None;
        };
        if !is_length(key) {
            return None;
        }
        let array = private_local(builder, target)?;'''
    new='''        let read = PropertyReadView::of(rhs)?;
        if !read.key.is_length() {
            return None;
        }
        let array = private_local(builder, read.target)?;'''
    assert old in s;s=s.replace(old,new,1)
    if draft:
        old='''        let ExprIr::PropertyRead { target, key } = &value.expr else {
            return false;
        };
        private_local(builder, target) == Some(self.array) && self.is_counter_key(builder, key)'''
        new='''        let Some(read) = PropertyReadView::of(value) else { return false; };
        private_local(builder, read.target) == Some(self.array) && self.is_counter_key(builder, read.key)'''
        assert old in s;s=s.replace(old,new,1)
        s=s.replace('fn is_counter_key(&self, builder: &FunctionBuilder<\'_>, key: &PropertyKeyIr)', 'fn is_counter_key(&self, builder: &FunctionBuilder<\'_>, key: ReadKey<\'_>)',1)
        s=s.replace('''        let (PropertyKeyIr::ArrayIndex(index) | PropertyKeyIr::StringExpr(index)) = key else {
            return false;
        };''','''        let ReadKey::Computed(index) = key else { return false; };''',1)
        s=s.replace('''        target: &TypedExpr,
        key: &PropertyKeyIr,
    ) -> Option<(ArrayRead, Option<LocalBindingId>)> {
        if private_local(builder, target) == Some(self.array) {
            if is_length(key) {''','''        read: PropertyReadView<'_>,
    ) -> Option<(ArrayRead, Option<LocalBindingId>)> {
        if private_local(builder, read.target) == Some(self.array) {
            if read.key.is_length() {''',1)
        s=s.replace('self.is_counter_key(builder, key)', 'self.is_counter_key(builder, read.key)',1)
        s=s.replace('CompactReadPath::new(builder, target, key)?', 'CompactReadPath::new(builder, read)?',1)
    else:
        old='''        target: &TypedExpr,
        key: &PropertyKeyIr,
    ) -> Option<ArrayRead> {
        if private_local(builder, target)? != self.array {
            return None;
        }
        if is_length(key) {
            return Some(ArrayRead::Length);
        }
        let (PropertyKeyIr::ArrayIndex(index) | PropertyKeyIr::StringExpr(index)) = key else {
            return None;
        };'''
        new='''        read: PropertyReadView<'_>,
    ) -> Option<ArrayRead> {
        if private_local(builder, read.target)? != self.array {
            return None;
        }
        if read.key.is_length() {
            return Some(ArrayRead::Length);
        }
        let ReadKey::Computed(index) = read.key else { return None; };'''
        assert old in s;s=s.replace(old,new,1)
    path.write_text(s)

def update_parent(path,draft):
    s=path.read_text()
    if draft:
        s=s.replace('use dense_array::{ArrayRead, ArrayReadBorrow, ArrayReadLoop};','use dense_array::{ArrayRead, ArrayReadBorrow, ArrayReadLoop, PropertyReadView};',1)
    else:
        s=s.replace('use dense_array::{ArrayRead, DenseArrayBorrow, DenseNumberArrayLoop};','use dense_array::{ArrayRead, DenseArrayBorrow, DenseNumberArrayLoop, PropertyReadView};',1)
    start=s.index('            ExprIr::PropertyRead { target, key } => {',s.index('    fn expression('))
    end=s.index('            ExprIr::MaterializeBinding',start)
    branch=s[start:end]
    contents=branch[branch.index('\n')+1:branch.rindex('            }')]
    if draft:
        contents=contents.replace('self.array.as_mut()?.read(self.builder, target, key)?','self.array.as_mut()?.read(self.builder, read)?')
    else:
        contents=contents.replace('array.read(self.builder, target, key)?','array.read(self.builder, read)?')
    # The match expression formerly supplied the surrounding Some(match...).
    contents=contents.replace('                match ', '                return Some(match ',1)
    end_match=contents.rfind('                }')
    contents=contents[:end_match]+contents[end_match:].replace('                }','                });',1)
    contents='\n'.join(line[4:] if line.startswith('    ') else line for line in contents.split('\n'))
    block='''        if let Some(read) = PropertyReadView::of(value) {
'''+contents+'''        }
'''
    s=s[:start]+s[end:]
    needle='''        let depth = self.visit(depth)?;
        Some(match &value.expr {'''
    assert needle in s;s=s.replace(needle,'''        let depth = self.visit(depth)?;
'''+block+'''        Some(match &value.expr {''',1)
    path.write_text(s)

prod=Path('crates/scriptw-aot-wasm/src/control_flow')
update_dense(prod/'scalar_number_loop/dense_array.rs',False)
update_parent(prod/'scalar_number_loop.rs',False)
draft=Path('target/performance-compact-path-draft/source/crates/scriptw-aot-wasm/src/control_flow')
update_dense(draft/'scalar_number_loop/dense_array.rs',True)
update_parent(draft/'scalar_number_loop.rs',True)
p=draft/'scalar_number_loop/compact_path.rs';s=p.read_text()
s=s.replace('''        target: &'a TypedExpr,
        key: &PropertyKeyIr,
    ) -> Option<(Self, &'a TypedExpr)> {
        if let PropertyKeyIr::StaticString(name) = key {
            return Some((Self::Number(CachedReadName::new(builder, name)?), target));
        }
        let (PropertyKeyIr::ArrayIndex(index) | PropertyKeyIr::StringExpr(index)) = key else {
            return None;
        };
        let index = dense_array::private_local(builder, index)?;
        let ExprIr::PropertyRead {
            target: row,
            key: PropertyKeyIr::StaticString(name),
        } = &target.expr
        else {
            return None;
        };''','''        read: PropertyReadView<'a>,
    ) -> Option<(Self, &'a TypedExpr)> {
        if let dense_array::ReadKey::StaticString(name) = read.key {
            return Some((Self::Number(CachedReadName::new(builder, name)?), read.target));
        }
        let dense_array::ReadKey::Computed(index) = read.key else { return None; };
        let index = dense_array::private_local(builder, index)?;
        let inner = PropertyReadView::of(read.target)?;
        let dense_array::ReadKey::StaticString(name) = inner.key else { return None; };
        let row = inner.target;''',1)
p.write_text(s)
