
function mutate(a) {
  'use strict';
  var total = 0;
  for (var i = 0; i < a.length; i++) { total += (i + 1) * a[i]; if (i === 0) a[1] = 9; }
  return total === 20 && i === 2;
}
function capture(a) {
  'use strict';
  var total = 0, seen = [];
  function observe() { seen.push(total); if (seen.length === 1) a.length = 1; }
  for (var i = 0; i < a.length; i++) { total += (i + 1) * a[i]; observe(); }
  return total === 2 && i === 1 && seen.join('|') === '2';
}
function shift(a) {
  'use strict';
  var total = 0;
  for (var i = 0; i < a.length; i++) { total += (i + 1) * a[i]; i++; }
  return total === 20 && i === 4;
}
function replace(a, b) {
  'use strict';
  var total = 0;
  for (var i = 0; i < a.length; i++) { total += (i + 1) * a[i]; a = b; }
  return total === 2 && i === 1;
}
mutate([2, 4]) && capture([2, 4, 6]) && shift([2, 4, 6]) && replace([2, 4, 6], [9]);
