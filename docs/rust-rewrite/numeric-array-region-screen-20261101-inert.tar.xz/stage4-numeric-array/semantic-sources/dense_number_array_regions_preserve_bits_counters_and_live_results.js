
function weighted(a, start, total) {
  'use strict';
  for (var i = start; i < a.length; i++) total += (i + 1) * a[i];
  return [total, i];
}
var a = [], expected = 0;
for (var i = 0; i < 129; i++) { a.push(i + 0.5); expected += (i + 1) * (i + 0.5); }
gc();
var dense = weighted(a, 0, 0), zeros = weighted([-0, -0], -0, -0);
var empty = weighted([], -0, -0), offset = weighted([1, 2, 3], 1, 5);
var fractional = weighted([1, 2, 3], 0.5, 0), infinity = weighted([1], Infinity, 7);
var nanStart = weighted([1], NaN, 8), nanValue = weighted([NaN, 1], 0, 0);
var infinities = weighted([Infinity, -Infinity], 0, 0);
var negative = [1, 2, 3]; negative[-1] = 7;
var negativeStart = weighted(negative, -1, 0), strings = weighted(['2', 3], 0, 0);
var subclass = class extends Array {};
var derived = weighted(new subclass(1, 2, 3), 0, 0);
var sealed = weighted(Object.seal([1, 2, 3]), 0, 0);
var frozen = weighted(Object.freeze([1, 2, 3]), 0, 0);
var fixed = weighted(Object.preventExtensions([1, 2, 3]), 0, 0);
gc();
dense[0] === expected && dense[1] === 129 && a[0] === 0.5 && a[128] === 128.5 &&
Object.is(zeros[0], -0) && zeros[1] === 2 &&
Object.is(empty[0], -0) && Object.is(empty[1], -0) &&
offset[0] === 18 && offset[1] === 3 &&
Number.isNaN(fractional[0]) && fractional[1] === 3.5 &&
infinity[0] === 7 && infinity[1] === Infinity &&
nanStart[0] === 8 && Number.isNaN(nanStart[1]) &&
Number.isNaN(nanValue[0]) && nanValue[1] === 2 &&
Number.isNaN(infinities[0]) && infinities[1] === 2 &&
negativeStart[0] === 14 && negativeStart[1] === 3 && strings[0] === 8 &&
derived[0] === 14 && sealed[0] === 14 && frozen[0] === 14 && fixed[0] === 14;
