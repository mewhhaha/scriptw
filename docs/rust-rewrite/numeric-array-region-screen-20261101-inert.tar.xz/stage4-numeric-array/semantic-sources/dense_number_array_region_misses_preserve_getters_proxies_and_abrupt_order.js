
function weighted(a) {
  'use strict';
  var total = 0;
  for (var i = 0; i < a.length; i++) total += (i + 1) * a[i];
  return [total, i];
}
var events = [], holey = [2, , 6], proto = Object.create(Array.prototype);
Object.defineProperty(proto, '1', {get() { events.push('inherited'); holey.length = 2; gc(); return 4; }});
Object.setPrototypeOf(holey, proto);
var holes = weighted(holey);
if (holes[0] !== 10 || holes[1] !== 2 || events.join('|') !== 'inherited') throw 'live inherited hole';
events = [];
var accessor = [2, 4, 6];
Object.defineProperty(accessor, '0', {get() {
  events.push('own'); accessor[1] = {valueOf() { events.push('convert'); gc(); return 5; }};
  return 3;
}});
var own = weighted(accessor);
if (own[0] !== 31 || own[1] !== 3 || events.join('|') !== 'own|convert') throw 'live own accessor';
events = [];
var proxy = new Proxy([2, 4], {get(target, key, receiver) {
  events.push(key); gc(); return Reflect.get(target, key, receiver);
}});
var trapped = weighted(proxy);
if (trapped[0] !== 10 || trapped[1] !== 2 || events.join('|') !== 'length|0|length|1|length') throw 'Proxy get order';
events = [];
var reads = 0, object = {get length() { events.push('length'); return ++reads === 1 ? 3 : 1; },
  get 0() { events.push('zero'); return 2; }};
var ordinary = weighted(object);
if (ordinary[0] !== 2 || ordinary[1] !== 1 || events.join('|') !== 'length|zero|length') throw 'live generic length';
events = [];
var sentinel = {}, throwing = [2, 4, 6], caught;
Object.defineProperty(throwing, '1', {get() { events.push('throw'); gc(); throw sentinel; }});
try { weighted(throwing); } catch (error) { caught = error; }
caught === sentinel && events.join('|') === 'throw';
