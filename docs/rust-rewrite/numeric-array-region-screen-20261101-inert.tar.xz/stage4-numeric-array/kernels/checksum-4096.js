function checksum(a){'use strict';var total=0;for(var i=0;i<a.length;i++)total+=(i+1)*a[i];return total;}
var a=[];for(var i=1;i<=4096;i++)a.push(i);var total=0;for(var repeat=0;repeat<16;repeat++)total+=checksum(a);print(total);
