from pathlib import Path
import subprocess, hashlib, json, datetime
root = Path('/workspace/scriptw')
base = root / 'target/performance-append-key-summary-20261031'
old = root / 'target/performance-date-demand-20261031'
paths = subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines()
paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines()
rows = {}
for name in paths:
    source = Path(name)
    data = source.read_bytes()
    rows[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    destination = base / 'implementation' / source
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
(base / 'compiled-inputs.json').write_text(json.dumps(rows, indent=2) + '\n')
patch = subprocess.check_output(['git', 'diff', '--binary'])
for name in subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines():
    patch += subprocess.run(['git', 'diff', '--no-index', '--binary', '/dev/null', name], capture_output=True).stdout
(base / 'compile-inputs.patch').write_bytes(patch)
identity = json.loads((old / 'candidate/identity.json').read_text())
products = json.loads((old / 'candidate/products.json').read_text())
assert identity['source_fingerprint'] == 'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480'
for name, data in [('baseline-identity.json', identity), ('baseline-products.json', products)]:
    (base / name).write_text(json.dumps(data, indent=2) + '\n')
published = json.loads((old / 'post-build-documentation-proof.json').read_text())['published_inputs']
checks = {}
for name, row in published.items():
    data = subprocess.check_output(['git', 'show', 'HEAD:' + name])
    assert hashlib.sha256(data).hexdigest() == row['sha256'], name
    checks[name] = row
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert parent == 'a9d31bddb6fa2efc81315e46d1798d78b1d314b6'
proof = dict(accepted_commit=parent, original_identity=identity, baseline_products=products,
             committed_parent_matches_all61_Date_published_inputs=checks,
             source='Actual frozen Date product original7c47+exactpatch identity retained; do not retag as an a9d31 build.')
(base / 'baseline-reuse-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
state = dict(phase='15 source/test/doc inputs frozen; 359 guards, 30 owners, 15 Intl recipes, 11 changed-Rust fmt pass; Astra source review clear; native planned',
             parent=parent, baseline=identity['source_fingerprint'], layout_before=42, layout_after=43,
             updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(base / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
print('Frozen', len(rows), 'files')
