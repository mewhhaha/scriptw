"""Assemble complete append-key-summary evidence from inert records only; never run products."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = 'a9d31bddb6fa2efc81315e46d1798d78b1d314b6'
BASELINE = 'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480'
BASELINE_SOURCE = '7c47e38274c9645b6701552c87d38362b2bfbcd5'
ORDER = ['baseline', 'candidate', 'candidate', 'baseline',
         'candidate', 'baseline', 'baseline', 'candidate']
DATE_FILES = ['date-first-descriptor.js', 'date-first-epoch.js', 'date-repeated-256.js']


def require(value, message):
    if not value:
        raise ValueError(message)


def inert(path, limit=16 * 1024**2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= limit,
            'missing, nonregular or oversized inert input: ' + str(path))
    require(path.suffix in {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.gz',
                           '.rs', '.md', '.py', '.patch', '.js', '.mjs', '.cjs', '.txt'},
            'inert metadata/source/log required: ' + str(path))
    return path


def read(name):
    path = Path(name)
    return json.loads(inert(path if path.is_absolute() else OUT / path).read_text())


def digest(path):
    # Native product/image files are never opened; identities come from receipts.
    return hashlib.sha256(inert(path).read_bytes()).hexdigest()


def origin(path, expected_sha256=None, archive=False):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    require(path.is_relative_to(ROOT), 'raw origin outside workspace')
    actual = digest(path)
    require(expected_sha256 is None or actual == expected_sha256, 'raw origin digest differs: ' + str(path))
    archived = path
    if archive and not path.is_relative_to(OUT):
        archived = OUT / 'raw-streams' / path.name
        archived.parent.mkdir(exist_ok=True)
        if archived.exists():
            require(digest(archived) == actual, 'archived raw stream differs')
        else:
            with archived.open('xb') as stream:
                stream.write(path.read_bytes())
    return dict(origin=str(path.relative_to(ROOT)), sha256=actual,
                archive_path=str(archived.relative_to(OUT)) if archived.is_relative_to(OUT) else None)


def native_case(directory, case):
    inventory = origin(case['inventory_log'], case['inventory_sha256'])
    inventory_text = (ROOT / inventory['origin']).read_text()
    names = re.findall(r'^(.+): test$', inventory_text, re.M)
    require(len(names) == len(set(names)) == case['inventoried_tests'] > 0,
            'native inventory differs: ' + directory)
    stream = origin(case['transcript_log'], case['transcript_sha256'], archive=True)
    text = (ROOT / stream['origin']).read_text()
    printed = re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    # libtest annotates #[should_panic] execution labels, while --list emits the
    # canonical Rust test name without that suffix.
    actual = [(name.removesuffix(' - should panic'), status) for name, status in printed]
    require(len(actual) == len(names) and {name for name, _ in actual} == set(names),
            'native transcript does not cover its inventory: ' + directory)
    totals = dict(passed=sum(status == 'ok' for _, status in actual),
                  failed=sum(status == 'FAILED' for _, status in actual),
                  ignored=sum(status == 'ignored' for _, status in actual))
    require(case['outcomes'] == [totals] and totals['ignored'] == 0, 'native outcome differs')
    summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    require(summaries == [(str(totals['passed']), str(totals['failed']), '0')],
            'native summary differs')
    failed = totals['failed'] > 0
    require(case['build_exit'] == 0 and case['state'] == ('failed' if failed else 'passed') and
            case['exit_code'] == (101 if failed else 0) and case['inventory_matches'] is (not failed),
            'native completion/inventory state differs')
    for row in case['sealed_build_logs']:
        origin(row['path'], row['gzip_sha256'])
    keys = {(case['package'], case['target'], name): status for name, status in actual}
    return dict(receipt=directory + '/receipt.json', package=case['package'], target=case['target'],
                filter=case.get('native_filter'), outcomes=totals, inventory=inventory,
                failing_tests=[name for name, status in actual if status == 'FAILED'],
                transcript=stream, executable_sha256=case['executable_sha256'],
                executable_bytes=case['executable_bytes'],
                executable_released_by_driver=case['executable_released']), keys


def source_and_native():
    inputs, summary = read('compiled-inputs.json'), read('native-summary-start0.json')
    plan = read('plan.json')
    require(len(inputs) == 15 and plan['parent'] == PARENT and
            plan['layout'] == dict(before=42, after=43), 'frozen15-input/ABI plan differs')
    for name, record in inputs.items():
        path = OUT / 'implementation' / name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and
                path.stat().st_size == record['bytes'] and digest(path) == record['sha256'],
                'frozen source snapshot differs: ' + name)
    runtime_source = OUT / 'implementation/crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    require(re.search(r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*43\s*;', runtime_source.read_text()),
            'ABI43 source authority absent')
    require(summary['complete'] is True and summary['all_passed'] is True and
            len(summary['scopes']) == len(plan['native']['scopes']) == 7, 'native seven-scope coverage incomplete')
    counts = [572, 41, 31, 13, 3, 14, 4]
    rows, selected, source_map, retained = [], {}, None, None
    for index, (planned, run, count) in enumerate(zip(plan['native']['scopes'], summary['scopes'], counts)):
        target = 'scriptw_aot_wasm' if planned['target'] == 'lib' else planned['target']
        directory = f'native-{index:02d}-{planned["target"]}'
        require(run == dict(index=index, label=directory, target=planned['package'] + ':' + target,
                            filter=planned['filter'], exit_code=0), 'native summary/plan selector differs')
        receipt = read(directory + '/receipt.json')
        require(receipt['head'] == PARENT and receipt['source_unchanged'] is True and
                receipt['shared_runtime_linker_unchanged'] is True and receipt['profile'] == 'release' and
                receipt['all_features'] is False and receipt['include_ignored'] is False and
                set(receipt['selected_workspace_packages']) == {'scriptw-aot-wasm', 'scriptw-engine'} and
                receipt['preserve_test_artifacts'] is True and len(receipt['cases']) == 1,
                'native source/features/selection changed')
        start = read(directory + '/source-start.json')
        actual_map = hashlib.sha256(json.dumps(start, sort_keys=True).encode()).hexdigest()
        require(actual_map == receipt['source_map_sha256'] and
                (source_map is None or source_map == actual_map), 'native source map differs across scopes')
        source_map = actual_map
        schedule = receipt['scheduling']
        require(schedule['cargo_jobs'] == schedule['test_processes'] == schedule['test_threads_per_process'] == 1,
                'native serial policy differs')
        case = receipt['cases'][0]
        require(case['package'] == planned['package'] and case['target'] == target and
                case.get('native_filter') == planned['filter'], 'native receipt selector differs')
        row, tests = native_case(directory, case)
        require(row['outcomes'] == dict(passed=count, failed=0, ignored=0) and len(tests) == count and
                not (selected.keys() & tests.keys()), 'native counts overlap or differ')
        lifecycle = read(directory + '/native-image-retirement.json')
        records = [record for record in lifecycle['records'] if record['selected']]
        require(lifecycle['exit_code'] == 0 and len(records) == 1 and
                records[0]['sha256'] == case['executable_sha256'] and
                records[0]['bytes'] == case['executable_bytes'], 'selected image lifecycle identity differs')
        selected_image = records[0]
        if index == 3:
            require(selected_image['action'] ==
                    'retained exact passing image for next filter in same Cargo selector',
                    'first builtins image was not retained for its next filter')
            retained = dict(record=selected_image, selector=case['selector'],
                            source_map_sha256=actual_map, receipt=directory + '/receipt.json')
        else:
            require(selected_image['action'] == 'retired exact passing image after complete source-bound transcript',
                    'selected passing image was not retired')
        if index == 4:
            require(retained is not None and
                    all(selected_image[key] == retained['record'][key] for key in ['path', 'sha256', 'bytes']) and
                    case['selector'] == retained['selector'] and actual_map == retained['source_map_sha256'],
                    'same-selector builtins keep/use/retire chain differs')
        row.update(source_map_sha256=actual_map, source_start=start, scheduling=schedule,
                   selector=case['selector'], lifecycle=lifecycle)
        rows.append(row)
        selected.update(tests)
    require(len(selected) == sum(counts) == 678 and set(selected.values()) == {'ok'},
            'native678 distinct passing union differs')
    layout_test = ('scriptw-aot-wasm', 'scriptw_aot_wasm',
                   'gc_types::type_registration_tests::compact_records::dictionary_indexed_key_summary_fills_existing_copying_collector_padding')
    emission_test = ('scriptw-aot-wasm', 'emission',
                     'guarded_push::fixed_push_proves_actual_native_then_keeps_argument_allocations_in_fallback')
    require(selected.get(layout_test) == 'ok' and selected.get(emission_test) == 'ok',
            'actual dictionary collector/encoded append proof did not pass')
    layout = (OUT / 'implementation/crates/scriptw-aot-wasm/src/gc_types/type_registration_tests/compact_records.rs').read_text()
    flat = re.sub(r'\s+', '', layout)
    require('assert_eq!(layout.size,32);' in flat and 'assert_eq!(layout.align,16);' in flat and
            '[(16,true),(20,false),(24,true),(28,false)]' in flat,
            'recorded dictionary allocation/edge layout differs from the passing frozen test')
    relocation = read('cargo-build-cache-relocation.json')
    require(relocation['logical_paths_preserved'] is True and relocation['normal_benchmark_cache_unchanged'] is True,
            'Cargo cache relocation changed benchmark cache semantics')
    return dict(inputs=inputs, snapshot='compiled-inputs.json', patch_sha256=digest(OUT / 'compile-inputs.patch'),
                source_map_sha256=source_map, scopes=rows, unique_passes=678, failures=[], repairs=[],
                shared_builtins_image_chain=dict(first=rows[3]['receipt'], second=rows[4]['receipt'],
                                                sha256=retained['record']['sha256'],
                                                bytes=retained['record']['bytes'],
                                                explanation='13 private-buffer checks then3 intrinsic-installation checks used the same retained Cargo selector image; second scope retired the exact image.'),
                dictionary_layout=dict(test=layout_test[2], bytes=32, alignment=16, gc_edges=2,
                                       gc_edge_offsets=[16, 24], summary_offset=28, result='passed'),
                encoded_append_proof=dict(test=emission_test[2], result='passed'),
                cargo_build_cache_relocation=relocation,
                scope='Seven exact normal-two-package scopes; filtered Engine inventories remain explicit. No repair/replay union or full-workspace claim.')


def product_metadata():
    identities = {label: read('baseline-identity.json' if label == 'baseline' else 'candidate/identity.json')
                  for label in ['baseline', 'candidate']}
    products = {label: read('baseline-products.json' if label == 'baseline' else 'candidate/products.json')
                for label in identities}
    require(identities['baseline']['source_fingerprint'] == BASELINE and
            identities['baseline']['source_commit'] == BASELINE_SOURCE and
            identities['candidate']['source_fingerprint'] != BASELINE and
            identities['candidate']['source_commit'] == PARENT, 'DATE-parent/APPEND source identity differs')
    for label, identity in identities.items():
        require(set(products[label]) == {'scriptw', 'runtime_baseline', 'compiler_precompiled_baseline'} and
                products[label]['compiler_precompiled_baseline']['sha256'] == identity['executable_sha256'] and
                identity['shared_configuration'] == identities['baseline']['shared_configuration'],
                'frozen product metadata differs')
    build, reuse = read('candidate-build.json'), read('baseline-reuse-proof.json')
    require(build['exit_code'] == 0 and build['head'] == PARENT and reuse['accepted_commit'] == PARENT and
            reuse['original_identity'] == identities['baseline'] and reuse['baseline_products'] == products['baseline'] and
            len(reuse['committed_parent_matches_all61_Date_published_inputs']) == 61,
            'candidate build or accepted61-input Date reuse proof differs')
    return dict(identities=identities, products=products, candidate_build=build, accepted_baseline_reuse_proof=reuse,
                identity_note='Accepted a9d31 parent reuses the actual a35 Date products built at7c47 plus their original frozen patch; those products are not retagged as an a9 build.')


def test262_evidence(products):
    plan, summary = read('test262-selection.json'), read('test262-candidate-summary.json')
    entries = {row['path']: row for row in plan['entries']}
    require(len(entries) == plan['original_file_count'] == len(summary['runs']) == 36,
            'original36 Test262 selection incomplete')
    root = ROOT / plan['suite_root'] / 'test'
    push = {str(path.relative_to(root)) for path in (root / 'built-ins/Array/prototype/push').rglob('*.js')}
    require(len(push) == 24 and push <= set(entries), 'complete24 original push family differs')
    actual, variants, raws = set(), 0, []
    for run in summary['runs']:
        name = run['scope']
        require(name in entries and name not in actual and run['product'] == 'candidate' and
                run['exit_code'] == 0 and run['total'] == run['passed'] > 0 and
                run['executable_sha256'] == products['products']['candidate']['scriptw']['sha256'],
                'Test262 run incomplete, duplicated or wrong product')
        path = root / name
        require(path.stat().st_size == entries[name]['bytes'] and digest(path) == entries[name]['sha256'],
                'original Test262 source differs')
        argv = run['argv']
        require(argv[0] == str(OUT / 'candidate/scriptw') and argv[argv.index('run') + 1] == name and
                argv[argv.index('--execution-backend') + 1] == 'wasm-aot' and
                Path(run['raw']).name == run['raw'], 'Test262 raw selector/backend differs')
        raw = inert(OUT / run['raw']).read_text()
        require(re.findall(r'^total: (\d+)$', raw, re.M) == [str(run['total'])] and
                re.findall(r'^passed: (\d+)$', raw, re.M) == [str(run['passed'])], 'Test262 raw totals differ')
        actual.add(name)
        variants += run['passed']
        raws.append(origin(OUT / run['raw']))
    require(actual == set(entries), 'Test262 original-file coverage differs')
    return dict(original_files=36, complete_push_files=24, adjoining_subset_files=12,
                actual_passing_variants=variants, selection=plan, summary=summary, raw_origins=raws,
                scope='Complete pinned push family plus12 explicit originals; no complete Array/Object/Reflect/full-Test262 or status publication claim.')


def measurement_evidence(products):
    directory = OUT / 'measurement'
    lock = read(directory / 'product-lock.json')
    hashes, plan = read(directory / 'source-hashes.json'), read(directory / 'sources/manifest.json')
    canonical = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
    canonical_plan = read(canonical / 'manifest.json')
    cases = [*plan['execution'], plan['startup']]
    require(len(cases) == len({case['file'] for case in cases}) == 21 and
            [case['file'] for case in plan['execution'][17:]] == DATE_FILES and lock['source_hashes'] == hashes,
            'measurement21 source inventory differs')
    require(plan['execution'][:17] == canonical_plan['execution'] and
            plan['startup'] == canonical_plan['startup'], 'canonical source gate changed')
    for case in [*canonical_plan['execution'], canonical_plan['startup']]:
        require(digest(directory / 'sources' / case['file']) == digest(canonical / case['file']),
                'canonical source copy changed: ' + case['file'])
    for name, sha in hashes.items():
        require(Path(name).name == name and digest(directory / 'sources' / name) == sha, 'measurement source changed')
    for name, sha in lock['support'].items():
        require(digest(ROOT / name) == sha, 'bound measurement validator/support changed')
    for label in ['baseline', 'candidate']:
        require(lock[label]['identity'] == products['identities'][label] and
                lock[label]['expected_runtime_abi'] == (42 if label == 'baseline' else 43), 'measurement product identity differs')
        for tool in ['compiler_precompiled_baseline', 'runtime_baseline']:
            require(lock[label]['products'][tool]['sha256'] == products['products'][label][tool]['sha256'] and
                    lock[label]['products'][tool]['bytes'] == products['products'][label][tool]['bytes'],
                    'measurement product metadata differs')
    # Reuse the measured driver's exact pure validators; never call its product
    # checks, native-image loader, prepare, invoke, measure or main functions.
    selected = {'require', 'check_report_identity', 'statistics_row', 'retained_wrapper', 'producer_header',
                'image_group', 'image_directory', 'arguments', 'observations', 'score',
                'boundary_scope', 'policy_key', 'validate_cache_policy', 'analyze'}
    tree = ast.parse((directory / 'cohort.py').read_text())
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in selected]
    require({node.name for node in definitions} == selected, 'measurement pure-validator interface changed')
    captured, producers = {}, {}
    namespace = dict(OUT=directory, ROOT=ROOT, Path=Path, statistics=statistics,
                     NORMAL_CACHE=OUT / 'normal-cache',
                     DATE_FILES=DATE_FILES, BOUNDARIES=['original', 'retained', 'ordinary'], SAMPLES=21, WARMUPS=10,
                     load=read, digest=digest, inputs=lambda: (plan, cases, hashes),
                     save=lambda path, value: captured.update({Path(path).name: value}))
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(directory / 'cohort.py'), 'exec'), namespace)
    groups = dict(original=cases, **{'retained-canonical': plan['execution'][:17],
                                   'retained-date': [*plan['execution'][17:], plan['startup'], *plan['execution'][4:17]]})
    for label in ['baseline', 'candidate']:
        for group, expected in groups.items():
            folder = directory / f'images-{label}-{group}'
            report = read(folder / 'producer.json')
            namespace['producer_header'](report, label, group, lock, expected,
                                         digest(directory / ('prepared-' + group) / 'manifest.json'))
            for case in report['cases']:
                if group.startswith('retained-'):
                    require(read(folder / Path(case['image']).with_suffix('.json')) == case,
                            'retained sidecar differs')
                    original, derived = folder / case['original_source_file'], folder / case['derived_source_file']
                    require(digest(original) == case['original_source_sha256'] and
                            digest(derived) == case['derived_source_sha256'] and
                            derived.read_text() == namespace['retained_wrapper'](original.read_text()),
                            'retained exact wrapper/provenance differs')
            producers[label, group] = report
    namespace['producer'] = lambda label, group, bound: producers[label, group]
    namespace['analyze']('balanced', ORDER, lock)
    analysis = read(directory / 'balanced-analysis.json')
    require(captured == {'balanced-analysis.json': analysis}, 'saved analysis differs from strict raw reassembly')
    require(lock['schema'] == 'scriptw-append-key-summary-product-lock-v1' and
            lock['baseline']['cohort'] == 'DATE-parent' and lock['candidate']['cohort'] == 'APPEND',
            'measurement cohort labels/lock schema differ')
    namespace['validate_cache_policy'](lock['cache_policy_at_bind'])
    before, after = analysis['cache_policy_before'], analysis['cache_policy_after']
    require(before == after == lock['cache_policy_at_bind'], 'normal cache substrate changed after binding')
    prefix = 'controls-normal'
    followup_plan = read(directory / (prefix + '-plan.json'))
    followup_complete = read(directory / (prefix + '-complete.json'))
    followup_analysis = read(directory / (prefix + '-analysis.json'))
    wanted = {'integer.js', 'folded-string-4096.js', 'join-singleton-1024.js', 'startup.js',
              'date-first-descriptor.js', 'numeric-loop-50000.js', 'retained-objects.js', 'join-4096.js'}
    selected_cases = [case for case in cases if case['file'] in wanted]
    selected_names = [case['file'] for case in selected_cases]
    wrapper_sha = digest(OUT / 'targeted-normal-controls.py')
    require(len(selected_cases) == 8 and followup_plan['selected_cases'] == selected_names and
            followup_complete['cases'] == selected_names and followup_analysis['selected_cases'] == selected_names and
            followup_plan['cache_policy_before'] == followup_complete['cache_policy_after'] ==
            followup_analysis['cache_policy_before'] == followup_analysis['cache_policy_after'] == before and
            followup_plan['followup_driver_sha256'] == followup_complete['followup_driver_sha256'] ==
            followup_analysis['followup_driver_sha256'] == wrapper_sha,
            'predeclared follow-up selection/wrapper/cache policy differs from the complete cohort')
    namespace['inputs'] = lambda: (plan, selected_cases, hashes)
    followup_captured = {}

    def capture_followup(path, value):
        require(Path(path).name == prefix + '-analysis.json', 'unexpected follow-up output path')
        # Preserve the frozen wrapper's annotations. Every statistic is computed
        # by the original strict analyzer over exactly these eight source inputs.
        value.update(scope='Eight predeclared unchanged sources only; normaldisk-backedoverlaycache; all3boundaries separate; nopoolingwithinitialfull21cohort, subsetonlyqualification or universalRSSclaim.',
                     cache_policy_before=before, cache_policy_after=after,
                     selected_cases=selected_names, followup_driver_sha256=wrapper_sha)
        followup_captured[Path(path).name] = value

    namespace['save'] = capture_followup
    namespace['analyze'](prefix, ORDER, lock)
    require(followup_captured == {prefix + '-analysis.json': followup_analysis},
            'follow-up analysis differs from independent selected-case raw reconstruction')
    # Source goldens may reuse the exact immutable Date Node reference. It is
    # separate from APP timing and cannot qualify the Scriptw cache substrate.
    node_directory = directory
    node_scope = 'Fresh APP source-golden verification; separate Node/V8 reference, not native performance qualification.'
    if not (directory / 'reference-node-verification.json').exists():
        node_directory = ROOT / 'target/performance-date-demand-20261031/measurement'
        node_scope = 'Inherited exact21-source Date Node goldens; every source hash/output and raw record checked. No new APP Node execution or inherited timing/native-cache qualification.'
    node = node_evidence(node_directory, cases, hashes, namespace)
    node['scope'] = node_scope
    node['verification_origin'] = origin(node_directory / 'reference-node-verification.json', archive=True)
    if node_directory == directory:
        reference = node['verification']
        namespace['validate_cache_policy'](reference['cache_policy_before'])
        require(reference['cache_policy_before'] == reference['cache_policy_after'] == before,
                'APP Node command cache binding differs')
    return dict(directory='measurement', analysis_file='measurement/balanced-analysis.json',
                analysis_sha256=digest(directory / 'balanced-analysis.json'), product_lock=lock,
                plan=read(directory / 'balanced-plan.json'), completion=read(directory / 'balanced-complete.json'),
                analysis=analysis, raw_children=504, independent_node_goldens=node,
                targeted_followup=dict(analysis_file='measurement/controls-normal-analysis.json',
                                       analysis_sha256=digest(directory / 'controls-normal-analysis.json'),
                                       plan=followup_plan, completion=followup_complete, analysis=followup_analysis,
                                       raw_children=192, followup_driver_sha256=wrapper_sha,
                                       scope='The one predeclared eight-source control/beneficiary follow-up on identical normal-cache policy and own products/images; independent reconstruction, no replacement or pooling with the complete21 cohort.'),
                raw_validation='Unchanged strict analyzer independently reconstructed504 full-cohort children and192 follow-up children separately. Exact source/producers/sidecars/argv/identities/resources/normal-overlay cache/warmup/output/timing/RSS checked without native product/image reads.',
                scope='Full21 and targeted8 normal-overlay DATE-parent versus APPEND scopes remain separate. All per-round/group/within-cohort pooled samples/means/medians and slower observations retained. Fresh original, ordinary and retained boundaries stay separate; no cross-cohort pooling, subtraction, memory benefit or parity inferred.')


def node_evidence(directory, cases, hashes, validators):
    reference = read(directory / 'reference-node-verification.json')
    require(reference['status'] == 'Independently verified' and
            reference['cases'] == [case['file'] for case in cases] and reference['source_hashes'] == hashes and
            reference['samples'] == 21 and reference['warmups_checked'] == 10,
            'independent Node reference scope differs')
    harness = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
    require(reference['harness_sha256'] == digest(harness), 'Node reference harness changed')
    raw = []
    for case in cases:
        stem = 'reference-node-' + case['file']
        report, command = read(directory / (stem + '.stdout')), read(directory / (stem + '.command.json'))
        require(command['argv'] == [reference['node'], str(harness), str(directory / 'prepared-original'),
                                    '21', '10', case['file']] and command['exit_code'] == 0 and
                command['timed_out'] is False and command['cwd'] == str(ROOT) and
                command['executable_sha256'] == reference['executable_sha256'] and
                command['resource_policy_unchanged'] is True and
                all(delta == 0 for delta in command['oom_event_delta'].values()) and
                validators['policy_key'](command['resources_before']) ==
                validators['policy_key'](command['resources_after']),
                'Node reference raw command/resources differ')
        require(report['schema'] == 'scriptw-v8-baseline-v2' and report['samples'] == 21 and
                report['warmups'] == 10 and len(report['cases']) == 1 and
                dict(node=report['node'], v8=report['v8']) == reference['versions'],
                'Node reference identity/counts differ')
        actual = report['cases'][0]
        require(actual['file'] == case['file'] and actual['source_sha256'] == hashes[case['file']] and
                len(actual['observations']) == 31 and all(
                    value['warmup'] is (index < 10) and value['stdout'] == case['stdout']
                    for index, value in enumerate(actual['observations'])), 'Node reference outputs differ')
        raw.extend(origin(directory / (stem + suffix), archive=True) for suffix in ['.stdout', '.stderr', '.command.json'])
    return dict(verification=reference, raw_origins=raw,
                scope='All21 original source goldens in the existing fresh-context Node/V8 harness; independent output/reference scope, not Scriptw native-cache admission or normal-substrate performance qualification.')


def main():
    required = ['decision.json', 'candidate/identity.json', 'candidate/products.json', 'candidate-build.json',
                'native-summary-start0.json', 'compiled-inputs.json', 'test262-candidate-summary.json',
                'measurement/product-lock.json', 'measurement/balanced-plan.json',
                'measurement/balanced-complete.json', 'measurement/balanced-analysis.json',
                'measurement/controls-normal-plan.json', 'measurement/controls-normal-complete.json',
                'measurement/controls-normal-analysis.json']
    for name in required:
        inert(OUT / name)
    decision = read('decision.json')
    require(all(isinstance(decision.get(key), str) and decision[key].strip()
                for key in ['status', 'reviewer', 'basis', 'next']) and
            isinstance(decision.get('limits'), list) and decision['limits'] and
            all(isinstance(value, str) and value.strip() for value in decision['limits']) and
            'pending' not in decision['status'].lower(), 'explicit completed Astra decision required')
    products = product_metadata()
    native = source_and_native()
    suite = test262_evidence(products)
    measurement = measurement_evidence(products)
    report = dict(schema='scriptw-append-key-summary-v1', complete=True,
                  recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  status=decision['status'], decision=decision,
                  source=dict(parent_commit=PARENT, candidate_fingerprint=products['identities']['candidate']['source_fingerprint'],
                              **products, snapshot='compiled-inputs.json', inputs=native['inputs'],
                              patch_sha256=native['patch_sha256']),
                  change=dict(runtime_abi_before=42, runtime_abi_after=43, default_runtime_policy_changed=False,
                              behavior='Sticky MAY_HAVE_INDEXED_KEYS in ordinary dictionaries; a clear current dictionary skips only its prototype level in the common packed-push proof. Digit-leading String insertion sets the bit before publication. Compacts retain the existing fallback without query promotion; every next push observes live callee/argument/prototype effects.',
                              dictionary_layout=native['dictionary_layout'],
                              allocation_accounting=dict(records_per_index_per_clear_ordinary_level=2,
                                                         kind='CodeUnitArray and StringValue decimal-key records',
                                                         qualification='Conditional source/encoded-route accounting only after existing packed/native/receiver/count/length/chain guards. Not a measured allocation census, retained-byte saving or process-memory result. No short-string collector byte estimate is asserted.')),
                  validation=dict(native=native, test262=suite),
                  measurement=measurement,
                  limits=['678 distinct checks cover the seven stated native scopes; filtered Engine scopes do not imply complete Engine/workspace coverage.',
                          'The first builtins image was deliberately retained for the second filter; exact SHA/size/path/source/selector continuity and its final retirement are recorded.',
                          'Test262 coverage is the complete24-file push family plus12 named adjoining originals; actual variants come from raw completed runs.',
                          'All21 source controls, all three actual boundaries and every slower round/group/sample remain visible; no boundary subtraction or inferred memory/parity claim.',
                          'The one predeclared eight-source follow-up uses the same normal cache/products/images; its192 children remain separate from the complete504-child cohort without pooling or replacing original controls.',
                          'Cargo build-script cache relocation to/tmp preserves logical source/build paths and is distinct from mandatory APP normal-overlay benchmark cache. Symlink/cache/native payloads are excluded from the inert archive.',
                          'Native identities are read from frozen receipts; this assembler never reads, hashes or executes native products/images. Full-suite status, published charts and release acceptance are unchanged.'])
    with (OUT / 'report-core.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(output='report-core.json', status=report['status'], native_unique=678,
                          test262_original_files=36, test262_actual_variants=suite['actual_passing_variants'],
                          workload_rows=21), indent=2))


if __name__ == '__main__':
    main()
