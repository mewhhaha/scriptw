//! Fixed push entries retain real code/Realm proofs and allocate argv only on
//! the saved-operand fallback, with canonical packed publication in R.
use super::property_read_plans::{calls, Module};
use scriptw_aot_wasm::{
    emit_with_rooted_snapshot, GcSnapshotField, GcSnapshotLayout, PromiseRejectionPolicy,
};
use scriptw_front::{parse, ParseOptions};
use scriptw_ir::lower;
use wasmparser::{
    CompositeInnerType, HeapType, Operator, StorageType, UnpackedIndex, ValType, Validator,
    WasmFeatures,
};

fn frame_end(body: &[Operator<'_>], start: usize) -> usize {
    let mut depth = 1;
    for (offset, op) in body[start + 1..].iter().enumerate() {
        match op {
            Operator::If { .. }
            | Operator::Block { .. }
            | Operator::Loop { .. }
            | Operator::TryTable { .. }
            | Operator::Try { .. } => depth += 1,
            Operator::End => {
                depth -= 1;
                if depth == 0 {
                    return start + 1 + offset;
                }
            }
            _ => {}
        }
    }
    panic!("encoded control frame is balanced");
}

fn indexed_key_summary_field(runtime: &Module<'_>, dictionary: u32) -> u32 {
    let CompositeInnerType::Struct(storage) =
        &runtime.types[dictionary as usize].composite_type.inner
    else {
        panic!("the snapshot dictionary witness names its actual struct");
    };
    let summary = storage
        .fields
        .iter()
        .enumerate()
        .filter_map(|(index, field)| {
            (field.mutable
                && field.element_type == StorageType::Val(ValType::I32)
                && index as u32 != GcSnapshotField::PropertiesLength.index())
            .then_some(index as u32)
        })
        .collect::<Vec<_>>();
    assert_eq!(
        summary.len(),
        1,
        "the dictionary has one mutable scalar summary distinct from its declaration-owned length"
    );
    summary[0]
}

fn dictionary_producers_initialize_clear_summary(
    runtime: &Module<'_>,
    dictionary: u32,
    summary: u32,
) {
    let CompositeInnerType::Struct(storage) =
        &runtime.types[dictionary as usize].composite_type.inner
    else {
        unreachable!();
    };
    for owner in [
        "helper::ordinary_object_allocate",
        "helper::native_constructor_header_allocate",
        "helper::ordinary_property_storage_ensure",
    ] {
        let (_, body) = runtime.named(owner);
        let allocations = body
            .iter()
            .enumerate()
            .filter_map(|(position, op)| {
                matches!(op,
            Operator::StructNew { struct_type_index } if *struct_type_index == dictionary)
                .then_some(position)
            })
            .collect::<Vec<_>>();
        assert_eq!(
            allocations.len(),
            1,
            "{owner} has one actual dictionary producer"
        );
        let operand = body[..allocations[0]]
            .iter()
            .rev()
            .filter(|op| !matches!(op, Operator::RefAsNonNull))
            .nth(storage.fields.len() - 1 - summary as usize)
            .unwrap();
        assert!(
            matches!(operand, Operator::I32Const { value: 0 }),
            "{owner} initializes the actual summary operand to false"
        );
    }
}

fn frames_at(body: &[Operator<'_>], position: usize) -> Vec<usize> {
    let mut frames = Vec::new();
    for (index, op) in body[..position].iter().enumerate() {
        match op {
            Operator::If { .. }
            | Operator::Block { .. }
            | Operator::Loop { .. }
            | Operator::TryTable { .. }
            | Operator::Try { .. } => frames.push(index),
            Operator::End => {
                frames
                    .pop()
                    .expect("every inner End closes an actual frame");
            }
            _ => {}
        }
    }
    frames
}

fn frame_else(body: &[Operator<'_>], start: usize) -> Option<usize> {
    (start + 1..frame_end(body, start)).find(|&position| {
        matches!(body[position], Operator::Else) && frames_at(body, position).last() == Some(&start)
    })
}

fn reference_operand(body: &[Operator<'_>], before: usize) -> u32 {
    let operand = body[..before]
        .iter()
        .rev()
        .find(|op| !matches!(op, Operator::RefAsNonNull))
        .unwrap();
    let Operator::LocalGet { local_index } = operand else {
        panic!("the actual reference operand remains rooted");
    };
    *local_index
}

fn reference_producer(body: &[Operator<'_>], before: usize, root: u32) -> usize {
    let assignment = body[..before].iter().rposition(|op| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == root))
        .expect("the inspected root has an actual producer");
    let producer = (0..assignment)
        .rev()
        .find(|&position| {
            !matches!(
                body[position],
                Operator::RefAsNonNull | Operator::RefCastNonNull { .. }
            )
        })
        .unwrap();
    if let Operator::LocalGet { local_index } = body[producer] {
        reference_producer(body, producer, local_index)
    } else {
        producer
    }
}

fn clear_dictionary_summary_skips_only_this_prototype_level(
    body: &[Operator<'_>],
    first_publication: usize,
    array: u32,
    object: u32,
    (dictionary, summary): (u32, u32),
    decimal: u32,
    descriptor: u32,
) {
    let reads = body[..first_publication]
        .iter()
        .enumerate()
        .filter_map(|(position, op)| {
            matches!(op,
        Operator::StructGet { struct_type_index, field_index }
            if *struct_type_index == dictionary && *field_index == summary)
            .then_some(position)
        })
        .collect::<Vec<_>>();
    assert_eq!(
        reads.len(),
        1,
        "each append entry rereads one live dictionary summary before publication"
    );
    let read = reads[0];
    let [Operator::StructGet { .. }, Operator::I32Eqz, Operator::LocalSet {
        local_index: acceptable,
    }] = body[read..read + 3]
    else {
        panic!("a clear actual summary authorizes only the current prototype level");
    };
    let dictionary_if = frames_at(body, read)
        .into_iter()
        .rev()
        .find(|&frame| {
            matches!(body[frame], Operator::If { .. })
                && matches!(body[frame - 1],
            Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) }
                if index == dictionary)
        })
        .expect("only a proven actual dictionary may supply the clear-bit proof");
    let dictionary_else =
        frame_else(body, dictionary_if).expect("compact storage retains an explicit fallback arm");
    let dictionary_end = frame_end(body, dictionary_if);
    assert!(dictionary_if < read && read < dictionary_else);
    assert!(
        matches!(&body[dictionary_else + 1..dictionary_end],
        [Operator::I32Const { value: 0 }, Operator::LocalSet { local_index }] if *local_index == acceptable),
        "a non-dictionary prototype cannot authorize the summary bypass"
    );
    let dictionary_root = reference_operand(body, read);
    let properties = reference_producer(body, read, dictionary_root);
    assert!(
        matches!(body[properties], Operator::StructGet { struct_type_index, field_index }
        if struct_type_index == object && field_index == GcSnapshotField::ObjectProperties.index()),
        "the tested dictionary is the actual current ordinary header's storage"
    );
    let tested_root = reference_operand(body, dictionary_if - 1);
    assert_eq!(
        reference_producer(body, dictionary_if - 1, tested_root),
        properties,
        "the type test and flag read use the same current storage record"
    );
    let header = reference_operand(body, properties);
    let bypass = (dictionary_end + 1..first_publication)
        .find(|&position| {
            matches!(&body[position - 1..=position],
        [Operator::LocalGet { local_index }, Operator::BrIf { .. }] if *local_index == acceptable)
        })
        .expect("the clear-bit result controls an actual conditional branch");
    let Operator::BrIf { relative_depth } = body[bypass] else {
        unreachable!()
    };
    let proof_writes = body[read + 3..bypass].iter().enumerate().filter_map(|(offset, op)| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == acceptable)
        .then_some(read + 3 + offset)).collect::<Vec<_>>();
    assert_eq!(
        proof_writes,
        [dictionary_else + 2],
        "only the explicit compact-storage else arm changes the clear-bit result before its branch"
    );
    let frames = frames_at(body, bypass);
    let checked = frames[frames.len() - 1 - relative_depth as usize];
    assert!(matches!(body[checked], Operator::Block { .. }));
    let checked_end = frame_end(body, checked);
    assert!(
        checked < properties
            && properties < dictionary_if
            && dictionary_end < bypass
            && bypass < checked_end
            && checked_end < first_publication,
        "clear dictionaries jump past this level's complete descriptor loop"
    );
    assert!(!body[checked + 1..=bypass].iter().any(|op| matches!(op,
        Operator::Call { .. } | Operator::ReturnCall { .. } | Operator::CallRef { .. } | Operator::ReturnCallRef { .. }
        | Operator::CallIndirect { .. } | Operator::ReturnCallIndirect { .. }
        | Operator::StructNew { .. } | Operator::StructNewDefault { .. }
        | Operator::ArrayNew { .. } | Operator::ArrayNewDefault { .. } | Operator::ArrayNewFixed { .. }
        | Operator::ArrayNewData { .. } | Operator::ArrayNewElem { .. })),
        "the clear dictionary path performs primitive reads and control only, with no calls or allocations");
    let fallback = &body[bypass + 1..checked_end];
    for target in [decimal, descriptor] {
        assert_eq!(
            fallback
                .iter()
                .filter(|op| matches!(op, Operator::Call { function_index }
            if *function_index == target))
                .count(),
            1,
            "the unchanged uncertain/compact fallback still owns the actual helper call"
        );
    }
    assert!(
        fallback
            .iter()
            .any(|op| matches!(op, Operator::Loop { .. })),
        "a set bit or compact storage still checks the full appended index range"
    );
    let ordinary = body[..checked]
        .windows(3)
        .enumerate()
        .rfind(|(_, ops)| {
            matches!(ops,
        [Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) },
         Operator::I32Eqz, Operator::BrIf { .. }] if *index == object)
        })
        .map(|(position, _)| position)
        .expect("ordinary concrete-object admission precedes any storage proof");
    let header_store = body[..properties].iter().rposition(|op| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == header)).unwrap();
    assert!(ordinary + 2 < header_store && header_store < checked);
    assert!(matches!(body[header_store - 1], Operator::RefCastNonNull {
        hty: HeapType::Concrete(UnpackedIndex::Module(index)) } if index == object));
    assert_eq!(
        reference_operand(body, header_store - 1),
        reference_operand(body, ordinary),
        "the guarded concrete prototype supplies the actual header whose storage is inspected"
    );
    let array_if = frames_at(body, ordinary)
        .into_iter()
        .rev()
        .find(|&frame| {
            matches!(body[frame], Operator::If { .. })
                && matches!(body[frame - 1],
            Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) }
                if index == array)
        })
        .expect("prototype Arrays retain their separate concrete arm");
    let array_else = frame_else(body, array_if).unwrap();
    assert!(array_else < ordinary && ordinary < checked);
    assert!(
        body[array_if + 1..array_else].iter().any(|op| matches!(op,
        Operator::StructGet { struct_type_index, field_index }
            if *struct_type_index == array && *field_index == GcSnapshotField::ArrayCount.index())),
        "Array prototype occupancy remains checked before ordinary dictionary admission"
    );
    let follow = (checked_end + 1..first_publication).find(|&position| matches!(body[position],
        Operator::StructGet { struct_type_index, field_index }
            if struct_type_index == object && field_index == GcSnapshotField::ObjectPrototype.index()))
        .expect("both branches merge into the common live prototype read");
    assert!(frame_end(body, array_if) < follow);
    assert_eq!(
        reference_operand(body, follow),
        header,
        "both paths advance from the same current ordinary header"
    );
    assert!(!body[properties + 1..follow].iter().any(|op| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == header)),
        "the proof does not switch headers before following the prototype");
    let prototype_loop = frames_at(body, checked)
        .into_iter()
        .rev()
        .find(|&frame| matches!(body[frame], Operator::Loop { .. }))
        .unwrap();
    assert!(
        body[prototype_loop + 1..array_if]
            .windows(3)
            .any(|ops| matches!(
                ops,
                [
                    Operator::I32Const { value: 8 },
                    Operator::I32GeU,
                    Operator::BrIf { .. }
                ]
            )),
        "the existing chain depth cap still precedes every prototype type/storage proof"
    );
    assert!(
        body[follow + 1..frame_end(body, prototype_loop)]
            .iter()
            .enumerate()
            .any(|(offset, op)| {
                let Operator::Br { relative_depth } = op else {
                    return false;
                };
                let frames = frames_at(body, follow + 1 + offset);
                frames[frames.len() - 1 - *relative_depth as usize] == prototype_loop
            }),
        "the common join continues the same bounded prototype walk"
    );
}

fn argv_allocation(op: &Operator<'_>, array: u32) -> bool {
    matches!(op, Operator::ArrayNew { array_type_index }
        | Operator::ArrayNewDefault { array_type_index }
        | Operator::ArrayNewFixed { array_type_index, .. }
        if *array_type_index == array)
}

fn incoming_empty_argv_allocation(
    body: &[Operator<'_>],
    signature: &wasmparser::FuncType,
    argv: u32,
) -> usize {
    let vectors = signature
        .params()
        .iter()
        .enumerate()
        .filter_map(|(index, ty)| {
            matches!(ty, ValType::Ref(reference) if reference.is_nullable()
            && reference.heap_type() == HeapType::Concrete(UnpackedIndex::Module(argv)))
            .then_some(index as u32)
        })
        .collect::<Vec<_>>();
    assert_eq!(
        vectors.len(),
        1,
        "the source entry owns one nullable incoming argument List"
    );
    let vector = vectors[0];
    let count = vector
        .checked_sub(1)
        .expect("the incoming count precedes its vector");
    assert_eq!(signature.params()[count as usize], ValType::I64);
    let allocations = body
        .windows(14)
        .enumerate()
        .filter_map(|(start, ops)| {
            matches!(ops,
            [Operator::LocalGet { local_index: parameter }, Operator::LocalSet { local_index: saved },
             Operator::LocalGet { local_index: supplied }, Operator::RefIsNull, Operator::If { .. },
             Operator::LocalGet { local_index: supplied_count }, Operator::I64Eqz, Operator::I32Eqz,
             Operator::If { .. }, Operator::Unreachable, Operator::End,
             Operator::ArrayNewFixed { array_type_index, array_size: 0 },
             Operator::LocalSet { local_index: normalized }, Operator::Else]
                if *parameter == vector && saved == supplied && supplied == normalized
                    && *supplied_count == count && *array_type_index == argv)
            .then_some(start + 11)
        })
        .collect::<Vec<_>>();
    assert_eq!(allocations.len(), 1,
        "only a null incoming vector with zero declared arguments constructs the entry's empty List");
    allocations[0]
}

#[test]
fn fixed_push_proves_actual_native_then_keeps_argument_allocations_in_fallback() {
    std::thread::Builder::new()
        .name("guarded-push-emission".into())
        .stack_size(64 * 1024 * 1024)
        .spawn(|| {
            let lowered = lower(&parse(
                "function one(v){var a=[];var result=a.push(v);return result;} \
                 function two(v){var a=[];var result=a.push(v,v);return result;} \
                 function three(v){var a=[];var result=a.push(v,v,v);return result;} \
                 function control(v){var a=[];return a;} \
                 function zero(v){var a=[];var result=a.push();return result;} \
                 function four(v){var a=[];var result=a.push(v,v,v,v);return result;} \
                 function evaluated(arg){var a=[];var result=a.push(arg(1),arg(2));return result;} \
                 [one,two,three,control,zero,four,evaluated];",
                ParseOptions::script(),
            ).unwrap());
            let artifact = emit_with_rooted_snapshot(
                &lowered,
                PromiseRejectionPolicy::Ignore,
                &scriptw_intl::IntlCompilationProfile::Minimal,
            ).unwrap();
            let runtime_bytes = artifact.runtime().unwrap().bytes();
            for bytes in [&artifact.bytes[..], runtime_bytes] {
                Validator::new_with_features(WasmFeatures::all())
                    .validate_all(bytes).unwrap();
            }
            let runtime = Module::read(runtime_bytes, true);
            let program = Module::read(&artifact.bytes, true);
            let stored = runtime.witness_type(GcSnapshotLayout::Stored);
            let array = runtime.witness_type(GcSnapshotLayout::Array);
            let storage = runtime.witness_type(GcSnapshotLayout::Array);
            let object = runtime.witness_type(GcSnapshotLayout::Object);
            let dictionary = runtime.witness_type(GcSnapshotLayout::PropertyStorage);
            let summary = indexed_key_summary_field(&runtime, dictionary);
            dictionary_producers_initialize_clear_summary(&runtime, dictionary, summary);
            let code = runtime.witness_type(GcSnapshotLayout::Code);
            let context = runtime.witness_type(GcSnapshotLayout::Context);
            let (dispatch, _) = runtime.named("helper::proxy_call");
            // Nominal GC arrays can share an element layout. Bind the actual
            // JS dispatch operand, rather than guessing its type by shape.
            let signature = runtime.function_type(dispatch);
            let ValType::Ref(arguments) = signature.params()[6] else {
                panic!("two value triples precede the actual dispatch argument List");
            };
            assert!(!arguments.is_nullable(), "dispatch requires an actual argument List");
            let HeapType::Concrete(UnpackedIndex::Module(argv)) = arguments.heap_type() else {
                panic!("dispatch arguments retain their nominal GC array type");
            };
            let CompositeInnerType::Array(slots) = &runtime.types[argv as usize].composite_type.inner else {
                panic!("the actual dispatch argument operand is a GC array");
            };
            let StorageType::Val(ValType::Ref(element)) = slots.0.element_type else {
                panic!("the actual argument List contains typed GC references");
            };
            assert!(slots.0.mutable && !element.is_nullable()
                && element.heap_type() == HeapType::Concrete(UnpackedIndex::Module(stored)),
                "the actual dispatch List owns non-null canonical StoredValue entries");
            let dispatch = program.imported_runtime_function(&runtime, dispatch);
            let (publish, _) = runtime.named("helper::array_indexed_publish_default_data");
            let (descriptor, _) = runtime.named("helper::ordinary_own_descriptor");
            let (decimal, _) = runtime.named("helper::integer_decimal_string");
            let (_, control) = program.named("js::control#");
            let source_allocations = |body: &[Operator<'_>]| body.iter().filter(|op| matches!(op,
                Operator::StructNew { struct_type_index } if *struct_type_index == stored)).count();
            let mut kernels = Vec::new();
            for (name, arity) in [("one", 1), ("two", 2), ("three", 3)] {
                let (definition, kernel) = runtime.named(&format!("helper::array_packed_push{arity}"));
                let imported = program.imported_runtime_function(&runtime, definition);
                kernels.push(imported);
                let (source, body) = program.named(&format!("js::{name}#"));
                let direct = body.iter().position(|op| matches!(op,
                    Operator::Call { function_index } if *function_index == imported))
                    .expect("the source call reaches its fixed-arity native entry");
                assert!(body[..direct].iter().filter(|op| matches!(op,
                    Operator::StructGet { struct_type_index, .. } if *struct_type_index == code)).count() >= 2,
                    "actual immutable code kind and builtin identity guard the native entry");
                assert!(body[..direct].iter().any(|op| matches!(op,
                    Operator::StructGet { struct_type_index, field_index }
                        if *struct_type_index == context && *field_index == GcSnapshotField::ContextRealm.index())),
                    "the saved actual callable supplies the execution Realm");
                assert!(body[..direct].iter().any(|op| matches!(op, Operator::RefEq)),
                    "the actual execution Realm is compared with the caller Realm");
                assert_eq!(source_allocations(&body[..direct]), source_allocations(control),
                    "successful fixed push allocates no per-argument StoredValue snapshots");
                let entry_argv = incoming_empty_argv_allocation(body, program.function_type(source), argv);
                let before_push = body[..direct].iter().enumerate()
                    .filter_map(|(index, op)| argv_allocation(op, argv).then_some(index))
                    .collect::<Vec<_>>();
                assert_eq!(before_push, [entry_argv],
                    "the source entry alone normalizes incoming null argv; successful fixed push creates no argument List");
                let fallback = body.windows(3).enumerate().find_map(|(start, ops)| {
                    let [Operator::LocalGet { .. }, Operator::I32Eqz, Operator::If { .. }] = ops else { return None; };
                    let end = frame_end(body, start + 2);
                    (start > direct && calls(&body[start + 3..end], dispatch))
                        .then_some(&body[start + 3..end])
                }).expect("a failed handled flag owns the ordinary saved-operand fallback");
                assert_eq!(source_allocations(fallback), arity,
                    "only fallback snapshots each once-evaluated argument");
                assert!(fallback.iter().any(|op| argv_allocation(op, argv)),
                    "the fallback alone materializes the ordinary argument List");
                let first_publication = kernel.iter().position(|op| matches!(op,
                    Operator::Call { function_index } if *function_index == publish)).unwrap();
                assert_eq!(kernel.iter().filter(|op| matches!(op,
                    Operator::Call { function_index } if *function_index == publish)).count(), arity,
                    "the native entry publishes each rooted operand through the canonical owner");
                assert!(kernel[..first_publication].iter().any(|op| matches!(op,
                    Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) }
                        if *index == array)), "actual concrete Array admission precedes publication");
                for (owner, field) in [(array, GcSnapshotField::ArrayLengthWritable),
                    (storage, GcSnapshotField::ArrayCount),
                    (object, GcSnapshotField::ObjectExtensible)] {
                    assert!(kernel[..first_publication].iter().any(|op| matches!(op,
                        Operator::StructGet { struct_type_index, field_index }
                            if *struct_type_index == owner && *field_index == field.index())),
                        "live {field:?} is checked before publication");
                }
                assert!(calls(&kernel[..first_publication], descriptor),
                    "prototype indexed descriptors remain part of shared admission");
                clear_dictionary_summary_skips_only_this_prototype_level(kernel, first_publication,
                    array, object, (dictionary, summary), decimal, descriptor);
                assert!(!kernel.iter().any(|op| argv_allocation(op, argv)),
                    "the native entry does not rebuild an argument vector internally");
            }
            let (_, general) = runtime.named("builtin::Array.prototype.push");
            let general_publication = general.iter().position(|op| matches!(op,
                Operator::Call { function_index } if *function_index == publish))
                .expect("general Array.push retains the canonical packed publication owner");
            clear_dictionary_summary_skips_only_this_prototype_level(general, general_publication,
                array, object, (dictionary, summary), decimal, descriptor);
            let (_, evaluated) = program.named("js::evaluated#");
            let direct = evaluated.iter().position(|op| matches!(op,
                Operator::Call { function_index } if *function_index == kernels[1])).unwrap();
            assert_eq!(evaluated[..direct].iter().filter(|op| matches!(op,
                Operator::Call { function_index } if *function_index == dispatch)).count(), 2,
                "both argument callbacks finish once before the native entry rereads current prototypes and storage");
            for name in ["js::zero#", "js::four#"] {
                let (_, body) = program.named(name);
                assert!(kernels.iter().all(|kernel| !calls(body, *kernel)),
                    "unsupported fixed arities retain the general call from the start");
                assert!(calls(body, dispatch));
            }
        }).unwrap().join().unwrap();
}
