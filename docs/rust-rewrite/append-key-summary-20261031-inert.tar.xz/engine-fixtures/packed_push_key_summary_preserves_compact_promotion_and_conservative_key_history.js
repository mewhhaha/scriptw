
function check(ok,label){if(!ok)throw label;}
function rejects(action,label){
  var caught=false;try{action();}catch(error){caught=error instanceof TypeError;}
  check(caught,label);
}
var marker={},symbol=Symbol('0'),reads=0,prototype=Object.create(Array.prototype);
function irrelevant(){reads++;throw 'a nonmatching prototype getter was invoked';}
for(var key of ['', '-0', symbol]){
  Object.defineProperty(prototype,key,{get:irrelevant,configurable:true});
}
var clear=[];
Object.setPrototypeOf(clear,prototype);
check(clear.push(marker)===1 && clear[0]===marker && reads===0,
  'empty, minus-zero String and Symbol descriptions are distinct from an index');
for(var key of ['00','1x','4294967294','4294967295']){
  Object.defineProperty(prototype,key,{get:irrelevant,configurable:true});
}
gc();
var conservative=[];
Object.setPrototypeOf(conservative,prototype);
check(conservative.push(7,8)===2 && conservative[0]===7 && conservative[1]===8 &&
  reads===0 && Object.hasOwn(prototype,'4294967294') && Object.hasOwn(prototype,'4294967295'),
  'digit-leading false positives keep exact descriptor lookup without growing huge arrays');
var own=Object.getOwnPropertyDescriptor(conservative,'0');
check(own.value===7 && own.writable && own.enumerable && own.configurable,
  'default own descriptor survives conservative prototype fallback');
var numericPrototype=Object.create(Array.prototype),numeric=[],numericThis,numericValue;
Object.defineProperty(numericPrototype,-0,{set:function(value){numericThis=this;numericValue=value;gc();},
  configurable:true});
Object.setPrototypeOf(numeric,numericPrototype);
check(numeric.push(marker)===1 && numericThis===numeric && numericValue===marker &&
  !Object.hasOwn(numeric,'0') && Object.hasOwn(numericPrototype,'0') &&
  !Object.hasOwn(numericPrototype,'-0'),'Number negative zero canonicalizes before dictionary insertion');

var compactPlain={named:marker},plainArray=[];
Object.setPrototypeOf(compactPlain,Array.prototype);
Object.setPrototypeOf(plainArray,compactPlain);gc();
check(plainArray.push(3,4,5)===3 && plainArray[0]===3 && plainArray[2]===5 &&
  Reflect.ownKeys(compactPlain).join('|')==='named' && compactPlain.named===marker,
  'a compact prototype without indices keeps its keys and receiver append semantics');
for(var promotion=0;promotion<2;promotion++){
  var compact={'0':marker,stamp:promotion},first=[],next=[];
  Object.setPrototypeOf(compact,Array.prototype);
  Object.setPrototypeOf(first,compact);
  check(first.push('own')===1 && first[0]==='own' && compact[0]===marker,
    'compact prototype with key zero keeps its inherited writable descriptor');
  if(promotion===0)compact.extra=marker;else compact[symbol]=marker;
  Object.defineProperty(compact,'0',{writable:false});gc();
  Object.setPrototypeOf(next,compact);
  rejects(function(){next.push(13);},'promotion must retain the preexisting compact index key');
  check(next.length===0 && !Object.hasOwn(next,'0') && compact.stamp===promotion &&
    (promotion===0?compact.extra===marker:compact[symbol]===marker),
    'named and Symbol promotion retain compact keys, attributes and values');
}

var history=Object.create(Array.prototype),historyArray=[],writes=0;
Object.defineProperty(history,'0',{value:'blocked',writable:false,configurable:true});
for(var i=0;i<96;i++)history['old'+i]=i;
for(var i=0;i<96;i++)delete history['old'+i];
// Refill across the exhausted ordered table so preparation must compact its holes.
for(var i=0;i<96;i++)history['new'+i]=i;
Object.setPrototypeOf(historyArray,history);gc();
rejects(function(){historyArray.push(marker);},'compaction retains the live indexed restriction');
delete history[0];gc();
check(historyArray.push(marker)===1 && historyArray[0]===marker,'deleting an index allows a new own append');
var reinserted=[];
Object.defineProperty(history,'0',{configurable:true,set:function(value){
  writes++;check(this===reinserted && value===17,'reinserted setter receiver and value');gc();
}});
Object.setPrototypeOf(reinserted,history);
check(reinserted.push(17)===1 && writes===1 && !Object.hasOwn(reinserted,'0'),
  'reinserted indexed setter survives deletion, compaction and collection');
check(historyArray.push(19)===2 && historyArray[0]===marker && historyArray[1]===19 && writes===1,
  'reinserted prototype index does not affect a different append index or an existing own value');
var keys=Reflect.ownKeys(history);
check(keys.length===97 && keys[0]==='0' && keys[1]==='new0' && keys[96]==='new95' &&
  reads===0,'compacted ordinary enumeration retains index order and exactly the live named keys');
print('array-push-key-summary-transitions:ok');262;
