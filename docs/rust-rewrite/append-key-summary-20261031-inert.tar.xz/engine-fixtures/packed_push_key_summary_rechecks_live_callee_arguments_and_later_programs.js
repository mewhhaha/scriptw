
function check(ok,label){if(!ok)throw label;}
function rejects(action,label){
  var caught=false;try{action();}catch(error){caught=error instanceof TypeError;}
  check(caught,label);
}
var marker={},nativePush=Array.prototype.push,warm=[];
check(warm.push(marker)===1 && warm[0]===marker,'successful push before Object prototype mutation');
var intercepted=[],setterThis,setterValue,trace='';
Object.defineProperty(Object.prototype,'0',{configurable:true,set:function(value){
  trace+='set;';setterThis=this;setterValue=value;gc();
}});
try{
  check(intercepted.push(marker)===1 && intercepted.length===1 &&
    !Object.hasOwn(intercepted,'0') && setterThis===intercepted && setterValue===marker &&
    trace==='set;','new Object prototype setter is observed after a successful push');
}finally{delete Object.prototype[0];}
Object.defineProperty(Object.prototype,'0',{value:'blocked',writable:false,configurable:true});
try{
  var blocked=[];
  rejects(function(){blocked.push(marker,17);},'replacement Object prototype nonwritable index throws');
  check(blocked.length===0 && !Object.hasOwn(blocked,'0') && !Object.hasOwn(blocked,'1'),
    'nonwritable prototype preserves length and prevents indexed publication');
}finally{delete Object.prototype[0];}

var getterPrototype=Object.create(Array.prototype),getterArray=[],getterTrace='',getterThis;
Object.setPrototypeOf(getterArray,getterPrototype);
check(getterArray.push('seed')===1,'clear dictionary prototype admits earlier push');
Object.defineProperty(getterPrototype,'push',{configurable:true,get:function(){
  getterTrace+='get;';
  Object.defineProperty(getterPrototype,'1',{configurable:true,set:function(value){
    getterTrace+='set;';getterThis=this;check(value===marker,'getter-installed setter value');gc();
  }});
  gc();return nativePush;
}});
check(getterArray.push((getterTrace+='arg;',marker))===2 && getterTrace==='get;arg;set;' &&
  getterThis===getterArray && !Object.hasOwn(getterArray,'1') && getterArray[0]==='seed',
  'saved native callee getter and ordered argument effects precede the live append proof');

var argumentPrototype=Object.create(Array.prototype),argumentArray=[10],argumentTrace='';
Object.setPrototypeOf(argumentArray,argumentPrototype);
check(argumentArray.push(11)===2,'argument fixture first uses a clear dictionary');
rejects(function(){
  argumentArray.push(
    (argumentTrace+='a;',Object.defineProperty(argumentPrototype,'2',
      {value:'blocked',writable:false,configurable:true}),gc(),20),
    (argumentTrace+='b;',21),(argumentTrace+='c;',22));
},'argument insertion must invalidate the current append absence proof');
check(argumentTrace==='a;b;c;' && argumentArray.length===2 && argumentArray[0]===10 &&
  argumentArray[1]===11 && !Object.hasOwn(argumentArray,'2') && !Object.hasOwn(argumentArray,'3') &&
  !Object.hasOwn(argumentArray,'4'),'all arguments precede rejection with no partial own writes');

var summaryLaterPrototype=Object.create(Array.prototype),beforeLater=[];
Object.setPrototypeOf(beforeLater,summaryLaterPrototype);
check(beforeLater.push(marker)===1,'later-program prototype begins without indexed keys');
(0,eval)("Object.defineProperty(summaryLaterPrototype,'0',{value:'later',writable:false,configurable:true});");
gc();
var later=[];
Object.setPrototypeOf(later,summaryLaterPrototype);
rejects(function(){later.push(marker);},'a prepared later program publishes a live indexed restriction');
check(later.length===0 && !Object.hasOwn(later,'0'),'later program does not reuse earlier clear proof');
var replacement=Object.create(Array.prototype);
Object.setPrototypeOf(later,replacement);gc();
check(later.push(marker)===1 && later[0]===marker,'prototype replacement uses the new current dictionary');
Object.defineProperty(summaryLaterPrototype,'1',{value:'other',writable:false,configurable:true});
Object.setPrototypeOf(later,summaryLaterPrototype);gc();
rejects(function(){later.push(19);},'switching back observes the current indexed descriptor');
check(later.length===1 && !Object.hasOwn(later,'1'),'prototype replacement keeps receiver data intact');
print('array-push-key-summary-live:ok');262;
