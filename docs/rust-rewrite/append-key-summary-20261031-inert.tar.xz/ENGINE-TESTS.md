Engine append-key-summary regressions are complete in the existing owner
crates/scriptw-engine/tests/aot_builtins/aot_array_private_buffers.rs.
The requested aot_gc_entries path does not exist; no registration was added.
Base HEAD is a9d31bddb6fa2efc81315e46d1798d78b1d314b6.

Two tests extend the existing eleven. Each uses the unchanged NativeHost
sloppy/strict helper, then the public emitted Portable strict Script boundary.
The Portable artifact's encoded source-compilation profile is checked directly;
it is instantiated through the existing embedding API. JS and Store GC remain
real collection calls. The later-program case uses one literal prepared indirect
eval source, so Portable execution needs no unprepared native source callback.

- packed_push_key_summary_rechecks_live_callee_arguments_and_later_programs:
  successful push followed by Object.prototype[0] setter and nonwritable
  insertion; clean global teardown; saved native callee getter mutation; ordered
  three-argument mutation before rejection; prepared later-program publication;
  prototype replacement, switching back, GC, precise lengths and absent own keys.
- packed_push_key_summary_preserves_compact_promotion_and_conservative_key_history:
  empty/-0/Symbol('0') keys, digit-leading00/1x and both uint32 boundary strings
  on ordinary prototypes without huge arrays; Number -0 canonicalization;
  compact prototypes with/without index0; named and Symbol promotion preserving
  existing index0 before an attribute-only nonwritable change;96 named insertions,
  deletion/refill crossing exhausted table capacity, same-index delete/reinsert,
  setter receiver identity, enumeration order and GC.

Trace storage uses strings while Object.prototype[0] is intercepted. Existing
proxy/foreign/zero-or-four-argument/readonly-length/overflow controls are unchanged.
Semantic assertions use ordinary JS APIs; they do not inspect private field
positions or infer optimization entry from passing results. Structural owners
prove the actual clear-bit route and no-promotion query behavior.

New focused filter (two tests by source inventory):

    -p scriptw-engine --test aot_builtins aot_array_private_buffers::packed_push_key_summary_

Whole owner filter (thirteen tests by source inventory):

    -p scriptw-engine --test aot_builtins aot_array_private_buffers::

Owned-file rustfmt2021/check, git diff --check and reverse patch preflight passed.
No build, native JS execution, Node or native inventory ran. Runtime semantics
remain unverified until root's frozen batch.

engine-test-base.json, engine-base/, engine-candidate/, engine-fixtures/,
engine-tests.patch and engine-test-receipt.json retain exact source identities,
reviewable JS, patch and checks. Production, other test owners and main
registration were not edited by this chunk.
