# APP inert report preparation

build-report.py reads one 15-file frozen implementation snapshot and the actual
seven-scope native summary. The completed native helper check records 678
distinct passes: 572 AOT library, 41 emission, 31 runtime-link, 13 private buffers,
3 intrinsic installation, 14 compact storage and 4 native metadata.

The builtins 13 scope retained its selected executable for builtins 3. The
assembler verifies identical SHA/size/path/source map/Cargo selector through both
receipts, then the exact final retirement. It does not invent a first retirement
or a repair/replay union. Full inventory/build/watched transcripts retain their
original origins; external inert streams are copied under raw-streams.

Candidate identity/products/build metadata are required, with accepted Date
parent a35/ABI42 versus APPEND/ABI43. The 61-input committed-parent reuse proof
preserves the Date producer's actual 7c47 source identity; it is not retagged as
an a9d31 build. The 36 original Test262 files must complete; actual variants are
counted from raw runs. Only the 24-file push family is claimed complete.

The normal-overlay 21-source/all 3-boundary/eight-round 504-child cohort must
complete before assembly. The measured driver's pure validators independently
reconstruct every sample, round, group, mean, median and original RSS endpoint;
changed source/product/argv/resource/cache/output/count/statistics fails assembly.
No native product/image is opened, hashed, loaded or executed by the assembler.

The one predeclared normal-overlay follow-up is also mandatory: integer,
folded-string4096, singleton join, startup, Date first descriptor, numeric50000,
retained objects and join4096. Its 192 children use the same products/images/cache
policy and all three boundaries/eight rounds/21 measured/10 checked warmups.
The unchanged analyzer is rerun with exactly those eight source inputs and the
frozen wrapper's metadata additions. The complete 504 and targeted 192 scopes
remain intact and separate; no pooling, replacement or extra timing is implied.
Broad raw validation is deferred until root reports that this follow-up finished.

Node goldens use fresh APP 21-source records when present. Otherwise the exact
unchanged Date source-golden records are rechecked and archived as explicitly
inherited, with no new Node execution or inherited performance qualification.
Current root reports fresh APP Node 21 complete; broad validation is deferred
until active timings finish.

The required Astra decision uses status/reviewer/basis/limits/next and is copied
verbatim. No outcome, broad non-regression, memory benefit or parity is inferred.
The passing collector test proves dictionary 32B/16B alignment/two edges. Allocation
accounting is only the conditional two decimal-key records per append index per
clear ordinary prototype level; no short-string byte estimate is asserted.

package-inert.py retains regular raw/source/metadata files and raw Wasm as data.
It prunes cache/caches/normal-cache/tmp/candidate/failed-native/__pycache__,
next drafts and symlinked directories; file mode/suffix/magic reject native
payloads. Candidate identity/products JSON remain explicit exceptions. The Cargo
build-cache relocation JSON explains the preserved logical build paths and the
separate normal benchmark cache. Existing Date archives are not changed.

Deferred root commands, after inputs and review are complete:

    python3 -B target/performance-append-key-summary-20261031/build-report.py
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-summary-20261031/package-inert.py runtime-append-key-summary-20261031

report-native-helper-check.json records the completed inert native check.
Main/packager have not run. Measurement/follow-up/Test262/Node helper checks await
the end of active root timings. No new native/Node command or native payload read/hash
was performed for this preparation.
