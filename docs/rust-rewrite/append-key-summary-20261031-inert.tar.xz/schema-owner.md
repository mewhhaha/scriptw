Append-key schema/allocator chunk

Owned six-file hashes and exact parent a9d31bddb are in schema-owner-inputs.json; schema-owner.patch contains only those tracked paths. MAY_HAVE_INDEXED_KEYS is a mutable bool at field3 after the unchanged ENTRIES/LENGTH/INDEX prefix. All three production constructors and the existing schema witness emit constant(false). There is no generic reset API, new storage mode/helper or GC edge. Root owns insertion classification, guard lifetime and ABI43.

The new dictionary_indexed_key_summary_fills_existing_copying_collector_padding test decodes the actual emitted declaration, verifies concrete nonnull array references and the appended mutable i32, then feeds those exact fields to Wasmtime47 CopyingTypeLayouts. It asserts32B size/16B alignment and offsets16/20/24/28 with exactly two collector edges. The test is implemented but not run; those bytes are not a completed native result yet.

The structural owner agreed to verify all three production false operands in its existing complete-runtime parse in guarded_push, avoiding a separate full-R emission and any production snapshot export. Six-file rustfmt2021(skip_children=true) and git diff --check passed. No native build/execution, expensive suite, stage or commit was performed.
