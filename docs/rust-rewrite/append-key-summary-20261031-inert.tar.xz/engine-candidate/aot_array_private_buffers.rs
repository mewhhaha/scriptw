use scriptw_engine::{
    CompileOptions, EmbeddedEvaluation, EmbeddedRuntime, Engine, ExecutionBackend, HostOutputEvent,
    HostSurfacePolicy, JsCompletion, ObservedCompletion, ObservedJsValue, ObservedNumber,
    RealmBuilder, RunOptions,
};

fn assert_modes(source: &str, expected: &str) {
    scriptw_engine::configure_compilation_jobs(1).expect("bounded compiler jobs");
    for directive in ["", "'use strict';\n"] {
        let source = format!("{directive}{source}");
        let observed = Engine::new(RealmBuilder::new().build())
            .observe_script(
                &source,
                CompileOptions {
                    host_surface_policy: HostSurfacePolicy::Test262,
                    ..CompileOptions::default()
                },
                RunOptions {
                    backend: ExecutionBackend::WasmAot,
                    timeout_ms: Some(30_000),
                    ..RunOptions::default()
                },
            )
            .expect("private Array buffer fixture executes through Wasm AOT");
        assert_eq!(observed.backend_used, ExecutionBackend::WasmAot);
        assert_eq!(
            observed.completion,
            ObservedCompletion::Normal(ObservedJsValue::Number(ObservedNumber::from_f64(262.0))),
            "{source}"
        );
        assert_eq!(
            observed.output_events,
            vec![HostOutputEvent::PrintLine(expected.into())],
            "{source}"
        );
    }
}

#[test]
fn sort_is_stable_without_quadratic_comparisons_and_preserves_gc_identity() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/sort_values.js"),
        "array-private-sort-values:ok",
    );
}

#[test]
fn sort_snapshots_gets_and_preserves_comparator_abrupt_and_writeback_semantics() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/sort_effects.js"),
        "array-private-sort-effects:ok",
    );
}

#[test]
fn packed_sort_revalidates_comparator_effects_and_preserves_exact_partial_writeback() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/packed_sort_effects.js"),
        "array-packed-sort-effects:ok",
    );
}

#[test]
fn unboxed_numeric_sort_keeps_stable_bits_and_complete_generic_fallbacks() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/numeric_sort.js"),
        "array-unboxed-numeric-sort:ok",
    );
}

#[test]
fn dense_number_prefix_preserves_holes_bits_and_storage_transitions() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/dense_number_prefix.js"),
        "array-dense-number-prefix:ok",
    );
}

#[test]
fn array_owner_preserves_indexed_identity_across_header_and_private_state_changes() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/fused_owner_lifecycle.js"),
        "array-fused-owner-lifecycle:ok",
    );
}

#[test]
fn packed_push_guards_live_prototypes_attributes_overflow_and_realms() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/packed_push.js"),
        "array-packed-push:ok",
    );
}

fn assert_append_key_summary_profiles(source: &str, expected: &str) {
    // Keep the existing NativeHost sloppy/strict boundary, then independently
    // emit the same strict Script through the public Portable artifact API.
    assert_modes(source, expected);
    let compiler = Engine::new(RealmBuilder::new().build());
    let unit = compiler
        .compile_script(
            &format!("'use strict';\n{source}"),
            CompileOptions {
                host_surface_policy: HostSurfacePolicy::Test262,
                ..CompileOptions::default()
            },
        )
        .expect("append-key fixture lowers as a Portable Script");
    let artifact = compiler.emit_wasm(&unit).unwrap();
    assert_eq!(
        scriptw_aot_wasm::RuntimeSourceCompilationProfile::from_module(&artifact.bytes).unwrap(),
        scriptw_aot_wasm::RuntimeSourceCompilationProfile::Portable,
    );
    let mut config = wasmtime::Config::new();
    scriptw_engine::configure_wasm_runtime(&mut config);
    let engine = wasmtime::Engine::new(&config).unwrap();
    let runtime = EmbeddedRuntime::compile(&engine, &artifact).unwrap();
    let state = runtime.new_state(RealmBuilder::new().build(), ()).unwrap();
    let mut store = wasmtime::Store::new(&engine, state);
    store.limiter(|state| state.limits_mut());
    store.set_epoch_deadline(u64::MAX / 2);
    let mut linker = wasmtime::Linker::new(&engine);
    runtime.register(&mut store, &mut linker).unwrap();
    let mut instance = runtime.instantiate(&mut store, &mut linker).unwrap();
    store.gc(None).unwrap();
    match instance.initialize(&mut store).unwrap() {
        EmbeddedEvaluation::Settled(JsCompletion::Normal(value)) => {
            assert_eq!(value.as_number(), Some(262.0), "{source}");
        }
        other => panic!("Portable append-key fixture did not complete: {other:?}\n{source}"),
    }
    store.gc(None).unwrap();
    assert_eq!(
        instance.take_output(&mut store).unwrap(),
        [HostOutputEvent::PrintLine(expected.into())],
    );
}

#[test]
fn packed_push_key_summary_rechecks_live_callee_arguments_and_later_programs() {
    assert_append_key_summary_profiles(
        r#"
function check(ok,label){if(!ok)throw label;}
function rejects(action,label){
  var caught=false;try{action();}catch(error){caught=error instanceof TypeError;}
  check(caught,label);
}
var marker={},nativePush=Array.prototype.push,warm=[];
check(warm.push(marker)===1 && warm[0]===marker,'successful push before Object prototype mutation');
var intercepted=[],setterThis,setterValue,trace='';
Object.defineProperty(Object.prototype,'0',{configurable:true,set:function(value){
  trace+='set;';setterThis=this;setterValue=value;gc();
}});
try{
  check(intercepted.push(marker)===1 && intercepted.length===1 &&
    !Object.hasOwn(intercepted,'0') && setterThis===intercepted && setterValue===marker &&
    trace==='set;','new Object prototype setter is observed after a successful push');
}finally{delete Object.prototype[0];}
Object.defineProperty(Object.prototype,'0',{value:'blocked',writable:false,configurable:true});
try{
  var blocked=[];
  rejects(function(){blocked.push(marker,17);},'replacement Object prototype nonwritable index throws');
  check(blocked.length===0 && !Object.hasOwn(blocked,'0') && !Object.hasOwn(blocked,'1'),
    'nonwritable prototype preserves length and prevents indexed publication');
}finally{delete Object.prototype[0];}

var getterPrototype=Object.create(Array.prototype),getterArray=[],getterTrace='',getterThis;
Object.setPrototypeOf(getterArray,getterPrototype);
check(getterArray.push('seed')===1,'clear dictionary prototype admits earlier push');
Object.defineProperty(getterPrototype,'push',{configurable:true,get:function(){
  getterTrace+='get;';
  Object.defineProperty(getterPrototype,'1',{configurable:true,set:function(value){
    getterTrace+='set;';getterThis=this;check(value===marker,'getter-installed setter value');gc();
  }});
  gc();return nativePush;
}});
check(getterArray.push((getterTrace+='arg;',marker))===2 && getterTrace==='get;arg;set;' &&
  getterThis===getterArray && !Object.hasOwn(getterArray,'1') && getterArray[0]==='seed',
  'saved native callee getter and ordered argument effects precede the live append proof');

var argumentPrototype=Object.create(Array.prototype),argumentArray=[10],argumentTrace='';
Object.setPrototypeOf(argumentArray,argumentPrototype);
check(argumentArray.push(11)===2,'argument fixture first uses a clear dictionary');
rejects(function(){
  argumentArray.push(
    (argumentTrace+='a;',Object.defineProperty(argumentPrototype,'2',
      {value:'blocked',writable:false,configurable:true}),gc(),20),
    (argumentTrace+='b;',21),(argumentTrace+='c;',22));
},'argument insertion must invalidate the current append absence proof');
check(argumentTrace==='a;b;c;' && argumentArray.length===2 && argumentArray[0]===10 &&
  argumentArray[1]===11 && !Object.hasOwn(argumentArray,'2') && !Object.hasOwn(argumentArray,'3') &&
  !Object.hasOwn(argumentArray,'4'),'all arguments precede rejection with no partial own writes');

var summaryLaterPrototype=Object.create(Array.prototype),beforeLater=[];
Object.setPrototypeOf(beforeLater,summaryLaterPrototype);
check(beforeLater.push(marker)===1,'later-program prototype begins without indexed keys');
(0,eval)("Object.defineProperty(summaryLaterPrototype,'0',{value:'later',writable:false,configurable:true});");
gc();
var later=[];
Object.setPrototypeOf(later,summaryLaterPrototype);
rejects(function(){later.push(marker);},'a prepared later program publishes a live indexed restriction');
check(later.length===0 && !Object.hasOwn(later,'0'),'later program does not reuse earlier clear proof');
var replacement=Object.create(Array.prototype);
Object.setPrototypeOf(later,replacement);gc();
check(later.push(marker)===1 && later[0]===marker,'prototype replacement uses the new current dictionary');
Object.defineProperty(summaryLaterPrototype,'1',{value:'other',writable:false,configurable:true});
Object.setPrototypeOf(later,summaryLaterPrototype);gc();
rejects(function(){later.push(19);},'switching back observes the current indexed descriptor');
check(later.length===1 && !Object.hasOwn(later,'1'),'prototype replacement keeps receiver data intact');
print('array-push-key-summary-live:ok');262;
"#,
        "array-push-key-summary-live:ok",
    );
}

#[test]
fn packed_push_key_summary_preserves_compact_promotion_and_conservative_key_history() {
    assert_append_key_summary_profiles(
        r#"
function check(ok,label){if(!ok)throw label;}
function rejects(action,label){
  var caught=false;try{action();}catch(error){caught=error instanceof TypeError;}
  check(caught,label);
}
var marker={},symbol=Symbol('0'),reads=0,prototype=Object.create(Array.prototype);
function irrelevant(){reads++;throw 'a nonmatching prototype getter was invoked';}
for(var key of ['', '-0', symbol]){
  Object.defineProperty(prototype,key,{get:irrelevant,configurable:true});
}
var clear=[];
Object.setPrototypeOf(clear,prototype);
check(clear.push(marker)===1 && clear[0]===marker && reads===0,
  'empty, minus-zero String and Symbol descriptions are distinct from an index');
for(var key of ['00','1x','4294967294','4294967295']){
  Object.defineProperty(prototype,key,{get:irrelevant,configurable:true});
}
gc();
var conservative=[];
Object.setPrototypeOf(conservative,prototype);
check(conservative.push(7,8)===2 && conservative[0]===7 && conservative[1]===8 &&
  reads===0 && Object.hasOwn(prototype,'4294967294') && Object.hasOwn(prototype,'4294967295'),
  'digit-leading false positives keep exact descriptor lookup without growing huge arrays');
var own=Object.getOwnPropertyDescriptor(conservative,'0');
check(own.value===7 && own.writable && own.enumerable && own.configurable,
  'default own descriptor survives conservative prototype fallback');
var numericPrototype=Object.create(Array.prototype),numeric=[],numericThis,numericValue;
Object.defineProperty(numericPrototype,-0,{set:function(value){numericThis=this;numericValue=value;gc();},
  configurable:true});
Object.setPrototypeOf(numeric,numericPrototype);
check(numeric.push(marker)===1 && numericThis===numeric && numericValue===marker &&
  !Object.hasOwn(numeric,'0') && Object.hasOwn(numericPrototype,'0') &&
  !Object.hasOwn(numericPrototype,'-0'),'Number negative zero canonicalizes before dictionary insertion');

var compactPlain={named:marker},plainArray=[];
Object.setPrototypeOf(compactPlain,Array.prototype);
Object.setPrototypeOf(plainArray,compactPlain);gc();
check(plainArray.push(3,4,5)===3 && plainArray[0]===3 && plainArray[2]===5 &&
  Reflect.ownKeys(compactPlain).join('|')==='named' && compactPlain.named===marker,
  'a compact prototype without indices keeps its keys and receiver append semantics');
for(var promotion=0;promotion<2;promotion++){
  var compact={'0':marker,stamp:promotion},first=[],next=[];
  Object.setPrototypeOf(compact,Array.prototype);
  Object.setPrototypeOf(first,compact);
  check(first.push('own')===1 && first[0]==='own' && compact[0]===marker,
    'compact prototype with key zero keeps its inherited writable descriptor');
  if(promotion===0)compact.extra=marker;else compact[symbol]=marker;
  Object.defineProperty(compact,'0',{writable:false});gc();
  Object.setPrototypeOf(next,compact);
  rejects(function(){next.push(13);},'promotion must retain the preexisting compact index key');
  check(next.length===0 && !Object.hasOwn(next,'0') && compact.stamp===promotion &&
    (promotion===0?compact.extra===marker:compact[symbol]===marker),
    'named and Symbol promotion retain compact keys, attributes and values');
}

var history=Object.create(Array.prototype),historyArray=[],writes=0;
Object.defineProperty(history,'0',{value:'blocked',writable:false,configurable:true});
for(var i=0;i<96;i++)history['old'+i]=i;
for(var i=0;i<96;i++)delete history['old'+i];
// Refill across the exhausted ordered table so preparation must compact its holes.
for(var i=0;i<96;i++)history['new'+i]=i;
Object.setPrototypeOf(historyArray,history);gc();
rejects(function(){historyArray.push(marker);},'compaction retains the live indexed restriction');
delete history[0];gc();
check(historyArray.push(marker)===1 && historyArray[0]===marker,'deleting an index allows a new own append');
var reinserted=[];
Object.defineProperty(history,'0',{configurable:true,set:function(value){
  writes++;check(this===reinserted && value===17,'reinserted setter receiver and value');gc();
}});
Object.setPrototypeOf(reinserted,history);
check(reinserted.push(17)===1 && writes===1 && !Object.hasOwn(reinserted,'0'),
  'reinserted indexed setter survives deletion, compaction and collection');
check(historyArray.push(19)===2 && historyArray[0]===marker && historyArray[1]===19 && writes===1,
  'reinserted prototype index does not affect a different append index or an existing own value');
var keys=Reflect.ownKeys(history);
check(keys.length===97 && keys[0]==='0' && keys[1]==='new0' && keys[96]==='new95' &&
  reads===0,'compacted ordinary enumeration retains index order and exactly the live named keys');
print('array-push-key-summary-transitions:ok');262;
"#,
        "array-push-key-summary-transitions:ok",
    );
}

#[test]
fn packed_join_call_preserves_actual_callable_arguments_fallbacks_and_realms() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/packed_join_call.js"),
        "array-packed-join-call:ok",
    );
}

#[test]
fn packed_join_dense_prefix_tracks_storage_transitions_and_ordered_fallback() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/packed_join_dense_prefix.js"),
        "array-packed-join-dense-prefix:ok",
    );
}

#[test]
fn string_buffer_preserves_live_join_order_reentrancy_and_utf16() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/join.js"),
        "array-private-join:ok",
    );
}

#[test]
fn locale_buffer_preserves_call_receivers_options_gc_and_typed_array_witnesses() {
    assert_modes(
        include_str!("../fixtures/array_private_buffers/locale.js"),
        "array-private-locale:ok",
    );
}
