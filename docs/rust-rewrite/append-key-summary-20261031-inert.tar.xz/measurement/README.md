# Append-key-summary measurement preparation

Source only. No bind, preparation, new native/Node execution, product/image read
or product hashing has run. This reuses the established Date cohort driver and
its exact 21 source cases: canonical 17, startup and the three deterministic Date
controls. The repeated Date control retains 513 public Date reads and its exact
golden output. Historical Date JSON was used only for schema compatibility.

Baseline is DATE-parent:
target/performance-date-demand-20261031/candidate, source fingerprint
a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480,
embedded source commit 7c47e38274c9645b6701552c87d38362b2bfbcd5, ABI 42.
APP's existing baseline-reuse-proof.json binds it to accepted parent
a9d31bddb6fa2efc81315e46d1798d78b1d314b6. Candidate APPEND must be frozen at
APP/candidate with an explicitly supplied exact future fingerprint and ABI 43.
Each side prepares fresh images using its own local frozen producer/consumer.
No native product/image is copied, linked or taken from an archive.

Normal overlay backing is mandatory. Before future commands, create
target/performance-append-key-summary-20261031/normal-cache and set:

    export SCRIPTW_CACHE_DIR=/workspace/scriptw/target/performance-append-key-summary-20261031/normal-cache

The driver requires that canonical nonsymlink path and overlayfs:794c7630.
tmpfs, ramfs and other substrates are rejected before binding/preparation or
measurement. Resolved cache root, environment value and filesystem are recorded
before/after each cohort; SCRIPTW_CACHE_DIR is included in every child resource
receipt and compared throughout analysis. A changed root/substrate invalidates
the cohort. The script does not create or relocate caches automatically.

Deferred commands, only after root freezes the candidate and finishes all other
native jobs, from repository root:

    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-summary-20261031/measurement/cohort.py bind --candidate-fingerprint EXACT_APPEND_FINGERPRINT
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-summary-20261031/measurement/cohort.py prepare baseline
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-summary-20261031/measurement/cohort.py prepare candidate
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-summary-20261031/measurement/cohort.py measure balanced --order eight

All 21 sources run at each actual boundary: original compiler-free fresh
Store/Realm, ordinary default runtime invocation, and strict-derived retained
public call. Each child checks 10 warmups and 21 measured observations. Eight
rounds combine ABBA then BAAB; separately named ABBA/BAAB groups remain available.
All raw streams/argv/resources, per-round/group/pooled means and medians, original
post-execution RSS and process peaks remain visible. Boundaries are never
subtracted. Retained Date timings are Ready state after checked warmups.

The existing retained helper's 17-entry guard is unchanged: one canonical 17
input, then a second 17-entry input containing startup/Date3 plus 13 canonical
preparation-only fillers. Only the four new entries use that second image set
during timing. Actual producer/case/sidecar/source-wrapper/runtime-key validators
remain unchanged and strict. Failed/incomplete outputs are never overwritten.

verify-node PREFIX is optional, separate from native timing and also requires the
normal cache binding. The exact 21 source goldens already have saved Date Node
verification, referenced by date-inert-compatibility.json; no new Node command
was run here. Historical Date tmpfs timings are not APP performance baselines or
normal-overlay qualification. All APP timing results remain unmeasured.

plan.json and draft-receipt.json bind the copied sources, template, metadata and
driver. audit-date-records.py feeds only existing Date JSON/source/sidecars into
isolated unchanged validators. It does not import or run measurement entrypoints,
native products, images or Node. No new harness, engine feature or tracked edit
was introduced by this preparation.
