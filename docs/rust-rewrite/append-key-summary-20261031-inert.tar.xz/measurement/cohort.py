#!/usr/bin/env python3
"""Source-only append-key-summary cohort; execution waits for the frozen semantic gate."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import sys

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
SOURCES = OUT / 'sources'
BASELINE = ROOT / 'target/performance-date-demand-20261031/candidate'
CANDIDATE = OUT.parent / 'candidate'
DATE_PARENT = 'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480'
DATE_PARENT_SOURCE_COMMIT = '7c47e38274c9645b6701552c87d38362b2bfbcd5'
NORMAL_CACHE = OUT.parent / 'normal-cache'
CANONICAL = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
DATE_FILES = ['date-first-descriptor.js', 'date-first-epoch.js', 'date-repeated-256.js']
BOUNDARIES = ['original', 'retained', 'ordinary']
PRODUCERS = {}
TIME = Path('/workspace/toolchains/system/usr/bin/time')
NODE_HARNESS = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
SAMPLES, WARMUPS = 21, 10
ORDERS = {
    'ABBA': ['baseline', 'candidate', 'candidate', 'baseline'],
    'BAAB': ['candidate', 'baseline', 'baseline', 'candidate'],
    'eight': ['baseline', 'candidate', 'candidate', 'baseline',
              'candidate', 'baseline', 'baseline', 'candidate'],
}
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import measure_process
from limited_verification import kernel_group, require_cloud_budget


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    # Failed/incomplete receipts are never overwritten by a retry.
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def plain_file(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve() == path,
            f'canonical nonsymlink path required: {path}')
    stat = path.stat()
    require(path.is_file() and stat.st_nlink == 1,
            f'plain independently owned file required: {path}')
    return stat


def cache_root():
    configured = os.environ.get('SCRIPTW_CACHE_DIR')
    require(configured is not None and Path(configured).is_absolute(),
            'set SCRIPTW_CACHE_DIR to the APP normal-cache absolute path')
    expected = NORMAL_CACHE
    resolved = Path(configured).resolve()
    require(resolved == expected and expected.resolve() == expected and expected.is_dir(),
            'APP normal-cache must exist at its canonical nonsymlink path')
    return dict(path=str(expected), environment_cache_root=configured,
                resolved_scriptw_cache_dir=str(resolved))


def validate_cache_policy(policy):
    require(policy['path'] == policy['resolved_scriptw_cache_dir'] == str(NORMAL_CACHE) and
            Path(policy['environment_cache_root']).is_absolute() and
            str(Path(policy['environment_cache_root'])) == str(NORMAL_CACHE) and
            policy['filesystem'] == 'overlayfs:794c7630',
            'normal overlay APP cache required; tmpfs/ramfs or another substrate cannot qualify')


def cache_policy():
    policy = cache_root()
    policy['filesystem'] = subprocess.check_output(
        ['stat', '-f', '--format=%T:%t', policy['path']], text=True).strip()
    validate_cache_policy(policy)
    return policy


def products(directory, expected_fingerprint):
    identity_path, products_path = directory / 'identity.json', directory / 'products.json'
    plain_file(identity_path); plain_file(products_path)
    identity, metadata = load(identity_path), load(products_path)
    require(identity['schema'] == 'scriptw-precompiled-shared-host-v1', 'wrong identity schema')
    require(identity['source_fingerprint'] == expected_fingerprint, 'wrong frozen product source')
    rows = {}
    for tool in ['compiler_precompiled_baseline', 'runtime_baseline']:
        path = directory / tool
        stat = plain_file(path)
        require(stat.st_size == metadata[tool]['bytes'], f'product size changed: {path}')
        require(digest(path) == metadata[tool]['sha256'], f'product bytes changed: {path}')
        rows[tool] = dict(path=str(path), sha256=metadata[tool]['sha256'], bytes=stat.st_size)
    require(identity['executable_sha256'] == rows['compiler_precompiled_baseline']['sha256'],
            'host identity/product mismatch')
    return dict(directory=str(directory), identity=identity, products=rows,
                identity_metadata_sha256=digest(identity_path),
                products_metadata_sha256=digest(products_path))


def resources():
    cache_root()
    budget = require_cloud_budget()
    affinity = sorted(os.sched_getaffinity(0))
    require(len(affinity) == 1, 'serial measurement affinity required; use limited_verification --cloud')
    group = kernel_group()
    fields = ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max',
              'memory.current', 'memory.peak', 'memory.events', 'pids.current']
    observers = {key: value for key, value in os.environ.items()
                 if key.startswith('SCRIPTW_PRECOMPILED_PHASE_') or
                 key == 'SCRIPTW_PRECOMPILED_EXECUTION_WINDOWS'}
    require(not observers, 'phase/window observers would change these native cohorts')
    return dict(cloud_budget_bytes=budget, affinity=affinity,
                cgroup={name: (group / name).read_text().strip() for name in fields},
                environment={name: os.environ.get(name) for name in [
                    'CARGO_BUILD_JOBS', 'SCRIPTW_JOBS', 'RAYON_NUM_THREADS', 'RUST_TEST_THREADS',
                    'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES',
                    'SCRIPTW_CACHE_DIR']})


def invoke(stem, argv, executable_sha256, node=False):
    require(Path(stem).name == stem, 'invalid raw command label')
    print(stem, flush=True)
    env = dict(os.environ)
    if node:
        require(not env.get('NODE_OPTIONS'), 'NODE_OPTIONS would change the reference cohort')
        env.pop('NODE_COMPILE_CACHE', None)
        env['NODE_DISABLE_COMPILE_CACHE'] = '1'
    before = resources()
    with (OUT / (stem + '.stdout')).open('xb') as stdout, (OUT / (stem + '.stderr')).open('xb') as stderr:
        result = measure_process(list(map(str, argv)), cwd=ROOT, env=env,
                                 stdout=stdout, stderr=stderr, timeout=900, time_binary=TIME)
    after = resources()
    before_events = dict(line.split() for line in before['cgroup']['memory.events'].splitlines())
    after_events = dict(line.split() for line in after['cgroup']['memory.events'].splitlines())
    oom_delta = {key: int(after_events.get(key, '0')) - int(before_events.get(key, '0'))
                 for key in ['oom', 'oom_kill', 'oom_group_kill']}
    policy_stable = (before['cloud_budget_bytes'] == after['cloud_budget_bytes'] and
            before['affinity'] == after['affinity'] and before['environment'] == after['environment'] and
            all(before['cgroup'][key] == after['cgroup'][key] for key in
                ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max']))
    result.update(argv=list(map(str, argv)), executable_sha256=executable_sha256,
                  cwd=str(ROOT), resources_before=before, resources_after=after,
                  resource_policy_unchanged=policy_stable, oom_event_delta=oom_delta)
    save(OUT / (stem + '.command.json'), result)
    require(policy_stable, 'resource policy changed during measured child; raw receipt retained')
    require(all(value == 0 for value in oom_delta.values()), 'OOM event during measured child; raw receipt retained')
    require(result['exit_code'] == 0 and not result['timed_out'], f'command failed; retained receipt: {stem}')
    return load(OUT / (stem + '.stdout'))


def check_report_identity(report, label, lock, tool, schema):
    require(report['schema'] == schema, f'wrong {tool} report schema')
    require(report['source_fingerprint'] == lock[label]['identity']['source_fingerprint'], 'source label mismatch')
    require(report['source_commit'] == lock[label]['identity']['source_commit'], 'source commit mismatch')
    require(report['executable_sha256'] == lock[label]['products'][tool]['sha256'], 'executable label mismatch')


def statistics_row(values):
    require(len(values) >= 3 and all(type(value) is int and value >= 0 for value in values), 'invalid samples')
    return dict(samples=values, count=len(values), median=statistics.median(values),
                mean=statistics.mean(values), minimum=min(values), maximum=max(values))


def inputs():
    expected = load(OUT / 'source-hashes.json')
    require(set(expected) == {path.name for path in SOURCES.iterdir()}, 'source inventory changed')
    for name, sha in expected.items():
        plain_file(SOURCES / name)
        require(digest(SOURCES / name) == sha, f'source changed: {name}')
    plan, canonical = load(SOURCES / 'manifest.json'), load(CANONICAL / 'manifest.json')
    require(plan['schema'] == canonical['schema'] == 'scriptw-v8-workloads-v1' and
            len(canonical['execution']) == 17 and len(plan['execution']) == 20,
            'unexpected Date/canonical inventory')
    require(plan['startup'] == canonical['startup'] and
            plan['execution'][:17] == canonical['execution'] and
            [case['file'] for case in plan['execution'][17:]] == DATE_FILES,
            'canonical17, startup or Date control labels changed')
    for case in [*canonical['execution'], canonical['startup']]:
        require(digest(SOURCES / case['file']) == digest(CANONICAL / case['file']),
                f'canonical source changed: {case["file"]}')
    cases = [*plan['execution'], plan['startup']]
    require(len({case['file'] for case in cases}) == 21, 'duplicate case')
    for case in cases:
        require(Path(case['file']).name == case['file'], 'case must be a basename')
    golden = load(OUT / 'golden-derivation.json')
    require(golden['controls'] == plan['execution'][17:] and
            golden['canonical_manifest_sha256'] == digest(CANONICAL / 'manifest.json'),
            'golden derivation or original manifest changed')
    return plan, cases, expected


def support_identities():
    return {str(path.relative_to(ROOT)): digest(path) for path in [
        Path(__file__).resolve(), OUT / 'golden-derivation.json',
        ROOT / 'scripts/benchmark_metrics.py', ROOT / 'scripts/limited_verification.py',
        NODE_HARNESS, CANONICAL / 'manifest.json',
        ROOT / 'crates/scriptw-cli/examples/runtime_precompiled/callable.rs',
    ]}


def bind(candidate_fingerprint):
    cache = cache_policy()
    _, _, hashes = inputs()
    require(len(candidate_fingerprint) == 64 and
            all(char in '0123456789abcdef' for char in candidate_fingerprint) and
            candidate_fingerprint != DATE_PARENT, 'explicit future APPEND fingerprint required')
    baseline = products(BASELINE, DATE_PARENT)
    candidate = products(CANDIDATE, candidate_fingerprint)
    require(baseline['identity'] == load(OUT.parent / 'baseline-identity.json'),
            'frozen DATE-parent identity differs from APP baseline receipt')
    require(baseline['identity']['source_commit'] == DATE_PARENT_SOURCE_COMMIT,
            'DATE-parent frozen source commit differs')
    require(baseline['identity']['shared_configuration'] == candidate['identity']['shared_configuration'],
            'shared runtime configuration differs')
    baseline.update(cohort='DATE-parent', expected_runtime_abi=42)
    candidate.update(cohort='APPEND', expected_runtime_abi=43)
    save(OUT / 'product-lock.json', dict(schema='scriptw-append-key-summary-product-lock-v1',
         source_hashes=hashes, support=support_identities(), baseline=baseline, candidate=candidate,
         cache_policy_at_bind=cache,
         runtime_abi_authority='Expected42/43 recorded from reviewed source contracts; each own fresh producer/runtime key and matching consumer performs actual runtime admission. No cross-version image reuse.',
         authority='Frozen local products only; newly prepared local native images from these exact sources.'))


def checked_lock():
    _, _, hashes = inputs()
    lock = load(OUT / 'product-lock.json')
    require(lock['schema'] == 'scriptw-append-key-summary-product-lock-v1' and
            lock['source_hashes'] == hashes and lock['support'] == support_identities(),
            'bound sources or harness changed')
    validate_cache_policy(lock['cache_policy_at_bind'])
    for label, cohort, abi in [('baseline', 'DATE-parent', 42), ('candidate', 'APPEND', 43)]:
        row = lock[label]
        actual = products(Path(row['directory']), row['identity']['source_fingerprint'])
        require(actual == {key: value for key, value in row.items()
                           if key not in ['cohort', 'expected_runtime_abi']} and
                row['cohort'] == cohort and row['expected_runtime_abi'] == abi,
                f'frozen product or cohort label changed: {label}')
    require(lock['baseline']['identity']['source_fingerprint'] == DATE_PARENT and
            lock['baseline']['directory'] == str(BASELINE) and
            lock['candidate']['directory'] == str(CANDIDATE), 'wrong product locations')
    return lock


def source_groups():
    plan, cases, hashes = inputs()
    # The reusable retained helper admits exactly17 sources, not arbitrary counts.
    # Keep its canonical17 input intact; only the four new cases are measured from
    # the second input. Its13 canonical fillers are preparation-only duplicates.
    groups = {
        'original': cases,
        'retained-canonical': plan['execution'][:17],
        'retained-date': [*plan['execution'][17:], plan['startup'], *plan['execution'][4:17]],
    }
    for name, selected in groups.items():
        directory = OUT / ('prepared-' + name)
        prepared = dict(schema=plan['schema'], startup=plan['startup'], execution=selected)
        if not directory.exists():
            directory.mkdir()
            for case in selected:
                shutil.copyfile(SOURCES / case['file'], directory / case['file'])
            save(directory / 'manifest.json', prepared)
        require(load(directory / 'manifest.json') == prepared, 'prepared manifest changed')
        require(set(path.name for path in directory.iterdir()) ==
                {'manifest.json', *(case['file'] for case in selected)}, 'prepared inventory changed')
        for case in selected:
            plain_file(directory / case['file'])
            require(digest(directory / case['file']) == hashes[case['file']], 'prepared source changed')
    return groups


def image_group(boundary, case):
    if boundary == 'original':
        return 'original'
    return 'retained-date' if case['file'] in [*DATE_FILES, 'startup.js'] else 'retained-canonical'


def image_directory(label, group):
    return OUT / ('images-' + label + '-' + group)


def retained_wrapper(source):
    return 'export function run() {\n' + source + '\n}\n'


def producer_header(report, label, group, lock, expected_cases, manifest_sha256):
    retained = group.startswith('retained-')
    schema = 'scriptw-retained-call-producer-v1' if retained else 'scriptw-precompiled-producer-v1'
    check_report_identity(report, label, lock, 'compiler_precompiled_baseline', schema)
    require(report['compiler_enabled'] is True, 'compiler producer required')
    expected_configuration = lock[label]['identity']['shared_configuration']
    # Retained consumers use the per-image receipt copied into each case and its
    # sidecar. Validate that authority directly; aggregate decoration is optional.
    if retained:
        if 'shared_configuration' in report:
            require(report['shared_configuration'] == expected_configuration, 'retained aggregate policy mismatch')
    else:
        require(report['adapter'] == 'scriptw' and
                report['shared_configuration'] == expected_configuration, 'original producer policy mismatch')
    require(report['manifest_sha256'] == manifest_sha256, 'producer manifest mismatch')
    require([case['file'] for case in report['cases']] ==
            [case['file'] for case in expected_cases], 'producer inventory mismatch')
    for expected, case in zip(expected_cases, report['cases']):
        name = case['file']
        require(case['stdout'] == expected['stdout'] and
                case['original_source_sha256' if retained else 'source_sha256'] == lock['source_hashes'][name],
                'producer source/output mismatch')
        suffix = '.retained.swpc' if retained else '.swpc'
        require(case['image'] == name + suffix and case['runtime_key'] is not None,
                'unexpected image path or absent runtime identity')
        require(type(case['image_bytes']) is int and case['image_bytes'] > 0,
                'invalid native image length')
        for field in ['image_sha256', 'program_wasm_sha256', 'runtime_key']:
            value = case[field]
            require(isinstance(value, str) and len(value) == 64 and
                    all(char in '0123456789abcdef' for char in value),
                    'invalid producer digest: ' + field)
        if retained:
            check_report_identity(case, label, lock, 'compiler_precompiled_baseline', schema)
            require(case['compiler_enabled'] is True and
                    case['shared_configuration'] == expected_configuration and
                    case['compiler_identity_scheme'] == lock[label]['identity']['compiler_identity_scheme'] and
                    case['excluded_from_scored_cohorts'] is True and
                    case['excluded_from_ordinary_cohorts'] is True and
                    case['manifest_sha256'] == manifest_sha256 and
                    case['original_source_file'] == name + '.original.js' and
                    case['derived_source_file'] == name + '.retained.mjs',
                    'retained per-image identity/policy/provenance mismatch')
        else:
            require(case['source_compilation_profile'] == 'portable' and case['intl_profile'] == 'Minimal' and
                    case['wasm'] == name + '.wasm', 'original producer profile/Wasm path mismatch')
    return report


def producer(label, group, lock):
    key = label, group
    if key in PRODUCERS:
        return PRODUCERS[key]
    retained = group.startswith('retained-')
    directory = image_directory(label, group)
    report = load(directory / 'producer.json')
    expected_cases = source_groups()[group]
    producer_header(report, label, group, lock, expected_cases,
                    digest(OUT / ('prepared-' + group) / 'manifest.json'))
    for expected, case in zip(expected_cases, report['cases']):
        name = case['file']
        require(case['stdout'] == expected['stdout'] and
                case['original_source_sha256' if retained else 'source_sha256'] == lock['source_hashes'][name],
                'producer source/output mismatch')
        suffix = '.retained.swpc' if retained else '.swpc'
        require(case['image'] == name + suffix, 'unexpected image path')
        image = directory / case['image']
        plain_file(image)
        require(image.stat().st_size == case['image_bytes'] and
                digest(image) == case['image_sha256'], 'fresh native image changed')
        wasm_name = name + '.retained.wasm' if retained else case['wasm']
        require(wasm_name == name + ('.retained.wasm' if retained else '.wasm'), 'unexpected Wasm path')
        plain_file(directory / wasm_name)
        require(digest(directory / wasm_name) == case['program_wasm_sha256'], 'raw Wasm changed')
        require(case['runtime_key'] is not None, 'matching runtime identity required')
        if retained:
            original, derived = directory / case['original_source_file'], directory / case['derived_source_file']
            require(original.name == name + '.original.js' and derived.name == name + '.retained.mjs',
                    'retained provenance filename changed')
            plain_file(original); plain_file(derived)
            source = (SOURCES / name).read_text()
            require(digest(original) == lock['source_hashes'][name] and
                    derived.read_text() == retained_wrapper(source) and
                    digest(derived) == case['derived_source_sha256'], 'retained wrapper changed')
            sidecar = image.with_suffix('.json')
            plain_file(sidecar)
            require(load(sidecar) == case, 'retained consumer sidecar differs from producer case')
        else:
            require(report['adapter'] == 'scriptw' and case['source_compilation_profile'] == 'portable' and
                    case['intl_profile'] == 'Minimal', 'original producer feature profile mismatch')
    PRODUCERS[key] = report
    return report


def prepare(label):
    before = cache_policy()
    lock = checked_lock()
    groups = source_groups()
    tool = lock[label]['products']['compiler_precompiled_baseline']
    for group in groups:
        command = 'prepare-retained' if group.startswith('retained-') else 'prepare-scriptw'
        invoke(label + '-prepare-' + group, [tool['path'], command, OUT / ('prepared-' + group),
               image_directory(label, group)], tool['sha256'])
        producer(label, group, lock)
    after = cache_policy()
    require(after == before, 'preparation cache filesystem/root changed')
    save(OUT / (label + '-prepare-cache-policy.json'), dict(before=before, after=after))


def arguments(prefix, index, label, boundary, case, lock):
    tool = lock[label]['products']['runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline']
    if boundary == 'ordinary':
        return [tool['path'], str(OUT / 'prepared-original'), str(SAMPLES), str(WARMUPS),
                case['file'], str(OUT / f'{prefix}-r{index}-{label}-ordinary-artifacts')]
    group = image_group(boundary, case)
    suffix = '.retained.swpc' if boundary == 'retained' else '.swpc'
    return [tool['path'], 'execute-retained' if boundary == 'retained' else 'execute-scriptw',
            str(image_directory(label, group) / (case['file'] + suffix)),
            case['stdout'], str(SAMPLES), str(WARMUPS)]


def observations(report, boundary, case, label, lock):
    tool = 'runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline'
    schemas = dict(original='scriptw-precompiled-execution-v1',
                   retained='scriptw-retained-call-execution-v1', ordinary='scriptw-wasmtime-baseline-v2')
    check_report_identity(report, label, lock, tool, schemas[boundary])
    require(report['samples'] == SAMPLES and report['warmups'] == WARMUPS, 'sample policy mismatch')
    if boundary == 'ordinary':
        require(report['requested_native_policy'] is None and len(report['cases']) == 1,
                'ordinary policy/inventory changed')
        actual = report['cases'][0]
        require(actual['file'] == case['file'] and
                actual['source_sha256'] == lock['source_hashes'][case['file']], 'ordinary source mismatch')
        values = actual['observations']
    else:
        require(report['compiler_enabled'] is False and
                report['shared_configuration'] == lock[label]['identity']['shared_configuration'],
                'compiler-free consumer policy mismatch')
        prepared = producer(label, image_group(boundary, case), lock)
        image = next(row for row in prepared['cases'] if row['file'] == case['file'])
        if boundary == 'retained':
            require(report['producer'] == image and report['initialization_count'] == 1,
                    'retained source/image or Store lifetime mismatch')
        else:
            require(report['adapter'] == 'scriptw' and
                    report['image_sha256'] == image['image_sha256'] and
                    report['program_wasm_sha256'] == image['program_wasm_sha256'] and
                    report['runtime_key'] == image['runtime_key'], 'original source/image mismatch')
        values = report['observations']
    require(len(values) == SAMPLES + WARMUPS, 'incomplete observations')
    for index, value in enumerate(values):
        require(value['warmup'] is (index < WARMUPS) and value['stdout'] == case['stdout'] and
                value.get('stderr', '') == '' and value.get('matched', True) is True and
                value.get('completion', 'normal') == 'normal', 'unchecked/failing observation')
    return values[WARMUPS:]


def score(sample, boundary):
    return sample['call_ns'] if boundary == 'retained' else (
        sample['execution_ns'] if boundary == 'ordinary' else sample['phases_ns']['execution'])


def boundary_scope(boundary, case):
    if boundary == 'retained':
        return 'Derived strict-module public call; retained Store/Realm/export; measured Date calls are Ready after10 checked warmups, including first-use-labelled source.'
    if case['file'] in DATE_FILES:
        return 'Fresh Store/Realm each observation; metadata/epoch source includes actual first Date value demand; repeated256 includes one demand plus its repeated UTC work.'
    return 'Fresh Store/Realm each observation; unchanged non-Date startup/original source.'


def policy_key(snapshot):
    return dict(cloud_budget_bytes=snapshot['cloud_budget_bytes'], affinity=snapshot['affinity'],
                environment=snapshot['environment'],
                cgroup={key: snapshot['cgroup'][key] for key in
                        ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max']})


def analyze(prefix, order, lock=None):
    lock = checked_lock() if lock is None else lock
    _, cases, _ = inputs()
    plan, completed = load(OUT / (prefix + '-plan.json')), load(OUT / (prefix + '-complete.json'))
    require(plan['order'] == completed['order'] == order and
            completed['cases'] == [case['file'] for case in cases] and
            completed['boundaries'] == BOUNDARIES and
            plan['product_lock_sha256'] == digest(OUT / 'product-lock.json') and
            plan['source_hashes'] == lock['source_hashes'], 'incomplete or relabeled cohort')
    require(policy_key(plan['resources_before']) == policy_key(completed['resources_after']),
            'cohort resource policy changed')
    cache = plan['cache_policy_before']
    validate_cache_policy(cache)
    require(cache == completed['cache_policy_after'] and
            plan['resources_before']['environment']['SCRIPTW_CACHE_DIR'] ==
            completed['resources_after']['environment']['SCRIPTW_CACHE_DIR'] ==
            cache['environment_cache_root'], 'cohort cache substrate/environment changed')
    rows = []
    for case in cases:
        name = case['file']
        row = dict(file=name, role='date-control' if name in DATE_FILES else
                   'startup' if name == 'startup.js' else 'canonical17',
                   stdout=case['stdout'], source_sha256=lock['source_hashes'][name])
        for boundary in BOUNDARIES:
            sides = {}
            for label in ['baseline', 'candidate']:
                times, rss, rounds = [], [], []
                for index, side in enumerate(order):
                    if side != label:
                        continue
                    stem = f'{prefix}-r{index}-{label}-{boundary}-{name}'
                    command = load(OUT / (stem + '.command.json'))
                    tool = lock[label]['products']['runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline']
                    require(command['argv'] == arguments(prefix, index, label, boundary, case, lock) and
                            command['cwd'] == str(ROOT) and command['executable_sha256'] == tool['sha256'] and
                            command['exit_code'] == 0 and not command['timed_out'] and
                            command['resource_policy_unchanged'] is True and
                            all(delta == 0 for delta in command['oom_event_delta'].values()) and
                            policy_key(command['resources_before']) == policy_key(plan['resources_before']) and
                            policy_key(command['resources_after']) == policy_key(plan['resources_before']),
                            'raw process/product/resources mismatch')
                    samples = observations(load(OUT / (stem + '.stdout')), boundary, case, label, lock)
                    values = [score(sample, boundary) for sample in samples]
                    times.extend(values)
                    round_row = dict(index=index, group=index // 4, timing_ns=statistics_row(values),
                                     raw_stdout=stem + '.stdout', raw_process=stem + '.command.json',
                                     process_peak_rss_bytes=command['peak_rss_bytes'])
                    if boundary == 'original':
                        memory = [sample['process_snapshots']['after_execution']['rss_bytes'] for sample in samples]
                        rss.extend(memory)
                        round_row['post_execution_rss_bytes'] = statistics_row(memory)
                    rounds.append(round_row)
                sides[label] = dict(cohort=lock[label]['cohort'], timing_ns=statistics_row(times), rounds=rounds)
                if rss:
                    sides[label]['post_execution_rss_bytes'] = statistics_row(rss)
            summary = dict(scope=boundary_scope(boundary, case), products=sides, groups=[])
            for metric in ['median', 'mean']:
                summary[metric + '_change_percent'] = 100 * (
                    sides['candidate']['timing_ns'][metric] / sides['baseline']['timing_ns'][metric] - 1)
            if boundary == 'original':
                summary['post_execution_rss_change_percent'] = {
                    metric: 100 * (sides['candidate']['post_execution_rss_bytes'][metric] /
                                   sides['baseline']['post_execution_rss_bytes'][metric] - 1)
                    for metric in ['median', 'mean']}
            for group in range((len(order) + 3) // 4):
                group_row = dict(index=group)
                for label in ['baseline', 'candidate']:
                    group_row[label] = statistics_row([value for r in sides[label]['rounds']
                        if r['group'] == group for value in r['timing_ns']['samples']])
                for metric in ['median', 'mean']:
                    group_row[metric + '_change_percent'] = 100 * (
                        group_row['candidate'][metric] / group_row['baseline'][metric] - 1)
                if boundary == 'original':
                    group_row['post_execution_rss_bytes'] = {
                        label: statistics_row([value for r in sides[label]['rounds']
                            if r['group'] == group for value in r['post_execution_rss_bytes']['samples']])
                        for label in ['baseline', 'candidate']}
                summary['groups'].append(group_row)
            row[boundary] = summary
        rows.append(row)
    save(OUT / (prefix + '-analysis.json'), dict(schema='scriptw-append-key-summary-analysis-v1',
         order=order, samples=SAMPLES, warmups_checked=WARMUPS, workloads=rows,
         cache_policy_before=cache, cache_policy_after=completed['cache_policy_after'],
         scope='Local same-machine DATE-parent/APPEND diagnostic on mandatory normal overlay cache; unchanged canonical17 plus startup and existing Date controls; all3 boundaries separate; no boundary subtraction, memory-benefit or published chart claim.'))


def measure(prefix, order):
    require(Path(prefix).name == prefix and prefix, 'invalid cohort prefix')
    before = cache_policy()
    lock = checked_lock()
    groups = source_groups()
    for label in ['baseline', 'candidate']:
        for group in groups:
            producer(label, group, lock)
    save(OUT / (prefix + '-plan.json'), dict(order=order, samples=SAMPLES, warmups_checked=WARMUPS,
         boundaries=BOUNDARIES, product_lock_sha256=digest(OUT / 'product-lock.json'),
         source_hashes=lock['source_hashes'], resources_before=resources(), cache_policy_before=before,
         node_reference='Optional separate verification; never inferred from goldens or native completion.'))
    _, cases, _ = inputs()
    for index, label in enumerate(order):
        (OUT / f'{prefix}-r{index}-{label}-ordinary-artifacts').mkdir()
        selected = cases if index % 2 == 0 else list(reversed(cases))
        for case in selected:
            for boundary in BOUNDARIES:
                tool = lock[label]['products']['runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline']
                report = invoke(f'{prefix}-r{index}-{label}-{boundary}-{case["file"]}',
                                arguments(prefix, index, label, boundary, case, lock), tool['sha256'])
                observations(report, boundary, case, label, lock)
    after = cache_policy()
    require(after == before, 'measured cache filesystem/root changed')
    save(OUT / (prefix + '-complete.json'), dict(status='All selected native observations matched',
         order=order, cases=[case['file'] for case in cases], boundaries=BOUNDARIES,
         resources_after=resources(), cache_policy_after=after,
         independent_node_verification='See separate receipt; not inferred.'))
    analyze(prefix, order, lock)


def node_reference(prefix):
    before = cache_policy()
    source_groups()
    node = shutil.which('node')
    require(node is not None, 'optional Node reference unavailable')
    node = str(Path(node).resolve())
    sha = digest(node)
    _, cases, hashes = inputs()
    versions = None
    for case in cases:
        report = invoke(prefix + '-node-' + case['file'],
                        [node, NODE_HARNESS, OUT / 'prepared-original', str(SAMPLES),
                         str(WARMUPS), case['file']], sha, node=True)
        require(report['schema'] == 'scriptw-v8-baseline-v2' and report['samples'] == SAMPLES and
                report['warmups'] == WARMUPS and len(report['cases']) == 1, 'Node policy mismatch')
        reported_versions = dict(node=report['node'], v8=report['v8'])
        require(versions is None or versions == reported_versions, 'Node reference version changed')
        versions = reported_versions
        actual = report['cases'][0]
        require(actual['file'] == case['file'] and actual['source_sha256'] == hashes[case['file']],
                'Node source mismatch')
        require(len(actual['observations']) == SAMPLES + WARMUPS and all(
            value['warmup'] is (index < WARMUPS) and value['stdout'] == case['stdout']
            for index, value in enumerate(actual['observations'])), 'Node output mismatch')
    after = cache_policy()
    require(after == before, 'Node reference cache filesystem/root changed')
    save(OUT / (prefix + '-node-verification.json'), dict(status='Independently verified',
         node=node, versions=versions, executable_sha256=sha, harness_sha256=digest(NODE_HARNESS),
         cases=[case['file'] for case in cases], source_hashes=hashes,
         samples=SAMPLES, warmups_checked=WARMUPS, cache_policy_before=before, cache_policy_after=after))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    binding = commands.add_parser('bind')
    binding.add_argument('--candidate-fingerprint', required=True)
    preparing = commands.add_parser('prepare')
    preparing.add_argument('label', choices=['baseline', 'candidate'])
    for name in ['measure', 'analyze']:
        command = commands.add_parser(name)
        command.add_argument('prefix')
        command.add_argument('--order', choices=list(ORDERS), default='eight')
    reference = commands.add_parser('verify-node')
    reference.add_argument('prefix')
    args = parser.parse_args()
    if args.command == 'bind':
        bind(args.candidate_fingerprint)
    elif args.command == 'prepare':
        prepare(args.label)
    elif args.command == 'measure':
        measure(args.prefix, ORDERS[args.order])
    elif args.command == 'analyze':
        analyze(args.prefix, ORDERS[args.order])
    elif args.command == 'verify-node':
        node_reference(args.prefix)


if __name__ == '__main__':
    main()


