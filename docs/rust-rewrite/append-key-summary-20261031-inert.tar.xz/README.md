# Append-key summary implementation packet

Ready for one bounded experiment against accepted commit `a9d31bddb6fa2efc81315e46d1798d78b1d314b6`. This packet is source review and a plan, not test execution or performance acceptance. The reviewer made no tracked edits. Root started the authorized schema implementation during finalization; all baseline hashes come from the exact parent Git blobs.

`post-push-review.json` records no Date source-review blocker: HEAD and origin/main matched, the tree was clean at review start, and all 61 published Date input hashes match their committed blobs. The accepted measurement producer remains fingerprint `a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480`, originally built from `7c47e38274c9645b6701552c87d38362b2bfbcd5` plus its frozen source patch. Reuse that actual identity with a Git-blob equivalence proof; do not relabel the product as built at a9. Date's first-demand/retained-read costs, higher selected normal-cache RSS and missing original failed executable remain explicit in its report.

## Coherent batch and owners

`plan.json` lists exact disjoint files. Root owns insertion/guard/ABI; the schema agent owns the new field and every constructor; the AOT agent owns actual encoded and collector proofs; the Engine agent owns behavior/GC/later-program fixtures; the documentation agent owns the storage/push/runtime contracts and queue. Agree the single field name `OrdinaryPropertyStorageSchema::MAY_HAVE_INDEXED_KEYS` before integration. Schema ownership of `type_registration_tests.rs` is separate from AOT ownership of its `compact_records.rs` child. Do not race shared files.

There is no new runtime helper/export, global, GC edge, storage mode, Array field, snapshot projection API, dependency or Cargo.lock edge. Bump runtime layout **42 to 43**. The ordinary dictionary remains final and extends the same fieldless ObjectPropertyStorage base.

Finish source, schema, tests and docs together, then format only changed Rust with edition2021/skip_children, inspect diff/source guards, freeze exact inputs, and build the normal two-package union. Do not start broad validation while another chunk is still being authored.

## Exact representation and complete publication audit

Append one mutable bool after ENTRIES, LENGTH, INDEX, preserving ordinals 0/1/2. False proves that no semantic String key ever inserted into this storage began with ASCII U+0030 through U+0039. True means conservative unknown and is sticky. The pinned collector is expected to place the new i32 at byte28 within the existing 32-byte/16-aligned allocation, retaining exactly two GC references; validate actual emitted layout, not hand arithmetic.

Every constructor starts false:

1. `objects/allocation.rs::emit_alloc_object_header_kernel`: empty ordinary dictionary shared by ordinary/Array headers and other existing header consumers.
2. `objects/native_constructor.rs::compile_native_constructor_header_allocate_helper`: capacity4/LENGTH0 dictionary, followed by length/name insertions through the common seam. Do not exempt these statically known names in this candidate.
3. `objects/compact_data.rs::compile_ordinary_property_storage_ensure_helper`: unpublished empty dictionary. Each existing compact shape key is converted to an already canonical PropertyKeyLocals and inserted through the common seam before new PROPERTIES is published.
4. `gc_types/type_registration_tests.rs`: the non-production schema construction witness.

The sole new-key seam is `objects/property_storage.rs::emit_ordinary_insert_in_dictionary`. It is reached from (a) compatible new ordinary definitions through `emit_publish_ordinary_definition` / `emit_ordinary_insert_prepared_property`, (b) `OrdinaryPropertyAppend` after absence proof, including intrinsic/bootstrap installation, (c) the native-constructor two-key producer and (d) compact promotion. Existing-property replacements update descriptor state, not immutable keys. The second PropertyEntry construction in `OrdinaryPropertyPrepare` only copies an existing immutable key/hash/descriptor to a new position and does not insert a new semantic key.

At the common seam, before PropertyTable entry publication, if the flag is false: test the already canonical key's String tag, cast only within that guard, read immutable CODE_UNITS, test nonempty before array access, then classify the first UTF-16 unit as ASCII digit. A match writes true. Symbol, empty and non-digit-leading strings leave false. Reuse typed primitive accessors; no conversion, callback, allocation, helper call, number parsing or full String scan. Root storage/key throughout preparation and insertion. Set before entry publication; preserving a conservative true across a later trap is harmless. The body may be a private emission helper called only by this insertion seam, with no resetting capability.

Never clear on deletion, failed redefinition, descriptor replacement, table growth, compaction, seal/freeze/preventExtensions or prototype replacement. `objects.rs::emit_object_delete_ordinary` tombstones a table entry; `OrdinaryPropertyPrepare` updates ENTRIES/INDEX/LENGTH within the same storage. Both naturally retain the flag. Private fields are a separate table. Compact value updates retain keys; structural promotion visits every old key. A copied or reassigned current PROPERTIES edge carries its own storage's current flag, so there is no object-level cache to invalidate.

Examples: numeric -0 is already canonical String `0` and sets true. `00`, `1x`, `4294967295` and very long digit-leading strings also set true conservatively. Literal `-0`, `+1`, a non-ASCII digit, empty String and Symbol('0') do not denote any append index and may remain false.

## Guard and lifetime

Only edit the ordinary-prototype arm of `objects/packed_array_builtin.rs::emit_packed_push_prototypes_permit_append`:

- Null prototype completes admission. The existing depth8 limit still declines longer chains.
- Actual Array prototype uses the unchanged indexed COUNT==0 proof and then its ordinary header for the next link. Do not use named-storage flags to replace Array indexed checks.
- Other objects must pass the existing concrete OrdinaryObject check. Proxies and exotics decline without traps; do not project their embedded ordinary headers.
- For an admitted OrdinaryObject, read its current PROPERTIES. If that value is a concrete OrdinaryPropertyStorage and its flag is false, bypass this prototype's start..end IntegerDecimalString/OrdinaryOwnDescriptor loop.
- For compact storage or a true dictionary flag, run that exact existing loop. Its descriptor hit still declines to ordinary Set; even a writable inherited data descriptor remains conservatively on that old fallback.
- Both arms converge before the existing current header.PROTOTYPE read and depth increment. A clear dictionary may skip only its own keys, never the rest of the chain.

Preserve actual callable/native identity and defining-Realm guard, left-to-right once-only operand evaluation, saved callable/receiver, Array mode/COUNT==length, writable length, extensibility, range and complete argument checks. Fixed push1/2/3 and general builtin push already share this emitter and canonical indexed publisher. Do not change source-call selection, argument-vector fallback, zero/many argument semantics, overflow/partial write order or borrowed foreign call behavior.

The absence proof lasts only from this invocation's callback-free guard to canonical publication. Every subsequent push reads current storage and each current prototype after callee/argument effects. No loop hoisting, Realm watch, retained chain proof, shape scan or compact promotion is authorized.

## Independent proof seams

AOT schema proof must inspect the actual emitted dictionary and CopyingTypeLayouts: four fields, existing prefix and ordinals, new mutable i32 offset28, 32-byte size, 16-byte alignment, two GC references. Pin all three production constructors to false, including the native and promotion producers. Reuse the existing type-registration harness and existing wasmtime-environ dev dependency. Bind type indices through typed RuntimeSchema access where sibling visibility requires it; do not use private layouts().layout_index.

Extend `tests/emission/guarded_push.rs` with actual encoded control-frame/branch-target proof. Bind OrdinaryPropertyStorage through its existing snapshot type witness; derive the summary field as the unique mutable i32 other than existing PropertiesLength in the actual four-field declaration. The separate typed schema test pins its identity/order. No new GcSnapshotField is needed solely for this test. Require dictionary type test and summary StructGet on the same current storage local under the concrete ordinary prototype branch, clear summary bypass of the decimal/descriptor loop, fallback retaining both helpers, and convergence into the current prototype advance before first publication. The clear route has no Call/CallRef/CallIndirect or GC allocation. The classifier's guarded unit0 read and true publication precede the new property entry publication; compaction must not reset it. Keep the existing actual callee/Realm, no-argv and publisher checks. Cover fixed1/2/3 and actual general ArrayPush body without cloning a module decoder.

Engine behavior uses one new `packed_push_key_summary.js` through existing strict/sloppy `assert_modes`, plus one later-program/forced-GC case in `aot_gc_compact_data_storage.rs`. The fixture must test a custom ordinary dictionary prototype initially clear, late indexed setter/nonwritable insertion, argument-effect and saved-callee getter mutation before push, delete/reinsert with table compaction, current prototype replacement and sibling independence. Preserve own descriptors, return length, setter receiver/argument/count, thrown identity, partial writes and cleanup. Exercise compact prototypes before and after promotion, including a literal initially containing key `0`, plus numeric -0, literal -0, empty, Symbol('0'), `00`, `1x`, and near-u32 property names. Large index cases use sparse lengths; never allocate huge dense arrays. Use isolated custom prototypes where possible; clean any global indexed prototype modifications before assertion helpers allocate arrays. Existing packed_push.js already covers Proxy/exotic paths, inherited Array setter, foreign native borrowing, zero/four arguments, frozen/readonly/nonextensible/sparse and overflow cases.

The second Engine case must retain an actual Array/prototype across independently compiled later programs in the same Realm (existing Test262 native realm helper or retained Engine API), force GC, mutate an indexed prototype property in the later program and observe correct next push in another program. This proves no program-local or cached proof lifetime; unrelated fresh-Engine calls do not establish it. Host snapshots keep their prior semantic graph; the internal bool adds no observable property or reference.

## Bounded validation

Use the existing resource wrapper and normal two-package workspace driver with packages scriptw-aot-wasm and scriptw-engine; no optional feature-root mode. Planned targets/filters are explicit in plan.json: AOT full lib, emission and runtime_link; Engine `aot_array_private_buffers`, `aot_compact_intrinsic_installation`, `aot_gc_compact_data_storage`, `aot_compact_native_metadata`. Existing Engine filter inventories are 11/3/14/4 before authored additions. Record actual selected test inventory and results; zero tests cannot pass and expected counts are not receipts. Preserve passing exact-input scopes through test-only repair and unfinished scopes, and preserve failed executables/streams before retirement. Full broader Engine suites may be selected only for a concrete unresolved ownership concern.

`test262-selection.json` contains hashes, flags, includes and reasons for **36 original JS files** fully read by the reviewer: complete `built-ins/Array/prototype/push` (24), plus 12 explicit adjoining Object/Reflect cases. `test262-paths.txt` is the exact list. No full Object/Reflect/Array-family or variant count is implied. Use original files, flags and deadlines; record runner-selected actual variants. Engine owns summary-state tests absent from the suite.

## Measurement and acceptance

Use the accepted Date producer as baseline, never a rejected fold/shared-empty product. Freeze exact sources, images, executables, configuration and outputs before timing. All performance, RSS/private-dirty and page observations use a fixed **normal overlay SCRIPTW_CACHE_DIR**, with path, filesystem before/after and file-backed admission recorded. Tmpfs may hold verification cache for storage management, but its anonymous-deserialization scope is separate and cannot be pooled. Preserve the Date cache-admission diagnosis.

Reuse existing original17 and all three distinct boundaries: original compiler-free precompiled, ordinary public fresh-Realm, and derived retained-call diagnostic. Startup is a separately named control. Use the established ABBA and BAAB groups, retain every raw observation and per-group median/mean; calculate actual inventories from the chosen existing driver rather than inventing replay counts here. No new benchmark framework, product flags or admission bypass.

Expected route accounting: the default chain checks one ordinary Object.prototype per append index. IntegerDecimalString unconditionally allocates one CodeUnitArray and one StringValue, so 500 objects pushes can avoid 1000 GC allocations and 8192 retained-row pushes 16384. Validate actual short-string collector sizes before stating the estimated 512KiB gross transient churn. This does not remove retained row name strings/objects, numeric backing, or any retained JS field; it is not a live-byte or fixed-RSS claim.

Require repeatable useful original/ordinary gains on multiple array-build workloads, while startup/integer/empty/singleton and all other controls expose insertion classification cost. Retained-only wins cannot substitute for ordinary behavior. If ambiguous, predeclare at most one bounded targeted follow-up; otherwise accept or reject and preserve products. Do not silently exempt statically known bootstrap keys or change classification after a poor first gate: that is a new implementation and separate gate. Keep later i31 bitmap/Inline4 representation work and prior rejected experiments outside this batch.
