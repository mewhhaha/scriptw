"""Inspect frozen own R as inert ELF data outside timed work; never load it."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
BASELINE = ROOT / 'target/performance-date-demand-20261031'
spec = importlib.util.spec_from_file_location(
    'owned_runtime_inspector', ROOT / 'target/performance-memory-parity-20261031/diagnose-pages.py')
inspector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inspector)

identities = {
    'baseline': ('a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480', 42),
    'candidate': ('661084f09940b7242250ba476566cfbee929db4167eb00a43e1fe571cf398d5a', 43),
}
wanted = {
    'array_packed_push1': 'helper::array_packed_push1',
    'array_packed_push2': 'helper::array_packed_push2',
    'array_packed_push3': 'helper::array_packed_push3',
    'array_prototype_push': 'builtin::Array.prototype.push',
    'ordinary_property_append': 'helper::ordinary_property_append',
    'native_constructor_header_allocate': 'helper::native_constructor_header_allocate',
    'property_value_resolve': 'helper::property_value_resolve',
}
rows = {}
for label, folder in [('baseline', BASELINE), ('candidate', OUT)]:
    inspector.WORK = folder
    target = OUT / 'code-size-private' / label
    target.mkdir(parents=True, exist_ok=False)
    host, identity, record = inspector.extract_runtime('candidate', target)
    expected_fingerprint, expected_layout = identities[label]
    assert record['source_fingerprint'] == expected_fingerprint and record['runtime_layout'] == expected_layout
    helpers = {}
    for key, suffix in wanted.items():
        matches = [function for function in record['functions'] if function['name'].endswith('::' + suffix)]
        assert len(matches) == 1, (key, len(matches))
        helpers[key] = matches[0]
    image = target / record['inert_native_file']
    captures = {}
    for key in ['array_packed_push1', 'ordinary_property_append']:
        function = helpers[key]
        length = min(256, function['bytes'])
        with image.open('rb') as stream:
            stream.seek(function['file_offset'])
            entry = stream.read(length)
        assert len(entry) == length
        command = ['/usr/bin/objdump', '-d', f'--start-address={function["value"]}',
                   f'--stop-address={function["value"] + length}', str(image)]
        capture = subprocess.run(command, text=True, capture_output=True, check=True)
        entry_path = target / (key + '-entry-256.txt')
        entry_path.write_text(capture.stdout)
        stderr = target / (key + '-entry-256.stderr')
        stderr.write_text(capture.stderr)
        reservations = re.findall(r'\bsub\s+\$0x([0-9a-f]+),%rsp', capture.stdout)
        allowances = re.findall(r'\badd\s+\$0x([0-9a-f]+),%r10', capture.stdout)
        saved = list(dict.fromkeys(re.findall(r'\bmov\s+%(rbx|r12|r13|r14|r15),0x[0-9a-f]+\(%rsp\)', capture.stdout)))
        captures[key] = dict(raw=str(entry_path.relative_to(OUT)), stderr=str(stderr.relative_to(OUT)),
                            command=command, bytes=length, span_sha256=hashlib.sha256(entry).hexdigest(),
                            observed_stack_reservation_bytes=int(reservations[0], 16) if reservations else None,
                            observed_stack_limit_allowance_bytes=int(allowances[0], 16) if allowances else None,
                            observed_saved_registers=saved,
                            observed_push_rbp=bool(re.search(r'\bpush\s+%rbp', capture.stdout)),
                            scope='Only clear instructions within the first256B. A missing pattern is unknown, not zero. Stack reservation excludes pushed RBP/caller return address. No execution or residency attribution.')
    rows[label] = dict(host=str(host), host_sha256=record['host_sha256'], source_commit=record['source_commit'],
        source_fingerprint=record['source_fingerprint'], runtime_key=record['runtime_key'], runtime_layout=record['runtime_layout'],
        native_sha256=record['native_sha256'], native_bytes=record['native_bytes'], runtime_text_bytes=record['text']['bytes'],
        resolver=helpers['property_value_resolve'], helpers=helpers, entry_captures=captures,
        raw_symbols=str((target / 'candidate-runtime-symbols.json').relative_to(OUT)))
report = dict(schema='scriptw-inert-runtime-code-size-v1', scored=False, native_execution=False, products=rows,
    changes_bytes={key: rows['candidate'][key] - rows['baseline'][key] for key in ['native_bytes', 'runtime_text_bytes']},
    resolver_change_bytes=rows['candidate']['resolver']['bytes'] - rows['baseline']['resolver']['bytes'],
    helper_changes_bytes={name: rows['candidate']['helpers'][name]['bytes'] - rows['baseline']['helpers'][name]['bytes'] for name in wanted},
    identity_policy='Existing bounded extractor hashes each frozen own host against products/identity metadata before and after extraction; validates packed framing, execution receipt, source FP, ABI42/43, decompressed native length/SHA and ELF extents/symbols. No archived native image is loaded or read.',
    limits='Own frozen ELF data and four bounded256B entry captures only. No native payload/module loading or execution, live profiling, executed-code/residency/RSS or causal performance claim. Native images and extracted ELF remain private; archive must exclude them by suffix/magic/regular-file policy. This diagnostic makes no GC byte claim; conditional source counts remain separate.')
(OUT / 'runtime-code-size.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='complete', products={label: dict(source_fingerprint=row['source_fingerprint'], runtime_layout=row['runtime_layout'], native_bytes=row['native_bytes'], runtime_text_bytes=row['runtime_text_bytes'], helpers={name: value['bytes'] for name, value in row['helpers'].items()}, entries={name: {key: capture[key] for key in ['observed_stack_reservation_bytes','observed_stack_limit_allowance_bytes','observed_saved_registers']} for name,capture in row['entry_captures'].items()}) for label,row in rows.items()}, changes_bytes=report['changes_bytes'], helper_changes_bytes=report['helper_changes_bytes']), indent=2), flush=True)
