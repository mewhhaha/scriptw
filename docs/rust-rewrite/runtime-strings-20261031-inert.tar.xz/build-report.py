"""Assemble report-core.json after the string-only runtime cohorts complete; never publish."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = 'e15843397c217c0e113c50e2164c0d1fa5552112'
BASELINE = '6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5'
COMBINED = '6cd1e0d045b9f6a1b131fdaf8353a16a93e204a1ce3c3690887552631fadfd52'



def read(name):
    path = OUT / name
    assert path.stat().st_size <= 16 * 1024**2, path
    return json.loads(path.read_text())


def digest(path):
    # Only source/patch inputs are hashed here; product identities come from receipts.
    assert path.stat().st_size <= 4 * 1024**2, path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def outcome(case, passed, failed=0):
    assert case['outcomes'] == [dict(passed=passed, failed=failed, ignored=0)]
    assert case['state'] == ('failed' if failed else 'passed')
    assert case['exit_code'] == (101 if failed else 0)


def raw_files(stdout):
    assert stdout.endswith('.stdout') and Path(stdout).name == stdout, stdout
    stem = stdout.removesuffix('.stdout')
    paths = dict(stdout=stdout, stderr=stem + '.stderr', command=stem + '.command.json')
    assert all((OUT / name).is_file() for name in paths.values()), paths
    return paths


def validate_analysis(name, order, expected, identities, product_records, node_identity, require_means=False):
    report = read(name)
    assert report['order'] == order
    assert report['samples'] == 21 and report['warmups'] == 10
    rows = report['workloads']
    assert len(rows) == len(expected) > 0
    assert len({row['file'] for row in rows}) == len(expected)
    assert {row['file'] for row in rows} == set(expected)
    raw = []
    prefix = name.removesuffix('-analysis.json')
    for row in rows:
        assert row['source_sha256'] == digest(OUT / 'sources' / row['file'])
        for boundary in ('original', 'retained', 'ordinary'):
            products = row[boundary]['products']
            assert set(products) == {'baseline', 'candidate'}
            for label, values in products.items():
                assert math.isfinite(values['median_ns']) and values['median_ns'] > 0
                rounds = values['rounds']
                assert [r['index'] for r in rounds] == [i for i, actual in enumerate(order) if actual == label]
                assert all(r['raw'] == f"{prefix}-r{r['index']}-{label}-{boundary}-{row['file']}.stdout" for r in rounds)
                paths = [raw_files(r['raw']) for r in rounds]
                raw.extend(paths)
                scores, rss = [], []
                for round_row, files in zip(rounds, paths):
                    record = read(files['stdout'])
                    command = read(files['command'])
                    tool = 'runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline'
                    identity = product_records[label][tool]['sha256']
                    assert command['exit_code'] == 0 and not command['timed_out']
                    assert command['executable_sha256'] == identity
                    assert record['source_fingerprint'] == identities[label]['source_fingerprint']
                    assert record['executable_sha256'] == identity
                    if boundary != 'ordinary':
                        assert record['compiler_enabled'] is False
                    else:
                        assert record['cases'][0]['source_sha256'] == row['source_sha256']
                    observations = record['cases'][0]['observations'] if boundary == 'ordinary' else record['observations']
                    assert len(observations) == 31
                    assert all(o.get('matched', True) and o['stdout'] == expected[row['file']]['stdout'] for o in observations)
                    samples = [o for o in observations if not o['warmup']]
                    assert len(samples) == 21
                    times = [o['call_ns'] if boundary == 'retained' else o['phases_ns']['execution'] if boundary == 'original' else o['execution_ns'] for o in samples]
                    assert statistics.median(times) == round_row['median_ns']
                    scores.extend(times)
                    if boundary == 'original':
                        rss.extend(o['process_snapshots']['after_execution']['rss_bytes'] for o in samples)
                    if require_means:
                        assert statistics.mean(times) == round_row['mean_ns']
                assert statistics.median(scores) == values['median_ns']
                if require_means:
                    assert values['samples'] == len(scores) == 21 * order.count(label)
                    assert math.isfinite(values['mean_ns']) and values['mean_ns'] > 0
                    assert statistics.mean(scores) == values['mean_ns']
                    if boundary == 'original':
                        assert statistics.median(rss) == values['rss_bytes']
            calculated = 100 * (products['candidate']['median_ns'] / products['baseline']['median_ns'] - 1)
            assert math.isclose(row[boundary]['change_percent'], calculated, abs_tol=1e-9)
            if require_means:
                calculated_mean = 100 * (products['candidate']['mean_ns'] / products['baseline']['mean_ns'] - 1)
                assert math.isclose(row[boundary]['mean_change_percent'], calculated_mean, abs_tol=1e-9)
        reference = row['v8_reference']
        assert reference['median_ns'] > 0 and math.isfinite(reference['median_ns'])
        assert [r['index'] for r in reference['rounds']] == list(range(len(order)))
        v8_scores = []
        for round_row in reference['rounds']:
            index = round_row['index']
            assert round_row['raw'] == f"{prefix}-r{index}-{order[index]}-v8-{row['file']}.stdout"
            paths = raw_files(round_row['raw'])
            raw.append(paths)
            command, record = read(paths['command']), read(paths['stdout'])
            assert command['exit_code'] == 0 and not command['timed_out']
            assert command['executable_sha256'] == node_identity['sha256']
            assert record['samples'] == 21 and record['warmups'] == 10
            case = record['cases'][0]
            assert case['file'] == row['file'] and case['source_sha256'] == row['source_sha256']
            assert len(case['observations']) == 31
            assert all(o['stdout'] == expected[row['file']]['stdout'] for o in case['observations'])
            samples = [o for o in case['observations'] if not o['warmup']]
            assert len(samples) == 21
            v8_scores.extend(o['execution_ns'] for o in samples)
        assert statistics.median(v8_scores) == reference['median_ns']
    return report, raw


def startup_rows(prefix, order, expected_stdout, identities, products):
    rows = []
    for index, label in enumerate(order):
        stem = f'{prefix}-r{index}-{label}-startup'
        paths = raw_files(stem + '.stdout')
        command = read(paths['command'])
        assert command['exit_code'] == 0 and not command['timed_out']
        record = read(paths['stdout'])
        assert record['source_fingerprint'] == identities[label]['source_fingerprint']
        product = products[label]['compiler_precompiled_baseline']['sha256']
        assert command['executable_sha256'] == record['executable_sha256'] == product
        assert record['compiler_enabled'] is False
        observations = record['observations']
        assert len(observations) == 31
        assert all(o['matched'] and o['stdout'] == expected_stdout for o in observations)
        samples = [o for o in observations if not o['warmup']]
        assert len(samples) == 21
        rows.append(dict(
            index=index, product=label, raw=paths,
            median_execution_ns=statistics.median(o['phases_ns']['execution'] for o in samples),
        ))
    return rows


def validate_resources(resources):
    before, after = resources['before'], resources['after']
    assert before['affinity'] == after['affinity'] == [0]
    assert before['cloud_budget_bytes'] == after['cloud_budget_bytes'] == 32 * 1024**3
    for key in ('memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max'):
        assert before['cgroup'][key] == after['cgroup'][key]
    assert int(before['cgroup']['memory.max']) == before['cloud_budget_bytes']


def main():
    expected_native = {
        'native-strings-primary/receipt.json': {
            ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'intrinsics::deferred_methods::'): 3,
            ('scriptw-aot-wasm', 'runtime_link', None): 31,
            ('scriptw-engine', 'aot_gc_entries', 'aot_gc_intrinsic_publication::'): 3,
            ('scriptw-engine', 'aot_language', 'aot_compact_native_metadata::'): 4,
            ('scriptw-engine', 'aot_realm_modules', 'aot_created_realm_array_iterator::'): 6,
        },
        'native-strings-secondary/receipt.json': {
            ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'tests::bootstrap_compact_metadata::'): 4,
            ('scriptw-engine', 'aot_realm_modules', 'aot_native_function_source_syntax::'): 3,
        },
    }
    native_rows, selected_tests, receipt_totals = [], set(), {}
    for name, expected in expected_native.items():
        receipt = read(name)
        assert receipt['head'] == PARENT and receipt['source_unchanged']
        assert receipt['shared_runtime_linker_unchanged']
        cases = {(c['package'], c['target'], c.get('native_filter')): c for c in receipt['cases']}
        assert len(cases) == len(receipt['cases']) and set(cases) == set(expected)
        total = 0
        for key, case in cases.items():
            count = case['outcomes'][0]['passed']
            outcome(case, count)
            assert count == expected[key] == case['inventoried_tests'] and case['inventory_matches']
            inventory = ROOT / case['inventory_log']
            assert inventory.is_relative_to(OUT)
            assert digest(inventory) == case['inventory_sha256']
            names = re.findall(r'^(.+): test$', inventory.read_text(), re.M)
            assert len(names) == count
            for test_name in names:
                test_key = (case['package'], case['target'], test_name)
                assert test_key not in selected_tests, test_key
                selected_tests.add(test_key)
            native_rows.append(dict(receipt=name, package=key[0], target=key[1], filter=key[2],
                                    passed=count, inventory=case['inventory_log'],
                                    inventory_sha256=case['inventory_sha256'],
                                    executable_sha256=case['executable_sha256']))
            total += count
        receipt_totals[name] = total
    assert list(receipt_totals.values()) == [47, 7]
    native_passes = sum(receipt_totals.values())
    assert native_passes == len(selected_tests) == 54
    native_streams = read('native-stream-index.json')
    assert len(native_streams) == len(native_rows) == 7
    assert {(r['receipt'], r['scope'], r['filter']) for r in native_streams} == {
        (r['receipt'], r['target'], r['filter']) for r in native_rows
    }
    assert all((OUT / row['path']).is_file() for row in native_streams)

    inputs = read('compiled-inputs.json')
    assert len(inputs) == 8
    checked_inputs = {}
    for name, record in inputs.items():
        if name.startswith('crates/'):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            assert digest(ROOT / name) == record['sha256'], name
            checked_inputs[name] = record
    assert set(checked_inputs) == {
        'crates/scriptw-aot-wasm/src/intrinsics/deferred_methods/materialization.rs',
        'crates/scriptw-aot-wasm/src/intrinsics/deferred_methods/materialization/tests.rs',
    }
    draft_checks = read('checks.json')
    draft_hashes = read('candidate-hashes.json')
    assert draft_checks['candidate_value_rs_equals_HEAD'] and draft_checks['removed_selector_references_absent']
    assert draft_checks['formatting']['exit_code'] == 0
    assert '2021' in draft_checks['formatting']['arguments']
    for name, record in checked_inputs.items():
        assert record == draft_hashes['files'][name]
    value_source = ROOT / 'crates/scriptw-aot-wasm/src/gc_types/value.rs'
    value_identity = draft_hashes['files'][str(value_source.relative_to(ROOT))]
    assert digest(value_source) == value_identity['sha256']
    assert 'deferred_builtin_code' not in value_source.read_text()
    absent_modules = [
        'crates/scriptw-aot-wasm/src/gc_types/value/deferred_builtin_code.rs',
        'crates/scriptw-aot-wasm/src/gc_types/empty_array_properties.rs',
        'crates/scriptw-aot-wasm/src/gc_types/type_registration_tests/empty_array_properties.rs',
        'crates/scriptw-engine/tests/fixtures/array_private_buffers/shared_empty_named_storage.js',
    ]
    assert all(not (ROOT / name).exists() for name in absent_modules)
    runtime_source = ROOT / 'crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    assert re.search(r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*41\s*;', runtime_source.read_text())
    assert not re.search(r'\bmod\s+empty_array_properties\s*;', (ROOT / 'crates/scriptw-aot-wasm/src/gc_types.rs').read_text())

    rejected_experiments = [
        dict(name='numeric GetV probe', directory='performance-numeric-probe-20261031',
             source_fingerprint='c615b6e3b896f4aedc8a4292199a11e27114e914d1e6970fe67b3ea8790a03d1'),
        dict(name='combined runtime ownership and full fold', directory='performance-runtime-ownership-20261031',
             source_fingerprint=COMBINED),
        dict(name='full resolver fold', directory='performance-runtime-fold-20261031',
             source_fingerprint='3d2ea794bdc1585d9a5eff2aed93f729050df96f4dc04f24827eede5687698c6'),
    ]
    for experiment in rejected_experiments:
        experiment.update(status='rejected', source_coverage_reused=False,
                          report_core=str(ROOT / 'target' / experiment['directory'] / 'report-core.json'))
    candidate_identity = read('candidate/identity.json')
    candidate_products = read('candidate/products.json')
    candidate_fingerprint = candidate_identity['source_fingerprint']
    assert re.fullmatch(r'[0-9a-f]{64}', candidate_fingerprint)
    assert candidate_fingerprint not in {BASELINE, *(row['source_fingerprint'] for row in rejected_experiments)}
    assert candidate_identity['source_commit'] == PARENT
    accepted_identity = read('baseline-identity.json')
    accepted_products = read('baseline-products.json')
    assert accepted_identity['source_fingerprint'] == BASELINE
    assert accepted_identity['source_commit'] == '69ce371b964cc3af8da79750507ba5018eb2aef2'
    identities = dict(baseline=accepted_identity, candidate=candidate_identity)
    products = dict(baseline=accepted_products, candidate=candidate_products)
    for label in products:
        assert set(products[label]) == {'compiler_precompiled_baseline', 'runtime_baseline', 'scriptw'}
        assert products[label]['compiler_precompiled_baseline']['sha256'] == identities[label]['executable_sha256']
        assert identities[label]['shared_configuration'] == candidate_identity['shared_configuration']
    baseline_reuse = read('baseline-reuse-proof.json')
    assert baseline_reuse['parent_commit'] == PARENT
    assert baseline_reuse['baseline_original_identity'] == accepted_identity
    assert baseline_reuse['baseline_products'] == accepted_products
    build = read('candidate-build.json')
    assert build['head'] == PARENT and build['exit_code'] == 0

    test262_plan = read('test262-plan.json')
    families = test262_plan['families']
    assert len(families) == len({row['scope'] for row in families}) == 8
    assert test262_plan['expected_executions_from_combined_same_pins'] == 276
    suite = read('test262-candidate-summary.json')
    assert len(suite['runs']) == 8
    assert {row['scope'] for row in suite['runs']} == {row['scope'] for row in families}
    for run in suite['runs']:
        assert run['product'] == 'candidate' and run['exit_code'] == 0
        assert run['passed'] == run['total'] and run['total'] > 0
        assert run['executable_sha256'] == candidate_products['scriptw']['sha256']
        assert Path(run['raw']).name == run['raw'] and (OUT / run['raw']).is_file()
    test262_executions = sum(run['passed'] for run in suite['runs'])
    assert test262_executions == 276

    guards = (OUT / 'source-guards.log').read_text()
    assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed; 0 failed;', guards))) == 359
    assert 'ok (30 permanent areas)' in (OUT / 'ownership.log').read_text()
    assert len(re.findall(r'^PASS ', (OUT / 'intl-source.log').read_text(), re.M)) == 15
    audit = dict(status='not separately recorded for this cohort')
    if (OUT / 'product-graph.log').exists():
        assert 'check-no-interpreter-in-product-graph: ok' in (OUT / 'product-graph.log').read_text()
        audit = dict(status='passed', raw='product-graph.log')

    manifest = read('sources/manifest.json')
    startup = manifest['startup']
    expected = {row['file']: row for row in manifest['execution'] if row['file'] != startup['file']}
    assert len(expected) == 17
    definitions = {
        'initial': ['baseline', 'candidate', 'candidate', 'baseline'],
        'confirmation': ['candidate', 'baseline', 'baseline', 'candidate'],
    }
    cohorts, contexts, raw_index, startup_controls, resources = {}, {}, {}, {}, {}
    reference_node = None
    harness = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
    for prefix, order in definitions.items():
        resources[prefix] = dict(before=read(prefix + '-resources-before.json'),
                                 after=read(prefix + '-resources-after.json'),
                                 node_identity=read(prefix + '-node-identity.json'))
        validate_resources(resources[prefix])
        node = resources[prefix]['node_identity']
        assert node['harness_sha256'] == digest(harness)
        if reference_node is None:
            reference_node = node
        assert all(node[key] == reference_node[key] for key in ('sha256', 'harness_sha256', 'versions'))
        contexts[prefix] = dict(baseline_kind='accepted-fusion', identities=identities, products=products,
                                order=order, scope='Accepted fusion 6764 versus this frozen string-only candidate.')
        cohorts[prefix], raw_index[prefix] = validate_analysis(
            prefix + '-analysis.json', order, expected, identities, products, node,
        )
        startup_controls[prefix] = startup_rows(prefix, order, startup['stdout'], identities, products)
    table = []
    for name in expected:
        row = dict(file=name, source_sha256=None, cohorts={})
        for prefix, analysis in cohorts.items():
            actual = next(value for value in analysis['workloads'] if value['file'] == name)
            if row['source_sha256'] is None:
                row['source_sha256'] = actual['source_sha256']
            assert actual['source_sha256'] == row['source_sha256']
            row['cohorts'][prefix] = {key: actual[key] for key in ('original', 'retained', 'ordinary', 'v8_reference')}
        table.append(row)

    optional_controls = {}
    control_paths = set(OUT.glob('*control*-analysis.json')) | set(OUT.glob('*targeted*-analysis.json'))
    control_plan = read('control-plan.json') if (OUT / 'control-plan.json').exists() else None
    if control_plan is not None:
        assert (OUT / 'controls-analysis.json').is_file()
    for path in sorted(control_paths):
        control = read(path.name)
        if 'complete' in control:
            assert control['complete'] is True
        prefix = path.name.removesuffix('-analysis.json')
        fixtures = [row['file'] for row in control['workloads']]
        assert 0 < len(fixtures) == len(set(fixtures)) <= 17
        assert set(fixtures).issubset(expected)
        order = control['order']
        assert order in [definitions['initial'], definitions['confirmation'],
                         definitions['initial'] + definitions['confirmation']]
        if prefix == 'controls' and control_plan is not None:
            assert set(fixtures) == set(control_plan['fixtures'])
            assert order == control_plan['order']
            assert control_plan['samples'] == 21 and control_plan['warmups'] == 10
        control_resources = dict(before=read(prefix + '-resources-before.json'),
                                 after=read(prefix + '-resources-after.json'),
                                 node_identity=read(prefix + '-node-identity.json'))
        validate_resources(control_resources)
        node = control_resources['node_identity']
        assert node['harness_sha256'] == digest(harness)
        assert all(node[key] == reference_node[key] for key in ('sha256', 'harness_sha256', 'versions'))
        require_means = any('mean_ns' in product for row in control['workloads']
                            for boundary in ('original', 'retained', 'ordinary')
                            for product in row[boundary]['products'].values())
        control, control_raw = validate_analysis(
            path.name, order, {name: expected[name] for name in fixtures},
            identities, products, node, require_means=require_means,
        )
        optional_controls[path.name] = dict(
            report=control, plan=control_plan if prefix == 'controls' else None,
            cohort_context=dict(baseline_kind='accepted-fusion', identities=identities, products=products, order=order),
            raw_stream_index=control_raw, resources=control_resources,
            startup_controls=startup_rows(prefix, order, startup['stdout'], identities, products),
            scope='Optional root-run selected controls, separately validated against accepted fusion. No rejected-source evidence or expanded correctness coverage is inherited.',
        )

    diagnostics = {}
    if (OUT / 'runtime-code-size.json').exists():
        size = read('runtime-code-size.json')
        assert size['scored'] is False
        assert size['products']['baseline']['source_fingerprint'] == BASELINE
        assert size['products']['candidate']['source_fingerprint'] == candidate_fingerprint
        assert size['products']['baseline']['host_sha256'] == accepted_identity['executable_sha256']
        assert size['products']['candidate']['host_sha256'] == candidate_identity['executable_sha256']
        assert size['products']['baseline']['runtime_layout'] == size['products']['candidate']['runtime_layout'] == 41
        diagnostics['runtime_code_size'] = size
    else:
        diagnostics['runtime_code_size_status'] = 'Not yet recorded; native-byte improvement remains unverified.'
    if (OUT / 'scriptc-comparison.json').exists():
        comparison = read('scriptc-comparison.json')
        if comparison.get('complete') is True:
            assert comparison['samples'] == 21 and comparison['warmups'] == 10
            assert len(comparison['workloads']) == 17
            assert {row['file'] for row in comparison['workloads']} == set(expected)
            assert len(comparison['attempts']) == 68
            seen, scriptc_raw = set(), []
            for attempt in comparison['attempts']:
                key = (attempt['round'], attempt['runtime'], attempt['file'])
                assert key not in seen and key[0] in (0, 1) and key[1] in ('scriptw', 'scriptc') and key[2] in expected
                seen.add(key)
                paths = raw_files(attempt['raw'])
                command, record = read(paths['command']), read(paths['stdout'])
                assert command['exit_code'] == 0 and not command['timed_out']
                assert command['executable_sha256'] == record['executable_sha256'] == candidate_identity['executable_sha256']
                assert record['source_fingerprint'] == candidate_fingerprint and record['compiler_enabled'] is False
                assert record['image_sha256'] == attempt['image_sha256']
                assert len(record['observations']) == 31
                assert all(o['stdout'] == expected[key[2]]['stdout'] for o in record['observations'])
                assert sum(not o['warmup'] for o in record['observations']) == 21
                scriptc_raw.append(paths)
            diagnostics['scriptc_comparison'] = comparison
            diagnostics['scriptc_raw_stream_index'] = scriptc_raw
        else:
            diagnostics['scriptc_comparison_pending'] = dict(raw='scriptc-comparison.json',
                                                            scope='Incomplete optional comparison; excluded from measured claims.')

    report = dict(
        schema='scriptw-runtime-strings-v1',
        recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='measured-review-pending',
        source=dict(
            parent_commit=PARENT, candidate_fingerprint=candidate_fingerprint,
            candidate_identity=candidate_identity, candidate_products=candidate_products,
            candidate_build=build, accepted_baseline_reuse_proof=baseline_reuse,
            patch_sha256=digest(OUT / 'compile-inputs.patch'), inputs=inputs,
            verified_current_crate_inputs=checked_inputs,
            unchanged_parent_value_source=dict(path=str(value_source.relative_to(ROOT)), identity=value_identity,
                                               proof='Current hash equals the saved candidate value.rs that source-only checks established is byte-identical to parent HEAD; it is not one of the two changed Rust inputs.'),
            runtime_source=dict(path=str(runtime_source.relative_to(ROOT)), sha256=digest(runtime_source), layout_version=41),
            identity_note='Candidate is frozen parent e15843397 plus the exact eight-file string-only snapshot/patch, with its actual fingerprint read from candidate/identity.json. Two current Rust hashes are checked; six README/docs snapshots may receive measured prose. Selector module removal restores parent value.rs rather than adding a value-layout diff. Both mandatory cohorts use only accepted fusion fingerprint 6764.',
        ),
        change=dict(
            runtime_layout_version=41, abi_layout_changed=False, default_policy_changed=False,
            shared_empty_array_graph=False, new_runtime_global=False, selector_module=False,
            resolver=dict(code_allocation_sites_before=823, code_allocation_sites_after=823,
                          string_resolution_call_sites_before=1646, string_resolution_call_sites_after=2,
                          behavior='Each exact-ID leaf retains its original checked typed ExecutableCode allocation. Only pooled name/source string resolution moves into the shared ordered tail. Code, name, source, callable construction and recipe cache-publication order, defining Realm and GC rooting remain unchanged.',
                          scope='Static emitted string call-site reduction; dynamic code allocations, string resolutions and their order remain unchanged. No allocation-count reduction or eager table is introduced.'),
            claims='Native code-byte improvement must come from this candidate’s optional inert runtime-code-size record; it is not inferred from site counts. No shared-empty graph saving, live heap, executed-page or process RSS reduction is claimed from this source structure.',
        ),
        validation=dict(
            native_passing_cases=native_passes, native_selected_case_groups=len(native_rows),
            native_receipt_totals=receipt_totals, native_groups=native_rows, native_streams=native_streams,
            native_count_note='54 fresh string-source selected native checks derive from primary 47 plus secondary 7 complete source-unchanged receipts. AOT filters select 3+4, runtime_link 31, engine GC 3, language 4 and Realm filters 6+3. Inventory names are disjoint across groups. This is focused validation, not a full workspace/library run or reuse of a rejected source’s checks.',
            test262_selected_family_count=8, test262_passing_executions=test262_executions,
            test262_plan=test262_plan, test262_original_families=suite,
            coverage_note='Eight original metadata/alias families completed 276 actual variants using this string-only frozen CLI. All rejected-source correctness inventories remain separate.',
            source_only_guards=359, conformance_owners=30, intl_recipes=15, product_interpreter_audit=audit,
            formatting=dict(changed_rust='The two changed Rust files match the saved three-file edition-2021 draft format check; the third formatted source is unchanged parent value.rs.',
                            saved_check=draft_checks['formatting'],
                            full_workspace='Inherited 17 pre-existing file failures remain unresolved; no fresh full-workspace formatting or release acceptance claim.'),
        ),
        separate_rejected_experiments=rejected_experiments,
        measurement=dict(
            plan=read('measurement-plan.json'), cohort_contexts=contexts, cohorts=table,
            complete_cohort_reports=cohorts, raw_stream_index=raw_index,
            startup_controls=startup_controls, resources=resources,
            optional_root_run_controls=optional_controls,
            boundaries='Full-17 initial ABBA and confirmation BAAB both compare this string-only candidate with accepted fusion 6764. Original compiler-disabled fresh Store/Realm execution, strict-derived retained calls, ordinary runtime_baseline and Node fresh-context references remain separate boundaries. Every raw executable/source identity, output, startup control and Node/harness resource record is checked; slower controls remain visible.',
            memory='Post-execution smaps process RSS with Store alive is not live JavaScript bytes, peak memory or per-owner attribution. Whole-child GNU time peaks include loading/compiler and identity hashing. No result from the rejected combined/full-fold experiments is merged into this source’s measurement cohort.',
            resource_policy='Inherited managed-cloud 32 GiB cap; CPU 0 for measurements/tests, quota-bound build CPUs; serial Cargo/libtest and retained module cache 512 entries/2 GiB. Swap/group OOM settings are inherited, not local 4 GiB guarantees.',
        ),
        diagnostics=diagnostics,
        limits=[
            'Only the 54 fresh selected native checks and eight original Test262 families are this source’s correctness coverage; rejected experiment checks are not adopted.',
            'Selected replays are not full pinned-suite publication or full release acceptance; published benchmark graphs and full Test262 status remain unchanged.',
            'Every-case V8/Scriptc execution-time and RSS parity remains open; optional comparisons do not establish universal parity.',
            'Both full-17 cohorts and any optional root-run controls retain all slower/outlier observations and startup raw results.',
            'There remain 823 original ExecutableCode allocation sites; only pooled string call sites change from 1646 to 2. Dynamic allocation/string counts and order are unchanged.',
            'Native-byte benefit and acceptable time/RSS controls remain a root-reviewed retention gate, not an automatic consequence of static site reduction.',
        ],
    )
    (OUT / 'report-core.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(native_selected_passes=native_passes, native_case_groups=len(native_rows),
                          test262_executions=test262_executions, candidate_fingerprint=candidate_fingerprint,
                          workloads=len(table), cohorts=list(cohorts), optional_controls=list(optional_controls),
                          status=report['status'], output='report-core.json'), indent=2), flush=True)


if __name__ == '__main__':
    main()

