# String-only deferred-method fold: source-only fallback

This draft applies to the current full-fold workspace at HEAD e15843397c217c0e113c50e2164c0d1fa5552112, whose frozen production fingerprint is 3d2ea794bdc1585d9a5eff2aed93f729050df96f4dc04f24827eede5687698c6. It does not apply directly to clean HEAD: verify every base hash before applying. All edits are confined to this scratch directory. No build, native execution, timing, or measured-benefit claim accompanies this draft.

## Files

- `base/` records all four affected files exactly, including the currently untracked selector module.
- `candidate/` contains the three surviving files. The selector module is deliberately absent.
- `implementation.patch` changes materialization.rs, removes the selector re-export/module declaration, and deletes deferred_builtin_code.rs.
- `tests.patch` revises the existing actual-Wasm structural test.
- `all.patch` combines both patches; `base-hashes.json`, `candidate-hashes.json`, and `checks.json` record identity and source-only checks.

The parent owns applying the patch and updating the owning product documents. Existing full-fold wording must be changed to describe only string-call sharing before any acceptance commit.

## Narrow implementation

Selection.code is restored to the original nullable GcLocal<ExecutableCode>. Each exact-ID leaf invokes the original checked PlannedFunctionEntry::emit_executable_code publisher, stores its result in that root, and selects the name/source Runtime string-pool ordinals and length. Four values cross the selection merge: one code root, two i32 ordinals, and one i64 length. The complete-ID dispatch and MethodPlan metadata domain remain unchanged.

The common tail binds the nonnull selected code root, resolves the selected name, then resolves the selected source. Function/header/context allocation, context-cycle closure, metadata publication, and later recipe.CACHED publication remain unchanged. The DeferredBuiltinCodeSelection type and its source-ID/builtin/typed-entry selection locals are removed. No new tables, GC layouts, global slots, Array changes, ABI change, or executable-code representation are introduced. Runtime ABI remains 41.

The current 823-method domain is expected to keep 823 physical ExecutableCode allocation sites and reduce 1,646 physical pooled-string calls to two. The structural test checks one code allocation and typed entry per exact-ID leaf rather than hard-coding 823, checks two pooled-string calls after every code allocation and before function allocation, and forbids calls or other GC allocations in the selection region. Dynamic work remains one code allocation plus two string resolutions per uncached method. Strings may be cached already; no allocation-avoidance claim is made for their dynamic resolution.

## Order and rooting review

The only runtime movement is name/source resolution from the selected leaf to the immediately following shared tail. Code allocation still precedes name resolution, which precedes source resolution and the original object/context/function tail. The branch merge performs no JS callback, helper call, or allocation. Invalid IDs still trap in the exact-identity tree. Runtime-pool ordinals are checked during emission and cannot select program literals.

The selected code root stays live through the merge; the tail holds a second typed nonnull code root before the first string resolver. The name root is established before source resolution, and code/name/source remain separately rooted across the remaining allocations. Leaf temporaries are cleared only after publishing their value into Selection.code. The selection root is released only after the whole callable has been created. The captured Realm remains the existing materialization context, so canonical aliases, fresh-Store/fresh-Realm identities, defining-Realm Function.prototype/errors, and cache-publication order are unchanged.

GC allocation failure order remains code, name resolution, source resolution, then the existing tail. Emission-time string-domain validation may reject a malformed compiler plan before any runtime body is used. There is no new user-code reentry point or eager string materialization.

## Exact update to the 54-check plan

Keep the same five binaries and namespace selections, freshly built from this candidate:

| Package / target | Filter | Tests |
| --- | --- | ---: |
| scriptw-aot-wasm --lib | intrinsics::deferred_methods:: | 3 |
| same | tests::bootstrap_compact_metadata:: | 4 |
| scriptw-aot-wasm --test runtime_link | entire target | 31 |
| scriptw-engine --test aot_gc_entries | aot_gc_intrinsic_publication:: | 3 |
| scriptw-engine --test aot_language | aot_compact_native_metadata:: | 4 |
| scriptw-engine --test aot_realm_modules | aot_created_realm_array_iterator:: | 6 |
| same | aot_native_function_source_syntax:: | 3 |

Only one test is renamed/revised: materialization::tests::deferred_dispatch_has_many_typed_entries_but_one_function_construction_tail becomes materialization::tests::deferred_dispatch_keeps_code_allocations_in_leaves_and_shares_string_resolution. Namespace filters therefore still select 54 tests. Its old single-code-allocation/no-allocation-leaves assertions are replaced by one original code allocation per guarded typed entry, no other allocation/call in the tree, and exactly two ordered shared string calls. The metadata rejection test and existing Engine GC/Realm/code-identity regression are unchanged. No additional behavior test or test module is proposed. These source-only assertions are not yet typechecked or executed.

The already selected eight complete original Test262 families (Function.prototype.toString, Array.prototype.values/Symbol.iterator, Set.prototype.keys/values, Math.abs/max, Date.prototype.getTime) remain suitable fresh execution coverage; earlier products' passes must stay labelled with their own identities.

## Measurement gate and limits

The completed full-fold control cohort supports rejecting that product: ordinary singleton +7.99% median/+12.73% mean, ordinary small join +3.06%/+12.05%, ordinary objects +6.76%/+5.98%, and original integer +8.21%/+6.22%. The small retained-object target gains do not erase these control results. Do not time the rejected full fold again.

This string-only draft is a separate bounded experiment against accepted fusion fingerprint 6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5. Preserve the same original, ordinary, and retained boundaries and slower controls. Static native/metadata reduction, lower RSS, and improved timing all require new evidence. Keeping four selection values is a source fact, not proof that selection pressure caused prior regressions: warmed retained calls bypass method selection through the recipe cache, though changing the enclosing helper can affect generated code or placement.

Root later moved the source-only `candidate/` tree unchanged to `draft-candidate/` before freezing products. `candidate/` is reserved for the three fresh executable products and identity metadata; `draft-relocation.json` records the move.
