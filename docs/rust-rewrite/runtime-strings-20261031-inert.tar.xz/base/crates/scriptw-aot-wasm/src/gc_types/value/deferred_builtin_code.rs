//! Select a registered ordinary builtin without allocating its executable record.
//! The private locals keep entry, source identity and builtin identity together;
//! no caller can combine independently selected metadata with another entry.
use super::*;
use crate::emitted_function::FunctionIdentity;
use crate::function_entry::PlannedFunctionEntry;

pub(crate) struct DeferredBuiltinCodeSelection {
    entry: FunctionLocal<OrdinaryCallable, Nullable>,
    source_id: I64Local,
    builtin: GcI32DomainLocal<Option<scriptw_ir::StandardBuiltinId>>,
}

impl DeferredBuiltinCodeSelection {
    pub(crate) fn reserve(schema: &RuntimeSchema, function: &mut Function) -> Self {
        Self {
            entry: schema
                .reserve_function_local::<OrdinaryCallable, Nullable>(function)
                .initialize_null(function),
            source_id: schema.reserve_i64_local(function),
            builtin: GcI32DomainLocal::new(schema, None, function),
        }
    }

    pub(crate) fn select(
        &self,
        entry: &PlannedFunctionEntry,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) -> Result<(), crate::EmitError> {
        let FunctionIdentity::StandardBuiltin(builtin) = entry.identity() else {
            return Err(crate::EmitError::unsupported(
                "deferred builtin code selection requires a registered standard builtin",
            ));
        };
        if entry.protocol() != scriptw_ir::FunctionProtocolIr::OrdinaryCallOnly
            || entry.binary_numeric().is_some()
        {
            return Err(crate::EmitError::unsupported(
                "deferred builtin code selection requires an ordinary nonconstructor entry",
            ));
        }
        self.entry.replace(
            schema
                .reference_entry::<OrdinaryCallable>(entry, function)?
                .nullable(),
            function,
        );
        self.source_id.set_constant(entry.source_id(), function);
        self.builtin.set_constant(Some(builtin), function);
        Ok(())
    }

    pub(crate) fn publish(
        &self,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) -> GcStackReference<ExecutableCode> {
        // Only select can set this reference and its paired scalar metadata.
        // An unselected path traps before any code record can be published.
        let entry = schema
            .reserve_function_local::<OrdinaryCallable, NonNullable>(function)
            .initialize(
                self.entry.load(function).require_non_null(function),
                function,
            );
        let code = schema.struct_type::<ExecutableCode>().construct(
            (
                GcOperand::i64_local(self.source_id),
                GcOperand::constant(ExecutableCodeKind::StandardBuiltin),
                self.builtin.operand(),
                GcOperand::constant(None::<scriptw_ir::HostBuiltinId>),
                GcOperand::constant(scriptw_ir::FunctionProtocolIr::OrdinaryCallOnly),
                GcOperand::constant(scriptw_ir::ClassElementExecutionKind::None),
                GcOperand::function_reference(&entry),
                GcOperand::null_function(),
                GcOperand::null_function(),
                GcOperand::null_function(),
                GcOperand::null_function(),
            ),
            function,
        );
        entry.clear(function);
        code
    }

    pub(crate) fn release(self, schema: &RuntimeSchema, function: &mut Function) {
        self.builtin.clear(schema, function);
        schema.release_i64_local(self.source_id, function);
        self.entry.clear(function);
    }
}
