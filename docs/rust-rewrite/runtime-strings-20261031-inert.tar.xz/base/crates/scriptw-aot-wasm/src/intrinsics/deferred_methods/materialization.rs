//! One closed ordinary-native construction tail, selected without JS execution.
use super::*;
use crate::emitted_function::FunctionIdentity;

/// Only the metadata proven uniform for deferred methods can enter the tree.
/// Future planner changes fail emission here, before any partial body escapes.
pub(super) struct MethodPlan {
    pub(super) method: DeferredIntrinsicMethod,
    meta: WasmFunctionMeta,
}
impl MethodPlan {
    pub(super) fn new(
        method: DeferredIntrinsicMethod,
        meta: WasmFunctionMeta,
    ) -> Result<Self, EmitError> {
        let valid = meta.standard_builtin == Some(method.0)
            && DeferredIntrinsicMethod::new(method.0).is_some()
            && matches!(meta.entry.identity(), FunctionIdentity::StandardBuiltin(id) if id == method.0)
            && meta.entry.executable_kind()? == ExecutableCodeKind::StandardBuiltin
            && meta.protocol() == scriptw_ir::FunctionProtocolIr::OrdinaryCallOnly
            && meta.host_builtin.is_none()
            && meta.strict
            && meta.length_name_configurable
            && matches!(
                meta.class_element_execution_kind,
                scriptw_ir::ClassElementExecutionKind::None
            )
            && matches!(
                meta.class_heritage_kind,
                scriptw_ir::ClassHeritageKind::None
            )
            && !meta.is_named_expression
            && !meta.is_static_class_member
            && !meta.is_derived_constructor
            && !meta.is_synthetic_default_derived_constructor
            && !meta.uses_super
            && !meta.this_before_super
            && !meta.captures_private_environment
            && !meta.needs_active_function_identity
            && meta.class_instance_element_plan.is_none()
            && meta.template_source.is_none()
            && meta.constant_leaf.is_none()
            && meta.numeric_leaf.is_none()
            && meta.async_generator_resume_environment_plan.is_none();
        if !valid {
            return Err(EmitError::unsupported(format!(
                "deferred intrinsic {} metadata is outside the ordinary strict nonconstructor construction domain",
                method.0.debug_name()
            )));
        }
        Ok(Self { method, meta })
    }
}

/// Selection leaves contain typed callable references and scalar metadata only.
/// No GC allocation or pooled-string resolution precedes the shared tail.
/// Every invalid ID traps in the exact-identity decision tree.
pub(super) struct Selection {
    code: DeferredBuiltinCodeSelection,
    name: I32Local,
    source: I32Local,
    length: I64Local,
}
impl Selection {
    fn reserve(s: &RuntimeSchema, f: &mut Function) -> Self {
        Self {
            code: DeferredBuiltinCodeSelection::reserve(s, f),
            name: s.reserve_i32_local(f),
            source: s.reserve_i32_local(f),
            length: s.reserve_i64_local(f),
        }
    }
    fn release(self, s: &RuntimeSchema, f: &mut Function) {
        s.release_i32_local(self.source, f);
        s.release_i32_local(self.name, f);
        self.code.release(s, f);
        s.release_i64_local(self.length, f);
    }
}
/// Produced only after the complete exact-ID tree has been emitted. The
/// construction tail cannot accept pending, merely reserved selection locals.
pub(super) struct SelectedMethod(Selection);
impl SelectedMethod {
    pub(super) fn release(self, s: &RuntimeSchema, f: &mut Function) {
        self.0.release(s, f);
    }
}

impl FunctionBuilder<'_> {
    pub(super) fn emit_deferred_method_selection(
        &mut self,
        methods: &[MethodPlan],
        builtin: I32Local,
        f: &mut Function,
    ) -> Result<SelectedMethod, EmitError> {
        let selected = Selection::reserve(self.runtime_schema(), f);
        self.emit_deferred_intrinsic_dispatch(methods, builtin, &selected, f)?;
        Ok(SelectedMethod(selected))
    }

    pub(super) fn emit_select_deferred_method(
        &mut self,
        plan: &MethodPlan,
        selected: &Selection,
        f: &mut Function,
    ) -> Result<(), EmitError> {
        let s = self.runtime_schema();
        // Validate both strings as compiler-owned R literals before selecting
        // their ordinals. A source-program literal cannot enter this R-only tail.
        let runtime_ordinal = |text: &str| -> Result<i32, EmitError> {
            let index = self.strings.pooled_string_index(text)?;
            match self.strings.pooled_string_domain(index)? {
                crate::data::PooledLiteralDomain::Runtime(index) => Ok(index.ordinal() as i32),
                crate::data::PooledLiteralDomain::Program(_) => Err(EmitError::unsupported(
                    "deferred method metadata must belong to the runtime string pool",
                )),
            }
        };
        let name = runtime_ordinal(plan.meta.runtime_name())?;
        let source = runtime_ordinal(&plan.meta.to_string_value)?;
        selected.code.select(&plan.meta.entry, s, f)?;
        selected.name.set_constant(name, f);
        selected.source.set_constant(source, f);
        f.instruction(&Instruction::I64Const(
            (plan.meta.length as f64).to_bits() as i64
        ));
        selected.length.store(f);
        Ok(())
    }

    pub(super) fn emit_materialize_selected_method(
        &mut self,
        selected: &SelectedMethod,
        realm: &crate::functions::RealmFunctionMaterializationContext,
        f: &mut Function,
    ) -> Result<GcStackReference<FunctionObject>, EmitError> {
        let selected = &selected.0;
        let s = self.runtime_schema();
        // Preserve the original allocation order: code record, name string,
        // source string, then the existing function/header/context tail. Keep
        // each preceding reference independently rooted across later allocation.
        let code = s
            .reserve_gc_local(f)
            .initialize(selected.code.publish(s, f), f);
        let name = s.reserve_gc_local(f).initialize(
            s.resolve_pooled_string_reference(selected.name, self.runtime_helper_base()?, f),
            f,
        );
        let source = s.reserve_gc_local(f).initialize(
            s.resolve_pooled_string_reference(selected.source, self.runtime_helper_base()?, f),
            f,
        );
        let prototype = s.reserve_value_local(f);
        prototype.set_reference(realm.function_prototype(), s, f);
        let yes = s.reserve_i32_local(f);
        yes.set_constant(1, f);
        let no = s.reserve_i32_local(f);
        no.set_constant(0, f);
        let object = s.reserve_gc_local(f).initialize(
            s.helper_reference_on_stack(s.call_helper(
                crate::runtime_helpers::NativeFunctionAllocateArguments::new(
                    &prototype,
                    &name,
                    selected.length,
                    yes,
                ),
                self.runtime_helper_base()?,
                f,
            )),
            f,
        );
        let undefined = s.reserve_gc_local(f).initialize(s.stored_undefined(f), f);
        let context = s.reserve_gc_local(f).initialize(
            s.struct_type::<FunctionContext>().construct(
                (
                    GcOperand::reference(realm.realm(), s),
                    GcOperand::null(s),
                    GcOperand::null(s),
                    GcOperand::null(s),
                    GcOperand::reference(&undefined, s),
                    GcOperand::null(s),
                    GcOperand::null(s),
                    GcOperand::null(s),
                    GcOperand::null(s),
                    GcOperand::null(s),
                    GcOperand::null_function(),
                ),
                f,
            ),
            f,
        );
        let callable = s.reserve_gc_local(f).initialize(
            s.struct_type::<FunctionObject>().construct(
                (
                    GcOperand::reference(&object, s),
                    GcOperand::reference(&code, s),
                    GcOperand::reference(&context, s),
                    GcOperand::reference(&source, s),
                    GcOperand::reference(&undefined, s),
                    GcOperand::boolean(true),
                    GcOperand::constant(scriptw_ir::ClassHeritageKind::None),
                    GcOperand::boolean(false),
                    GcOperand::boolean(false),
                    GcOperand::boolean(false),
                    GcOperand::boolean(false),
                    GcOperand::boolean(false),
                    GcOperand::constant(None::<crate::module::TypedArrayElementKind>),
                    GcOperand::null(s),
                    GcOperand::null(s),
                ),
                f,
            ),
            f,
        );
        // Close the same sole allocation cycle before metadata or cache publication.
        s.field(FunctionContextSchema::ACTIVE_FUNCTION).write(
            &context,
            GcOperand::nullable_reference(&callable, s),
            s,
            f,
        );
        let parent = s.reserve_value_local(f);
        parent.set_undefined(f);
        s.call_helper(
            crate::runtime_helpers::FunctionMetadataPublishArguments::new(
                &callable,
                selected.length,
                &name,
                yes,
                no,
                no,
                yes,
                &parent,
            ),
            self.runtime_helper_base()?,
            f,
        );
        parent.clear(f);
        undefined.clear(f);
        context.clear(f);
        object.clear(f);
        prototype.clear(f);
        source.clear(f);
        name.clear(f);
        code.clear(f);
        s.release_i32_local(no, f);
        s.release_i32_local(yes, f);
        let result = callable.load(s, f);
        callable.clear(f);
        Ok(result)
    }
}

#[cfg(test)]
mod tests;
