"""Fresh sequential excluded diagnostics; invoke inside limited_verification.py."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/rsc-property-kernels-20261107'
TOOLS = ROOT / 'target/rsc-attribution-20261107/tools'
OUTPUT = Path(__file__).resolve().parent / 'results'
SOURCE = BASE / 'tools/source-corrected-5/manifest.json'
CAMPAIGN = BASE / 'tools/rsc-campaign-1/campaign.json'
FINGERPRINT = '5aa48ad8a545934f090cc46c13e18d6e56ac76098bbfe8e0a56eb345b9677044'
sys.path.insert(0, str(ROOT / 'scripts'))
sys.path.insert(0, str(BASE / 'tools'))
from limited_verification import limited_environment, require_kernel_budget
from common import check_source
from measure_rsc import resources, check_resources


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    check_source(SOURCE)
    campaign = load(CAMPAIGN)
    assert campaign['status'] == 'complete'
    assert sha(SOURCE) == campaign['source_manifest_sha256']
    first = next(row for row in campaign['processes']
                 if row['engine'] == 'candidate' and row['status'] == 'complete')
    old_binary = Path(campaign['baseline']['path'])
    new_binary = Path(campaign['candidate']['path'])
    old_reference = Path(campaign['baseline']['report'])
    new_reference = CAMPAIGN.parent / first['report']
    node = Path(campaign['node']['path'])
    assert sha(old_binary) == campaign['baseline']['sha256']
    assert sha(new_binary) == campaign['candidate']['sha256']
    assert sha(new_reference) == first['report_sha256']
    assert sha(node) == campaign['node']['sha256']
    old, new = load(old_reference), load(new_reference)
    assert old['source_fingerprint'].startswith('0ca455c')
    assert new['source_fingerprint'] == FINGERPRINT
    assert first['identity']['source_fingerprint'] == FINGERPRINT
    assert old['executable_sha256'] == sha(old_binary)
    assert new['executable_sha256'] == sha(new_binary)
    assert old['inputs'] == new['inputs'], 'Node and both hosts must use identical inputs'

    paths = {Path(__file__), SOURCE, SOURCE.parent / 'tracked.patch', CAMPAIGN,
             CAMPAIGN.parent / 'aggregate.json', old_binary, new_binary, old_reference,
             new_reference, node, Path(campaign['baseline']['producer']),
             Path(campaign['candidate']['cargo_producer']), BASE / 'candidate-reuse.json',
             ROOT / 'scripts/limited_verification.py',
             BASE / 'tools/common.py', BASE / 'tools/measure_rsc.py'}
    paths.update(path for path in TOOLS.iterdir() if path.is_file()
                 and path.suffix in ('.py', '.json', '.cjs'))
    for report in (old, new):
        paths.update(Path(report['inputs'][name]) for name in ('source', 'support'))
    probe = load(TOOLS / 'perf-probe.json')
    paths.add(ROOT / probe['unpacked_executable'])
    paths.update(path for path in (ROOT / probe['unpacked_libdir']).glob('*.so*') if path.is_file())
    original = ROOT / 'target/performance-v8-climb-20261104/entry-breakpoints-staged'
    paths.update(original / name for name in ('prepared.json', 'control-producer.json',
                 'controls', 'controls.rs', 'count_entries.py', 'build_controls.py'))
    pins = {str(path.resolve(strict=True)): sha(path) for path in sorted(paths)}
    OUTPUT.mkdir(exist_ok=False)
    report = {'schema': 'scriptw-rsc-property-diagnostics-v1', 'complete': False,
              'status': 'running', 'excluded_from_scored_cohorts': True,
              'source_fingerprint': FINGERPRINT, 'pins': pins,
              'old_reference': str(old_reference), 'new_reference': str(new_reference),
              'affinity': sorted(os.sched_getaffinity(0)), 'resources_before': resources(),
              'new_speed_policy': 'Excluded combined Cranelift OptLevel::Speed + RegallocAlgorithm::Backtracking diagnostic on the identical new source and R; only native P compilation policy changes. No default-policy or scored-timing change.',
              'runs': [], 'limits': 'Unscored caller/main-thread diagnostics including control edges. '
              'PMU summaries use raw kernel counts only and require no multiplexing. '
              'FP and hardware-entry instrumentation perturb execution; their timings are never scores. '
              'Inclusive categories and entries overlap; no category attribution is computed here.'}

    def save():
        (OUTPUT / 'campaign.json').write_text(json.dumps(report, indent=2) + '\n')

    def check_pins():
        check_source(SOURCE)
        for path, expected in pins.items():
            assert sha(path) == expected, 'changed diagnostic input: ' + path

    def run(kind, name, argv, **metadata):
        row = dict(kind=kind, name=name, argv=argv, status='running', **metadata)
        report['runs'].append(row)
        save()
        started = time.monotonic_ns()
        print('START', name, flush=True)
        try:
            check_pins()
            row['resources_before'] = resources()
            with (OUTPUT / (name + '.stdout')).open('xb') as out, \
                 (OUTPUT / (name + '.stderr')).open('xb') as err:
                child = subprocess.run(argv, cwd=ROOT, env=limited_environment(),
                                       stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=650)
            row['exit_code'] = child.returncode
            assert child.returncode == 0, name
            receipt_path = OUTPUT / name / 'receipt.json'
            receipt = load(receipt_path)
            assert receipt['status'] in ('complete', 'captured'), name
            row['receipt_sha256'] = sha(receipt_path)
            if kind == 'pmu':
                windows = receipt['windows']
                assert len(windows) == 100
                assert all(w['time_enabled_ns'] == w['time_running_ns'] > 0 for w in windows)
                row['raw_kernel_median_counts'] = {
                    event: statistics.median(w['raw_counts'][event] for w in windows)
                    for event in windows[0]['raw_counts']}
            if kind == 'control':
                assert receipt['complete'] and receipt['known_count_windows'] == 8
            if kind == 'entries':
                assert receipt['complete'] and len(receipt['windows']) == 7
                row['median_entry_counts'] = {
                    target: statistics.median(w['events'][index]['count'] for w in receipt['windows'])
                    for index, target in enumerate(receipt['targets'])}
            row['status'] = 'complete'
        except BaseException as error:
            row['status'] = 'failed'
            row['error'] = repr(error)
            raise
        finally:
            row['elapsed_ns'] = time.monotonic_ns() - started
            row.setdefault('resources_after', resources())
            try:
                check_pins()
                if 'resources_before' in row:
                    check_resources(row['resources_before'], row['resources_after'])
                row['inputs_and_resources_verified_after'] = True
            except BaseException as error:
                row['status'] = 'failed'
                row['after_verification_error'] = repr(error)
                save()
                raise
            finally:
                receipt_path = OUTPUT / name / 'receipt.json'
                if receipt_path.exists():
                    row['receipt_sha256'] = sha(receipt_path)
                    pins[str(receipt_path)] = row['receipt_sha256']
                observations = OUTPUT / name / 'observations.json'
                if observations.exists():
                    pins[str(observations)] = sha(observations)
                save()
            for suffix in ('stdout', 'stderr'):
                path = OUTPUT / (name + '.' + suffix)
                if path.exists():
                    row[suffix + '_sha256'] = sha(path)
            save()
        print('END', name, flush=True)

    save()
    try:
        for repetition in range(3):
            actors = ['old', 'new', 'new-speed', 'node']
            actors = actors[repetition:] + actors[:repetition]
            for mode in ('sync', 'async'):
                for actor in actors:
                    binary, reference = old_binary, old_reference
                    if actor in ('new', 'new-speed'):
                        binary, reference = new_binary, new_reference
                    name = f'pmu-{actor}-{mode}-{repetition}'
                    engine = 'scriptw'
                    if actor == 'node':
                        engine = 'node'
                    argv = [sys.executable, '-B', str(TOOLS / 'count_request_pmu.py'), str(OUTPUT / name),
                            '--engine', engine, '--mode', mode, '--binary', str(binary), '--node', str(node),
                            '--baseline-json', str(reference), '--samples', '100', '--warmups', '3']
                    if actor == 'new-speed':
                        argv += ['--native-mode', 'speed']
                    run('pmu', name, argv, actor=actor, mode=mode, repetition=repetition)
        report['pmu_raw_kernel_process_medians'] = {
            mode: {actor: {event: statistics.median(
                row['raw_kernel_median_counts'][event] for row in report['runs']
                if row['kind'] == 'pmu' and row['mode'] == mode and row['actor'] == actor)
                for event in ('cycles:u', 'instructions:u', 'branches:u', 'branch-misses:u')}
                for actor in ('old', 'new', 'new-speed', 'node')} for mode in ('sync', 'async')}
        save()
        for repetition in range(3):
            for mode in ('sync', 'async'):
                name = f'fp-new-{mode}-{repetition}'
                run('fp', name, [sys.executable, '-B', str(TOOLS / 'profile_rsc_fp.py'), str(new_binary),
                    str(OUTPUT / name), '--mode', mode, '--samples', '200', '--warmups', '3',
                    '--baseline-json', str(new_reference)], mode=mode, repetition=repetition)
        name = 'entry-controls'
        control = [sys.executable, '-B', str(TOOLS / 'count_runtime_entries.py'), '--binary', str(new_binary),
                   '--baseline-json', str(new_reference), '--mode', 'control', '--output', str(OUTPUT / name)]
        run('control', name, control)
        controls = OUTPUT / name / 'receipt.json'
        groups = {
            'reads': ['helper::object_read', 'helper::ordinary_property_find',
                      'helper::ordinary_own_descriptor', 'helper::cached_property_read'],
            'construction': ['helper::ordinary_property_append', 'helper::ordinary_property_storage_ensure',
                             'helper::intrinsic_property_find', 'helper::for_in_advance'],
            'roundtrip': ['helper::ordinary_set_data_on_receiver', 'builtin::Reflect.defineProperty',
                          'helper::object_has_property', 'helper::function_call']}
        pins[str(controls)] = sha(controls)
        for group, targets in groups.items():
            for mode in ('sync', 'async'):
                name = f'entries-{group}-{mode}'
                argv = [sys.executable, '-B', str(TOOLS / 'count_runtime_entries.py'), '--binary', str(new_binary),
                        '--baseline-json', str(new_reference), '--mode', mode, '--samples', '7',
                        '--controls-receipt', str(controls), '--output', str(OUTPUT / name)]
                for target in targets:
                    argv += ['--target', target]
                run('entries', name, argv, mode=mode, group=group)
        check_pins()
        report['resources_after'] = resources()
        check_resources(report['resources_before'], report['resources_after'])
        report.update(complete=True, status='complete')
    except BaseException as error:
        report.update(status='failed', error=repr(error), resources_after=resources())
        raise
    finally:
        save()
    print('DIAGNOSTICS COMPLETE', OUTPUT, flush=True)


if __name__ == '__main__':
    main()
