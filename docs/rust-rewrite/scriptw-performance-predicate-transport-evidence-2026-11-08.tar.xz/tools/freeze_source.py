#!/usr/bin/env python3
"""Freeze the current source base plus its exact dirty batch as ABI 53."""
import argparse
from pathlib import Path

from common import make_manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = make_manifest(args.output)
    print("FROZEN", manifest, flush=True)


if __name__ == "__main__":
    main()
