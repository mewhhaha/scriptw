#!/usr/bin/env python3
"""Stage current RSC/situation reports and a text-only evidence archive."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-predicate-transport-20261108'
ARCHIVER = ROOT / 'target/react-performance-20261103/archive_final.py'
RSC_RENDERER = ROOT / 'scripts/render-application-benchmarks.py'
SITUATION_RENDERER = ROOT / 'scripts/render-situation-benchmarks.py'
sys.path.insert(0, str(ROOT / 'scripts'))
TEXT_SUFFIXES = {'.json', '.jsonl', '.receipt', '.stdout', '.stderr', '.list', '.txt', '.map', '.rs',
                 '.js', '.cjs', '.mjs', '.py', '.md', '.toml', '.patch', '.snap', '.csv', '.svg', '.sh', '.log'}
FORBIDDEN_NAMES = {'perf.data', 'callchains.json'}
FORBIDDEN_SUFFIXES = {'.wasm', '.so', '.a', '.rlib', '.rmeta', '.o', '.dylib', '.dll', '.exe', '.bin', '.xz', '.zst', '.zip'}
INTERNAL_TEST_ONLY_FILE = 'crates/scriptw-aot-wasm/src/tests/local_argument_calls.rs'
MIXED_CFG_TEST_FILE = 'crates/scriptw-aot-wasm/src/functions/numeric_body.rs'
COMPILER_TEST_EXCLUSION_FILE = 'crates/scriptw-engine/compiler_fingerprint.rs'
TEST_MODULE_FILE = 'crates/scriptw-aot-wasm/src/tests.rs'
TEST_GATE_FILE = 'crates/scriptw-aot-wasm/src/lib.rs'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_text_file(path):
    path = Path(path).resolve(strict=True)
    assert path.is_file() and not path.is_symlink(), f'not a regular evidence file: {path}'
    assert path.name not in FORBIDDEN_NAMES and path.suffix.lower() not in FORBIDDEN_SUFFIXES, path
    assert path.suffix.lower() in TEXT_SUFFIXES or path.name in {'stdout', 'stderr'}, (
        f'not an admitted text evidence type: {path}')
    data = path.read_bytes()
    assert b'\0' not in data and data[:4] not in (b'\x7fELF', b'\x00asm'), f'binary evidence rejected: {path}'
    data.decode('utf-8')
    return path


def add_evidence_tree(archive, source, prefix):
    source = Path(source).resolve(strict=True)
    assert source.is_relative_to(ROOT) and source.is_dir() and not source.is_symlink()
    for path in sorted(source.rglob('*')):
        if path.is_dir():
            assert not path.is_symlink(), f'symlink in evidence tree: {path}'
            continue
        if path.name in FORBIDDEN_NAMES or path.suffix.lower() in FORBIDDEN_SUFFIXES:
            continue
        if path.suffix.lower() not in TEXT_SUFFIXES and path.name not in {'stdout', 'stderr'}:
            continue
        path = require_text_file(path)
        member = prefix.rstrip('/') + '/' + path.relative_to(source).as_posix()
        archive.add_file(member, path)


def add_source_snapshot(archive, manifest_path, prefix='source/current'):
    root = Path(manifest_path).parent
    manifest = read(manifest_path)
    listed = manifest['files']
    archive.add_file(prefix + '/manifest.json', require_text_file(manifest_path))
    archive.add_file(prefix + '/tracked.patch', require_text_file(root / 'tracked.patch'))
    archive.add_file(prefix + '/baseline/rsc-current.json',
                     require_text_file(root / 'baseline/rsc-current.json'))
    for relative, record in sorted(listed.items()):
        source = require_text_file(root / 'files' / relative)
        assert sha(source) == record['sha256'], f'frozen source snapshot hash mismatch: {relative}'
        archive.add_file(prefix + '/files/' + relative, source)
    present = {p.relative_to(root / 'files').as_posix() for p in (root / 'files').rglob('*') if p.is_file()}
    assert present == set(listed), 'frozen source snapshot inventory differs from manifest'


def add_rsc_campaign(archive, campaign_path, aggregate_path):
    root = Path(campaign_path).parent
    campaign = read(campaign_path)
    aggregate = read(aggregate_path)
    archive.add_file('rsc/campaign.json', require_text_file(campaign_path))
    archive.add_file('rsc/aggregate.json', require_text_file(aggregate_path))
    for path in sorted((root / 'inputs').rglob('*')):
        if path.is_file():
            source = require_text_file(path)
            archive.add_file('rsc/inputs/' + path.relative_to(root / 'inputs').as_posix(), source)
    for row in campaign['processes']:
        assert row['status'] == 'complete'
        for field in ('report', 'stdout', 'stderr'):
            relative = Path(row[field])
            assert not relative.is_absolute() and '..' not in relative.parts
            source = require_text_file(root / relative)
            assert sha(source) == row[field + '_sha256'], f'campaign {field} hash mismatch: {relative}'
            archive.add_file('rsc/' + relative.as_posix(), source)


def validate_campaign(campaign_path, aggregate_path, manifest_path):
    campaign, aggregate = read(campaign_path), read(aggregate_path)
    manifest = read(manifest_path)
    assert campaign['schema'] == 'scriptw-rsc-levers-campaign-v1'
    assert campaign['status'] == 'complete' and len(campaign['processes']) == 32
    assert aggregate['schema'] == 'scriptw-rsc-levers-aggregate-v1'
    assert aggregate['source_manifest_sha256'] == sha(manifest_path)
    assert campaign['source_manifest_sha256'] == sha(manifest_path)
    assert manifest['base_git'] == 'dfefb3222737b067e1c98777161d95d42491df8f'
    assert manifest['base_runtime_abi'] == manifest['runtime_abi'] == 53
    assert aggregate['runtime_abi'] == 53
    assert aggregate['measurement']['campaign_sha256'] == sha(campaign_path)
    assert aggregate['measurement']['checked_flight_calls'] == 640
    assert aggregate['measurement']['actors'] == ['baseline', 'candidate', 'candidate-speed', 'v8']
    assert campaign['policy']['actors'] == aggregate['measurement']['actors']
    assert campaign['policy']['blocks'] == 2
    assert campaign['policy']['processes_per_actor_per_block'] == 4
    assert campaign['policy']['samples'] == 7 and campaign['policy']['warmups'] == 3
    assert campaign['source_base_git'] == manifest['base_git']
    assert campaign['runtime_abi'] == manifest['runtime_abi'] == 53
    public = read(Path(manifest_path).parent / 'baseline/rsc-current.json')
    assert public['schema'] == 'scriptw-rsc-current-v2'
    published_baseline = public['engines']['candidate']['identity']
    for key in ('source_fingerprint', 'source_commit', 'executable_sha256', 'compiler_identity_scheme',
                'toolchain', 'configuration', 'program_wasm_sha256', 'runtime', 'inputs'):
        assert campaign['baseline']['identity'][key] == published_baseline[key], (
            f'2255 baseline differs from published source2255 identity: {key}'
        )
    assert campaign['baseline']['identity']['source_fingerprint'].startswith('2255a008')
    fast = aggregate['engines']['candidate']['identity']
    assert fast['source_commit'] == manifest['base_git']
    assert campaign['candidate']['compiler_source_identity']['source_revision'].removeprefix('git:') == manifest['base_git']
    for actor in campaign['policy']['actors']:
        rows = [row for row in campaign['processes'] if row['actor'] == actor]
        assert len(rows) == 8 and all(row['status'] == 'complete' for row in rows), actor
        engine = aggregate['engines'][actor]
        assert set(engine['cases']) == {'rsc-sync', 'rsc-async'}
        assert all(len(values) == 8 and all(type(v) is int and v > 0 for v in values)
                   for values in engine['cases'].values())
        if actor != 'v8':
            assert len(engine['phase_processes']) == 8
    fast = aggregate['engines']['candidate']['identity']
    speed = aggregate['engines']['candidate-speed']['identity']
    for key in ('source_fingerprint', 'source_commit', 'executable_sha256', 'program_wasm_sha256',
                'runtime', 'inputs'):
        assert fast[key] == speed[key], f'Fast/Speed identity mismatch: {key}'
    assert fast['configuration']['cranelift_opt_level'] == 'None'
    assert fast['configuration']['register_allocation'] == 'SinglePass'
    assert speed['configuration']['cranelift_opt_level'] == 'Speed'
    assert speed['configuration']['register_allocation'] == 'Backtracking'
    assert campaign['candidate']['sha256'] == fast['executable_sha256']
    assert campaign['candidate']['qualified_reuse'] is None
    assert campaign['candidate']['artifact']['fresh'] is False
    baseline_identity = campaign['baseline']['identity']
    measured_baseline = aggregate['engines']['baseline']['identity']
    for key in ('source_fingerprint', 'source_commit', 'executable_sha256', 'compiler_identity_scheme',
                'toolchain', 'configuration', 'program_wasm_sha256', 'runtime', 'inputs'):
        assert baseline_identity[key] == measured_baseline[key], f'baseline identity mismatch: {key}'
    return campaign, aggregate, manifest


def make_rsc_report(campaign_path, aggregate_path, manifest_path):
    campaign, aggregate, manifest = validate_campaign(campaign_path, aggregate_path, manifest_path)
    template_path = Path(manifest_path).parent / 'baseline/rsc-current.json'
    report = read(template_path)
    assert report['schema'] == 'scriptw-rsc-current-v2'
    report['date'] = aggregate['date']
    report['caveat'] = aggregate['caveat']
    report['source_manifest_sha256'] = sha(manifest_path)
    report['baseline'] = campaign['baseline']
    report['candidate'] = dict(campaign['candidate'])
    report['candidate'].pop('qualified_reuse', None)
    report['candidate_speed'] = {
        'path': campaign['candidate']['path'],
        'sha256': campaign['candidate']['sha256'],
        'cargo_producer': campaign['candidate']['cargo_producer'],
        'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
        'configuration': aggregate['engines']['candidate-speed']['identity']['configuration'],
        'native_mode': 'speed',
        'scope': 'separately scored native compilation policy',
    }
    policy = campaign['policy']
    measurement = copy.deepcopy(aggregate['measurement'])
    measurement.update({
        'processes_per_engine_per_block': policy['processes_per_actor_per_block'],
        'clock': policy['clock'],
        'process_order': policy['process_order'],
        'execution_processes': len(campaign['processes']),
        'exact_output': 'Both RSC cases were checked against the shared Node-generated JSON golden.',
    })
    report['measurement'] = measurement
    report['engines'] = aggregate['engines']
    report['inputs'] = campaign['inputs']
    candidate_source = {
        'source_commit': aggregate['engines']['candidate']['identity']['source_commit'],
        'source_fingerprint': aggregate['engines']['candidate']['identity']['source_fingerprint'],
        'manifest_path': str(Path(manifest_path).relative_to(ROOT)),
        'manifest_sha256': sha(manifest_path),
        'runtime_abi': manifest['runtime_abi'],
        'archive_prefix': 'source/current/',
        'manifest_member': 'source/current/manifest.json',
    }
    report['source_identity'] = {
        'git_revision_role': 'new HEAD with one frozen dirty source batch',
        'baseline_source': {
            'identity': campaign['baseline']['identity'],
            'executable': campaign['baseline']['path'],
            'executable_sha256': campaign['baseline']['sha256'],
            'report': campaign['baseline']['report'],
            'report_sha256': campaign['baseline']['report_sha256'],
            'published_report_sha256': campaign['baseline']['published_report_sha256'],
        },
        'candidate_measured_source': candidate_source,
        'candidate_build': {
            'path': campaign['candidate']['path'],
            'executable_sha256': campaign['candidate']['sha256'],
            'cargo_producer': campaign['candidate']['cargo_producer'],
            'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
            'build_producer_is_direct': True,
            'compiler_source_identity': campaign['candidate']['compiler_source_identity'],
        },
        'candidate_speed_policy': aggregate['engines']['candidate-speed']['identity']['configuration'],
        'runtime_abi': manifest['runtime_abi'],
    }
    report['producer_receipts'] = {
        'baseline': {
            'path': campaign['baseline']['producer'],
            'sha256': campaign['baseline']['producer_sha256'],
        },
        'candidate': {
        'cargo_producer': campaign['candidate']['cargo_producer'],
        'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
            'build_producer_is_direct': True,
        },
        'candidate_speed': {
            'cargo_producer': campaign['candidate']['cargo_producer'],
            'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
            'native_configuration': aggregate['engines']['candidate-speed']['identity']['configuration'],
        },
    }
    report.pop('evidence_archive', None)
    report.pop('complete_archived_report', None)
    report['publication'] = {
        'date': aggregate['date'], 'status': 'staged-ready-for-review',
        'measured_source': candidate_source,
        'baseline': {'identity': campaign['baseline']['identity'],
                     'reference_campaign_sha256': campaign['baseline']['reference_campaign_sha256'],
                     'reference_aggregate_sha256': campaign['baseline']['reference_aggregate_sha256']},
        'speed_policy': campaign['policy']['speed_scope'],
        'archive_prefix': 'source/current/',
    }
    report.pop('baseline_diagnostics', None)
    report.pop('evidence_archive', None)
    report['staging'] = {
        'status': 'ready-for-review', 'canonical_files_written': False,
        'archive_created': False, 'charts_rendered': False,
        'limits': aggregate['caveat'],
    }
    return report, campaign, aggregate


def compact_situations(path, candidate_identity, historical_path, measured_manifest_sha256):
    report = read(path)
    assert report.get('schema') == 'scriptw-situation-benchmarks-v1', (
        'publish the official raw full-21 report directly; wrappers need a separately justified qualification'
    )
    renderer = load_module('scriptw_situation_renderer', SITUATION_RENDERER)
    cases = renderer.validate(report)
    assert report['status'] == 'complete' and len(cases) == 21
    policy = report['policy']
    assert policy['actors'] == ['scriptw-fast', 'scriptw-speed', 'v8']
    assert policy['blocks'] == 2 and policy['processes_per_actor_per_block'] == 4
    assert policy['samples'] == 21 and policy['warmups'] == 100
    identity = report['source_identity']
    assert identity['source_commit'] == candidate_identity['source_commit']
    assert identity['source_fingerprint'] == candidate_identity['source_fingerprint']
    assert report['tools']['host']['sha256']
    historical = read(historical_path)
    old = historical.get('historical_width_identity', {})
    archive = old.get('evidence_archive', historical.get('evidence_archive', {}))
    assert old.get('source_fingerprint', '').startswith('0ca455c')
    assert isinstance(archive.get('sha256'), str) and len(archive['sha256']) == 64
    compact = {key: copy.deepcopy(value) for key, value in report.items()
               if key not in {'rows', 'commands', 'retained_files'}}
    compact.pop('evidence_archive', None)
    compact.pop('complete_archived_report', None)
    compact['historical_width_identity'] = copy.deepcopy(old)
    compact['publication'] = {
        'status': 'staged-ready-for-review',
        'full_report': {'archive_member': 'situations/full-report.json', 'sha256': sha(path)},
        'consumer_processes': len(cases) * 3 * 8,
        'checked_invocations': len(cases) * 3 * 8 * (policy['samples'] + policy['warmups']),
        'source_manifest_sha256': measured_manifest_sha256,
        'canonical_files_written': False,
    }
    return compact, None, Path(path)



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--aggregate', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True,
                        help='single frozen source snapshot for the measured build')
    parser.add_argument('--situations-report', type=Path, required=True,
                        help='official raw full-21 situations report')
    parser.add_argument('--historical-situations', type=Path,
                        default=ROOT / 'docs/rust-rewrite/situations-current.json')
    parser.add_argument('--evidence', type=Path, action='append', default=[],
                        help='actual verification receipt/log text; repeat as needed')
    parser.add_argument('--output-dir', type=Path, required=True,
                        help='new isolated directory under target')
    parser.add_argument('--archive-name', default='scriptw-performance-predicate-transport-evidence-2026-11-08.tar.xz')
    args = parser.parse_args()

    output = args.output_dir.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    campaign_path = args.campaign.resolve(strict=True)
    aggregate_path = args.aggregate.resolve(strict=True)
    manifest_path = args.source_manifest.resolve(strict=True)
    situations_path = args.situations_report.resolve(strict=True)
    rsc, campaign, aggregate = make_rsc_report(campaign_path, aggregate_path, manifest_path)
    situations, _, situations_full_path = compact_situations(
        situations_path, aggregate['engines']['candidate']['identity'],
        args.historical_situations.resolve(strict=True), sha(manifest_path))

    chart_module = load_module('scriptw_rsc_renderer', RSC_RENDERER)
    with tempfile.TemporaryDirectory(prefix='rsc-v2-', dir=BASE) as temporary_dir:
        temporary = Path(temporary_dir) / 'report.json'
        temporary.write_bytes(encoded(rsc))
        chart_module.rsc_report(temporary)

    output.mkdir(parents=True)
    (output / 'reports').mkdir()
    (output / 'reports/rsc-current.json').write_bytes(encoded(rsc))
    (output / 'reports/situations-current.json').write_bytes(encoded(situations))

    archiver = load_module('scriptw_inert_archive', ARCHIVER)
    archive = archiver.Archive()
    add_source_snapshot(archive, manifest_path)
    add_rsc_campaign(archive, campaign_path, aggregate_path)
    archive.add_file('reports/rsc-current-prearchive.json', output / 'reports/rsc-current.json')
    archive.add_file('reports/situations-current-prearchive.json', output / 'reports/situations-current.json')
    archive.add_file('situations/full-report.json', situations_full_path)
    archive.add_file('inputs/baseline-public-report.json', manifest_path.parent / 'baseline/rsc-current.json')
    archive.add_file('tools/stage_publication.py', Path(__file__).resolve())
    archive.add_file('tools/stage_docs.py', Path(__file__).with_name('stage_docs.py').resolve())
    archive.add_file('tools/common.py', BASE / 'tools/common.py')
    archive.add_file('tools/freeze_source.py', BASE / 'tools/freeze_source.py')
    archive.add_file('tools/measure_rsc.py', BASE / 'tools/measure_rsc.py')
    archive.add_file('tools/benchmark-situations.py', ROOT / 'scripts/benchmark-situations.py')
    archive.add_file('tools/benchmark_metrics.py', ROOT / 'scripts/benchmark_metrics.py')
    archive.add_file('tools/limited_verification.py', ROOT / 'scripts/limited_verification.py')
    archive.add_file('tools/archive_final.py', ARCHIVER)
    archive.add_file('tools/render-application-benchmarks.py', RSC_RENDERER)
    archive.add_file('tools/render-situation-benchmarks.py', SITUATION_RENDERER)
    historical_attribution_path = ROOT / 'docs/rust-rewrite/react-attribution-current.json'
    historical_attribution = read(historical_attribution_path)
    assert historical_attribution['schema'] == 'scriptw-react-attribution-current-v5'
    assert historical_attribution['sampling']['historical']['source_fingerprint'].startswith('5aa48ad8')
    archive.add_file('historical-attribution/react-attribution-current.json', historical_attribution_path)
    historical_diagnostics = ROOT / 'target/rsc-property-kernels-20261107/diagnostics'
    add_evidence_tree(archive, historical_diagnostics, 'historical-attribution/diagnostics')
    for index, path in enumerate(args.evidence):
        path = path.resolve(strict=True)
        if path.is_dir():
            add_evidence_tree(archive, path, f'verification/{index:02}-{path.name}')
        else:
            archive.add_file(f'verification/{index:02}-{path.name}/{require_text_file(path).name}', path)
    archive.add_bytes('README.txt', (
        'Scriptw predicate and number-domain performance evidence. Members are inert UTF-8 text with a SHA-256 index. '
        'Executables, Wasm payloads, native libraries, perf.data, and binary artifacts are excluded. '
        'The archive contains one measured source snapshot, 32 RSC processes and 640 exact-checked Flight calls, '
        'plus the full 21-workload situation report: 504 processes and 60,984 checked invocations. '
        'The RSC baseline is the independently measured source2255 binary; the candidate is a direct build from '
        'the single frozen current-source snapshot. Test262 and universal-performance claims are not implied. '
        'Historical attribution remains bound to its original source identity.\n'
    ).encode())
    archive_path = output / args.archive_name
    raw_archive_meta = archive.write(archive_path)
    archive_meta = {key: value for key, value in raw_archive_meta.items() if key != 'file'}
    archive_meta.update({'file': args.archive_name,
                         'canonical_file': 'docs/rust-rewrite/' + args.archive_name,
                         'staged_file': str(archive_path.relative_to(ROOT))})
    import tarfile
    with tarfile.open(archive_path, 'r:xz') as packed:
        index = json.load(packed.extractfile('INDEX.json'))
    member_hashes = {item['path']: item['sha256'] for item in index['members']}

    reports = {'rsc-current.json': rsc, 'situations-current.json': situations}
    for name, value in reports.items():
        value['evidence_archive'] = archive_meta
        value.setdefault('publication', {})['evidence_archive'] = archive_meta
        member = 'reports/' + name.removesuffix('.json') + '-prearchive.json'
        value['complete_archived_report'] = {'archive_member': member,
                                             'sha256': member_hashes[member]}
        value['staging'] = {'status': 'ready-for-review', 'canonical_files_written': False,
                            'evidence_archive_created': True, 'charts_rendered': False}
        (output / 'reports' / name).write_bytes(encoded(value))

    ready = {
        'schema': 'scriptw-performance-predicate-transport-publication-stage-v1',
        'complete': True, 'canonical_files_written': False, 'charts_rendered': False,
        'source_manifest': {'path': str(manifest_path.relative_to(ROOT)), 'sha256': sha(manifest_path),
                            'base_git': read(manifest_path)['base_git'],
                            'runtime_abi': read(manifest_path)['runtime_abi']},
        'campaign_sha256': sha(campaign_path), 'aggregate_sha256': sha(aggregate_path),
        'reports': {name: sha(output / 'reports' / name) for name in reports},
        'situation_report_sha256': sha(situations_path), 'evidence_archive': archive_meta,
        'evidence_members': len(member_hashes),
        'limits': 'Staged only; source2255 baseline identity is historical and separate from the current-source build.',
    }
    (output / 'publication-ready.json').write_bytes(encoded(ready))
    print(output / 'publication-ready.json')


if __name__ == '__main__':
    main()
