#!/usr/bin/env python3
"""Prepare review-only README, benchmark details, and current-work drafts."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import statistics
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-predicate-transport-20261108'
RSC_RENDERER = ROOT / 'scripts/render-application-benchmarks.py'
SITUATION_RENDERER = ROOT / 'scripts/render-situation-benchmarks.py'
sys.path.insert(0, str(ROOT / 'scripts'))


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_rsc(path):
    report = read(path)
    renderer = load_module('stage_docs_rsc_renderer', RSC_RENDERER)
    with tempfile.TemporaryDirectory(prefix='docs-rsc-', dir=BASE) as directory:
        temporary = Path(directory) / 'rsc-current.json'
        temporary.write_text(json.dumps(report, allow_nan=False))
        renderer.rsc_report(temporary)
    identity = report['engines']['candidate']['identity']
    assert report['schema'] == 'scriptw-rsc-current-v2'
    assert report['source_identity']['runtime_abi'] == 53
    assert identity['source_fingerprint'] == report['source_identity']['candidate_measured_source']['source_fingerprint']
    return report


def verify_situations(path, rsc):
    report = read(path)
    assert report.get('schema') == 'scriptw-situation-benchmarks-v1', 'raw official report required'
    renderer = load_module('stage_docs_situation_renderer', SITUATION_RENDERER)
    cases = renderer.validate(report)
    assert report['status'] == 'complete' and len(cases) == 21
    assert report['policy']['actors'] == ['scriptw-fast', 'scriptw-speed', 'v8']
    assert report['policy']['blocks'] == 2 and report['policy']['processes_per_actor_per_block'] == 4
    assert report['policy']['samples'] == 21 and report['policy']['warmups'] == 100
    candidate = rsc['engines']['candidate']['identity']
    assert report['source_identity']['source_commit'] == candidate['source_commit']
    assert report['source_identity']['source_fingerprint'] == candidate['source_fingerprint']
    return report, cases, None


def coverage_text(path, rsc, situations, cases):
    summary = read(path)
    assert summary['schema'] == 'scriptw-performance-predicate-transport-coverage-v1'
    assert re.fullmatch(r'\d{4}-\d{2}-\d{2}', summary['date'])
    assert summary['source_fingerprint'] == rsc['engines']['candidate']['identity']['source_fingerprint']
    scopes = summary['scopes']
    for name in ('broad', 'source_guards', 'production_cli'):
        assert name in scopes
    broad, guards, cli = scopes['broad'], scopes['source_guards'], scopes['production_cli']
    assert type(guards['passed']) is int and guards['passed'] > 0
    assert summary.get('private_unit_suites_rerun') is False
    assert summary.get('full_workspace_ci_rerun') is False
    assert summary.get('full_test262_rerun') is False
    names = broad.get('scope_names')
    assert isinstance(names, list) and names and all(isinstance(name, str) for name in names)
    assert len(names) == broad['scopes']
    situation_calls = len(cases) * 3 * 8 * (situations['policy']['samples'] + situations['policy']['warmups'])
    rsc_calls = rsc['measurement']['checked_flight_calls']
    assert situation_calls == 60984 and rsc_calls == 640
    assert guards['passed'] == 380 and cli['passed'] == 9
    assert type(broad['passed']) is int and broad['passed'] > 0
    return (
        f"Scoped verification (**{summary['date']}**, source `{summary['source_fingerprint'][:12]}`): "
        f"{broad['passed']:,} broad checks, {guards['passed']} source guards, and {cli['passed']} CLI smokes pass. "
        "Full CI, Test262, and private units were not rerun; existing format, Intl, and four AOT failures remain owned."
    )


def ms(value):
    return f'{value / 1_000_000:.3f}'


def cohort_date(report):
    date = report.get('date')
    if date:
        return date
    finished = report.get('finished_at') or report.get('started_at')
    assert isinstance(finished, str) and re.match(r'\d{4}-\d{2}-\d{2}', finished)
    return finished[:10]


def stats(engine, case):
    values = engine['cases'][case]
    return f'{ms(statistics.median(values))} ({ms(min(values))}–{ms(max(values))})'


def rsc_markdown(report, attribution_path):
    fingerprint = report['engines']['candidate']['identity']['source_fingerprint']
    source_commit = report['engines']['candidate']['identity']['source_commit']
    date = report['date']
    engines = report['engines']
    assert engines['candidate']['identity']['program_wasm_sha256'] == engines['candidate-speed']['identity']['program_wasm_sha256']
    assert engines['candidate']['identity']['runtime'] == engines['candidate-speed']['identity']['runtime']
    lines = [
        '## React Server Components', '',
        f'Measured **{date}**, React **19.3.1**, source fingerprint `{fingerprint[:12]}`. '
        f'The manifest-bound dirty source snapshot is based on Git `{source_commit[:12]}`; that base commit alone '
        'does not identify the measured implementation. Both Flight outputs match Node exactly. The 32-row catalog '
        'async form adds a resolved Promise and extra markup; neither request performs I/O.', '',
        '| Current policy | Sync · ms (median; min–max) | Async · ms (median; min–max) |',
        '| --- | ---: | ---: |',
    ]
    for name, label in (('candidate', 'Scriptw Fast'), ('candidate-speed', 'Scriptw Speed'), ('v8', 'Node 24 / V8')):
        lines.append(f'| {label} | {stats(engines[name], "rsc-sync")} | {stats(engines[name], "rsc-async")} |')
    measurement = report['measurement']
    lines.extend([
        '', '![Current RSC request timings](assets/rsc-current/runtime.svg)', '',
        f"The campaign uses {measurement['processes_per_engine']} fresh processes per policy in "
        f"{measurement['blocks']} balanced blocks, with {measurement['warmups']} warmups and "
        f"{measurement['samples']} timed requests per mode. It records {measurement['checked_flight_calls']} "
        'exact-checked Flight calls. Each process retains one Module/Realm; setup precedes the request window, '
        'while JSON encoding and exact-output validation follow it. Rows show medians of process medians, with '
        'process-median bounds. The chart contains current Fast, Speed and V8 only; the published baseline remains '
        'a separately identified raw control.', '',
        'Fast and Speed are separately scored native compilation policies. Their source, executable, P, R and '
        'request inputs match; Cranelift optimization and register allocation differ together.', '',
        '| Cold phase · median | Fast | Speed |', '| --- | ---: | ---: |',
    ])
    for field, label, scale in (
        ('front_and_lower', 'Front end and lowering · s', 1_000_000_000),
        ('wasm_emission', 'Wasm emission · s', 1_000_000_000),
        ('native_preparation', 'Native preparation · s', 1_000_000_000),
        ('source_to_wasm', 'Source to Wasm · s', 1_000_000_000),
        ('realm_and_instantiation', 'Realm and instantiation · ms', 1_000_000),
        ('module_initialization', 'Module initialization · ms', 1_000_000),
    ):
        cells = []
        for name in ('candidate', 'candidate-speed'):
            phases = [process[field] for process in engines[name]['phase_processes'] if field in process]
            cells.append(f'{statistics.median(phases) / scale:.3f}')
        lines.append(f'| {label} | {cells[0]} | {cells[1]} |')
    fast_id = engines['candidate']['identity']
    speed_id = engines['candidate-speed']['identity']
    runtime_bytes = fast_id['runtime']['wasm_bytes']
    program_bytes = fast_id['program_wasm_bytes']
    assert speed_id['program_wasm_bytes'] == program_bytes and speed_id['runtime']['wasm_bytes'] == runtime_bytes
    lines.extend([
        '', '![RSC cold compilation phases](assets/rsc-current/compilation.svg)', '',
        f"The emitted program P is {program_bytes:,} bytes (SHA-256 `{fast_id['program_wasm_sha256']}`). "
        f"Packaged runtime R is {runtime_bytes:,} bytes (SHA-256 `{fast_id['runtime']['wasm_sha256']}`). "
        'These are artifact sizes, not allocation or resident-memory measurements. Exact executable and producer '
        'identities are in [the current report](rsc-current.json).', '',
        '### RSC profiling evidence', '',
    ])
    if attribution_path is not None:
        attribution = read(attribution_path)
        assert attribution['source_fingerprint'] == fingerprint
        assert isinstance(attribution['markdown'], str) and attribution['markdown'].strip()
        lines.extend([attribution['markdown'].strip(), ''])
    else:
        lines.extend([
            'No current-source function-entry or PMU attribution accompanies this timing cohort. The earlier '
            '[React attribution report](react-attribution-current.json) and [its raw evidence archive]'
            '(scriptw-property-kernels-evidence-2026-11-07.tar.xz) identify source fingerprint '
            '`5aa48ad8a545`; their counts and sampled functions remain historical and do not describe this source.',
            '',
        ])
    return '\n'.join(lines) + '\n'


def readme_rsc(report, situations):
    engines = report['engines']
    fingerprint = engines['candidate']['identity']['source_fingerprint']
    measurement = report['measurement']
    lines = [
        f"**React 19.3.1 RSC · {report['date']}**, source `{fingerprint[:12]}`; exact Flight output.", '',
        '| Retained request | Scriptw Fast | Scriptw Speed | Node 24 / V8 |',
        '| --- | ---: | ---: | ---: |',
    ]
    for case, label in (('rsc-sync', 'Sync'), ('rsc-async', 'Async')):
        values = [f"{statistics.median(engines[name]['cases'][case]) / 1e6:.3f} ms"
                  for name in ('candidate', 'candidate-speed', 'v8')]
        lines.append(f'| {label} | {values[0]} | {values[1]} | {values[2]} |')
    lines.extend([
        '', '![Retained RSC requests](docs/rust-rewrite/assets/rsc-current/runtime.svg)', '',
        f"Eight fresh processes per policy in two balanced blocks; {measurement['warmups']} warmups and "
        f"{measurement['samples']} timed requests per mode. Full Flight serialization and consumption are timed; "
        'setup precedes the window, and JSON encoding and final output validation follow it. Fast and Speed are '
        'separately scored native policies; their optimization and register-allocation settings differ together. '
        'The async catalog adds a resolved Promise and markup and performs no I/O. [Phases, workload bounds and '
        'limits](docs/rust-rewrite/benchmarks.md#react-server-components) · '
        '[RSC identities](docs/rust-rewrite/rsc-current.json).', '',
        f"**Focused performance situations · {cohort_date(situations)}**, source `{fingerprint[:12]}`: 21 standalone programs "
        'compare Fast, Speed and V8; no before/after panel. ',
        '[Scores and workload bounds](docs/rust-rewrite/benchmarks.md#focused-performance-situations) · '
        '[Situation data](docs/rust-rewrite/situations-current.json) · '
        '[RSC data](docs/rust-rewrite/rsc-current.json).', '',
    ])
    return '\n'.join(lines)


def frame_image_table(report):
    found = {}
    for preparation in report.get('preparations', []):
        actor = preparation.get('actor')
        if actor not in ('scriptw-fast', 'scriptw-speed'):
            continue
        for case in preparation.get('cases', []):
            name = case.get('file')
            if name not in {'frame-compact.js', 'frame-branches32.js', 'frame-branches128.js', 'frame-branches512.js'}:
                continue
            if case.get('status', 'ok') != 'ok':
                continue
            found.setdefault(name, {})[actor] = case
    names = ('frame-compact.js', 'frame-branches32.js', 'frame-branches128.js', 'frame-branches512.js')
    assert all(name in found and {'scriptw-fast', 'scriptw-speed'} <= found[name].keys() for name in names), (
        'fresh situation report is missing paired Fast/Speed native image records')
    lines = [
        '', '### Native program image sizes', '',
        '| Retained program | Fast native P · KiB | Speed native P · KiB | Portable Wasm P · KiB |',
        '| --- | ---: | ---: | ---: |',
    ]
    for name in names:
        fast = found[name]['scriptw-fast']
        speed = found[name]['scriptw-speed']
        assert type(fast['native_serialized_bytes']) is int and fast['native_serialized_bytes'] > 0
        assert type(speed['native_serialized_bytes']) is int and speed['native_serialized_bytes'] > 0
        assert type(fast['program_wasm_bytes']) is int and fast['program_wasm_bytes'] > 0
        lines.append(
            f"| `{name}` | {fast['native_serialized_bytes'] / 1024:.1f} | "
            f"{speed['native_serialized_bytes'] / 1024:.1f} | {fast['program_wasm_bytes'] / 1024:.1f} |"
        )
    lines.extend(['', 'Native serialized sizes include code metadata and data; they do not measure peak RSS or runtime heap.', ''])
    return '\n'.join(lines)


def situation_markdown(report, cases):
    lines = [
        f"Measured **{cohort_date(report)}** on source `{report['source_identity']['source_fingerprint'][:12]}`. "
        'All 21 programs use two balanced blocks and eight fresh processes per actor. Fast, Speed and V8 are current '
        'policies; this is not a before/after series.', '',
        '| Program · retained call | Fast · ms (median; min–max) | Speed · ms (median; min–max) | V8 · ms (median; min–max) |',
        '| --- | ---: | ---: | ---: |',
    ]
    for case in cases:
        name = case['file']
        runtimes = case['runtimes']
        values = []
        for actor in ('scriptw-fast', 'scriptw-speed', 'v8'):
            result = runtimes[actor]
            assert result['status'] in ('ok', 'complete')
            medians = result['process_medians_ns']
            values.append(f'{statistics.median(medians) / 1e6:.6g} '
                          f'({min(medians) / 1e6:.6g}–{max(medians) / 1e6:.6g})')
        lines.append(f'| `{name}` | {values[0]} | {values[1]} | {values[2]} |')
    lines.extend([
        '', 'All scores time the public retained call after preparation; each program keeps its own workload and '
        'exact-output checks. No workload ratio or blended score is reported. [Full identities and observations]'
        '(situations-current.json).', '',
        '![Current focused situation timings](assets/situations-current/global-lookup.svg)',
    ])
    lines.append(frame_image_table(report))
    return '\n'.join(lines) + '\n'


def replace_between(text, start, end, replacement):
    a = text.index(start)
    b = text.index(end, a)
    return text[:a] + replacement + text[b:]



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rsc-report', type=Path, required=True)
    parser.add_argument('--situations-report', type=Path, required=True)
    parser.add_argument('--coverage-summary', type=Path, required=True,
                        help='actual current batch coverage summary JSON')
    parser.add_argument('--attribution-summary', type=Path,
                        help='optional JSON with matching source_fingerprint and markdown fields')
    parser.add_argument('--output-dir', type=Path, required=True,
                        help='new ignored target directory for review drafts')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    rsc = verify_rsc(args.rsc_report.resolve(strict=True))
    situations, cases, _ = verify_situations(args.situations_report.resolve(strict=True), rsc)
    verification = coverage_text(args.coverage_summary.resolve(strict=True), rsc, situations, cases)
    current_readme = (ROOT / 'README.md').read_text()
    current_benchmarks = (ROOT / 'docs/rust-rewrite/benchmarks.md').read_text()
    current_inventory = (ROOT / 'docs/rust-rewrite/current-inventory.md').read_text()

    readme = replace_between(current_readme, '**React 19.3.1 RSC', '## Current Status',
                             readme_rsc(rsc, situations) + '\n')
    line = next(line for line in readme.splitlines() if line.startswith('Scoped verification ('))
    readme = readme.replace(line, verification)

    rsc_details = rsc_markdown(rsc, args.attribution_summary)
    first_section = current_benchmarks.index('## React Server Components')
    situations_section = current_benchmarks.index('## Focused performance situations', first_section)
    benchmarks = current_benchmarks[:first_section] + rsc_details + '\n' + current_benchmarks[situations_section:]
    start = benchmarks.index('## Focused performance situations')
    stop = benchmarks.index('### Global lookup', start)
    situation_intro = situation_markdown(situations, cases)
    benchmarks = benchmarks[:start] + '## Focused performance situations\n\n' + situation_intro + '\n' + benchmarks[stop:]
    benchmarks = benchmarks.replace(
        'All programs make 8,192 entries and exercise every selected site with matching\n'
        'checksums. Compact dispatch uses one polymorphic site and a dynamic key; switch\n'
        'arms use constant keys and separate sites. This does not isolate stack-probe cost.',
        'These programs execute 8,192 logical source applications across selected sites with matching checksums. '
        'Fast and Speed may fuse admitted calls into the loop body, so logical applications are not a direct-call '
        'count. Compact dispatch uses one polymorphic site and a dynamic key; switch arms use constant keys and '
        'separate sites. This does not isolate stack-probe cost.')
    validation_start = benchmarks.index('### Public-call control and verification')
    validation_end = benchmarks.index('<!-- runtime-comparison-details:start -->', validation_start)
    scopes = read(args.coverage_summary)['scopes']
    scope_names = scopes['broad']['scope_names']
    coverage_paragraph = (
        '### Public-call control and verification\n\n'
        f"The current situation cohort has {len(cases) * 3 * 2 * 4:,} process observations and "
        f"{len(cases) * 3 * 8 * (situations['policy']['samples'] + situations['policy']['warmups']):,} exact calls. "
        f"The current RSC cohort has {rsc['measurement']['execution_processes']:,} processes and "
        f"{rsc['measurement']['checked_flight_calls']:,} exact Flight calls. "
        'The fixed-yield for-in width control remains historical on source `0ca455c47636` and its earlier archive.\n\n'
        + verification.replace('(docs/rust-rewrite/current-inventory.md)', '(current-inventory.md)') + '\n\n'
        + '**Broad native scopes:** ' + ', '.join(scope_names) + '.\n\n'
    )
    benchmarks = benchmarks[:validation_start] + coverage_paragraph + benchmarks[validation_end:]

    inventory = current_inventory
    output.mkdir(parents=True)
    outputs = {'README.md': readme, 'benchmarks.md': benchmarks, 'current-inventory.md': inventory}
    for name, text in outputs.items():
        (output / name).write_text(text)

    # Existing benchmark/Test262 publications remain byte-identical in the drafts.
    def marked(text, marker):
        pattern = re.compile(r'<!-- ' + re.escape(marker) + r':start -->.*?<!-- '
                             + re.escape(marker) + r':end -->', re.S)
        return pattern.search(text).group(0)
    for marker in ('runtime-comparison', 'application-benchmarks', 'scriptw-status', 'scriptw-test-graph'):
        assert marked(readme, marker) == marked(current_readme, marker)
    assert benchmarks[benchmarks.index('<!-- runtime-comparison-details:start -->'):] == \
        current_benchmarks[current_benchmarks.index('<!-- runtime-comparison-details:start -->'):]
    assert inventory[inventory.index('## Conformance boundaries'):] == \
        current_inventory[current_inventory.index('## Conformance boundaries'):]
    receipt = {
        'schema': 'scriptw-performance-predicate-transport-docs-stage-v1', 'complete': True,
        'canonical_files_written': False, 'output_dir': str(output.relative_to(ROOT)),
        'source_fingerprint': rsc['engines']['candidate']['identity']['source_fingerprint'],
        'rsc_report_sha256': sha(args.rsc_report), 'situations_report_sha256': sha(args.situations_report),
        'coverage_summary_sha256': sha(args.coverage_summary),
        'attribution_summary_sha256': sha(args.attribution_summary) if args.attribution_summary else None,
        'situation_qualification': None,
        'reports': {name: hashlib.sha256(text.encode()).hexdigest() for name, text in outputs.items()},
        'preserved': ['README runtime/application/Test262 blocks',
                      'historical 17-kernel and edge benchmark details',
                      'pinned Test262 and conformance history'],
    }
    (output / 'stage.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(output / 'stage.json')


if __name__ == '__main__':
    main()
