#!/usr/bin/env python3
"""Balanced exact-output RSC cohort for frozen ABI-53 property lever source."""
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import shutil
import statistics
import sys

ROOT = Path(__file__).resolve().parents[3]
TOOLS = Path(__file__).resolve().parent
BASE = ROOT / "target/performance-predicate-transport-20261108"
TARGET = BASE / "tools"
BASELINE_HOST = ROOT / "target/performance-levers-20261108/frozen-outlined-1/rsc_baseline"
BASELINE_PRODUCER = ROOT / "target/performance-levers-20261108/frozen-outlined-1/rsc_baseline-producer.json"
REFERENCE_DIR = ROOT / "target/performance-levers-20261108/tools/rsc-campaign-2"
REFERENCE_CAMPAIGN = REFERENCE_DIR / "campaign.json"
REFERENCE_AGGREGATE = REFERENCE_DIR / "aggregate.json"
REFERENCE_PUBLIC = ROOT / "docs/rust-rewrite/rsc-current.json"
REFERENCE_COMMON = ROOT / "target/performance-levers-20261108/tools/common.py"
REFERENCE_REPORT = REFERENCE_DIR / "block-0-rep-0-candidate/report.json"
PUBLIC_REPORT = ROOT / "docs/rust-rewrite/rsc-current.json"
FIXTURES = ROOT / "target/application-benchmarks-20261102/generated-v2"
SOURCE = FIXTURES / "rsc.js"
SUPPORT = FIXTURES / "support.json"
DRIVER = ROOT / "crates/scriptw-cli/tests/fixtures/edge_rendering/react-driver.cjs"
CASES = ("rsc-sync", "rsc-async")
ENGINES = ("baseline", "candidate", "candidate-speed", "v8")
SAMPLES = 7
WARMUPS = 3
PROCESSES_PER_BLOCK = 4
FIELDS = ("memory.max", "memory.swap.max", "memory.oom.group", "cpu.max", "memory.events")

sys.path.insert(0, str(ROOT / "scripts"))
from benchmark_metrics import measure_process
from limited_verification import kernel_group, limited_environment, require_kernel_budget
from common import BASE_RUNTIME_ABI, PINNED_HEAD, RUNTIME_ABI, check_source, digest, git, read, save, validate_snapshot


def resources():
    group = kernel_group()
    return {name: (group / name).read_text().strip() for name in FIELDS}


def check_resources(before, after):
    for name in FIELDS:
        if name != "memory.events":
            assert before[name] == after[name], f"resource policy changed: {name}"
    before_events = dict(line.split() for line in before["memory.events"].splitlines())
    after_events = dict(line.split() for line in after["memory.events"].splitlines())
    for name in ("oom", "oom_kill", "oom_group_kill"):
        assert before_events.get(name) == after_events.get(name), f"OOM event changed: {name}"


def executable(path):
    path = Path(path).resolve(strict=True)
    assert path.is_file() and os.access(path, os.X_OK), f"not executable: {path}"
    return path


def checked_inputs(report, expected):
    actual = report["inputs"]
    for name in ("source_sha256", "support_sha256", "adapted_source_sha256", "wrapper"):
        assert actual[name] == expected[name], f"request input differs: {name}"


def checked_observations(rows):
    assert isinstance(rows, list) and len(rows) == SAMPLES + WARMUPS
    selected = []
    for index, row in enumerate(rows):
        assert row["index"] == index
        assert type(row["warmup"]) is bool and row["warmup"] == (index < WARMUPS)
        assert type(row["elapsed_ns"]) is int and row["elapsed_ns"] > 0
        if not row["warmup"]:
            selected.append(row["elapsed_ns"])
    return int(statistics.median(selected))


def checked_scriptw(report, host, expected_inputs, goldens, native_mode, fast_configuration):
    assert report["schema"] == "scriptw-react-retained-baseline-v1"
    assert report["status"] == "complete" and "profiling" not in report
    assert report["executable_sha256"] == digest(host)
    assert report["native_mode"] == native_mode
    assert report["native_mode_scope"]
    checked_inputs(report, expected_inputs)
    assert [case["case"] for case in report["cases"]] == list(CASES)
    medians = {}
    for case in report["cases"]:
        golden = goldens[case["case"]].removesuffix("\n").encode()
        assert case["samples"] == SAMPLES and case["warmups"] == WARMUPS
        assert case["exact_node_output_checked"] is True
        assert case["expected_json_sha256"] == digest_bytes(golden)
        assert case["expected_json_bytes"] == len(golden)
        median = checked_observations(case["observations"])
        assert case["median_ns"] == median
        medians[case["case"]] = median
    assert report["phases_ns"]["source_to_wasm"] == (
        report["phases_ns"]["front_and_lower"] + report["phases_ns"]["wasm_emission"]
    )
    for name in ("front_and_lower", "wasm_emission", "source_to_wasm", "engine_setup",
                 "native_preparation", "realm_and_instantiation", "module_initialization"):
        assert type(report["phases_ns"].get(name)) is int and report["phases_ns"][name] > 0
    configuration = report["configuration"]
    assert configuration["compilation_jobs"] == 1
    assert configuration["native_parallel_compilation"] is False
    expected_configuration = dict(fast_configuration)
    if native_mode == "speed":
        expected_configuration.update(cranelift_opt_level="Speed", register_allocation="Backtracking")
    assert configuration == expected_configuration
    return medians


def digest_bytes(value):
    import hashlib
    return hashlib.sha256(value).hexdigest()


def checked_node(report, expected_inputs, goldens):
    assert report["schema"] == "scriptw-react-retained-module-reference-v1"
    assert report["node"]["node"].startswith("24.")
    assert report["case_order"] == list(CASES)
    assert report["samples"] == SAMPLES and report["warmups"] == WARMUPS
    checked_inputs(report, expected_inputs)
    rows = report["observations"]
    expected_order = [case for case in CASES for _ in range(SAMPLES + WARMUPS)]
    assert [row["case"] for row in rows] == expected_order
    medians = {}
    for case in CASES:
        selected = [row for row in rows if row["case"] == case]
        assert all(row["stdout"] == goldens[case] for row in selected)
        medians[case] = checked_observations(selected)
    for name in ("realm_creation_ns", "source_module_parse_ns", "module_link_and_initialization_ns"):
        assert type(report[name]) is int and report[name] > 0
    return medians


def parse_cargo_producer(path, candidate):
    rows = [json.loads(line) for line in Path(path).read_text().splitlines() if line]
    finished = [row for row in rows if row.get("reason") == "build-finished"]
    assert len(finished) == 1 and finished[0]["success"], "Cargo producer did not complete successfully"
    artifacts = [row for row in rows if row.get("reason") == "compiler-artifact"
                 and row.get("executable") and row.get("target", {}).get("name") == "rsc_baseline"]
    exact = []
    for row in artifacts:
        target = row["target"]
        profile = row["profile"]
        assert "example" in target["kind"] and target["test"] is False
        assert profile["test"] is False and profile["opt_level"] == "3"
        if digest(row["executable"]) == digest(candidate):
            exact.append(row)
    assert len(exact) == 1, "Cargo JSON log must identify exactly one ordinary rsc_baseline executable matching candidate host"
    return exact[0]


def cargo_source_identity(path):
    rows = [json.loads(line) for line in Path(path).read_text().splitlines() if line]
    identities = set()
    for row in rows:
        if row.get("reason") != "build-script-executed":
            continue
        environment = dict(row.get("env", []))
        fingerprint = environment.get("SCRIPTW_COMPILER_FINGERPRINT")
        revision = environment.get("SCRIPTW_COMPILER_SOURCE_REVISION")
        if fingerprint and revision:
            identities.add((fingerprint, revision))
    assert len(identities) == 1, "Cargo producer must emit exactly one source fingerprint/revision pair"
    return next(iter(identities))


def recorded_cargo_artifact(path):
    """Read Cargo's historical artifact metadata without following its reused output path."""
    rows = [json.loads(line) for line in Path(path).read_text().splitlines() if line]
    assert any(row.get("reason") == "build-finished" and row.get("success") for row in rows)
    artifacts = [row for row in rows if row.get("reason") == "compiler-artifact"
                 and row.get("target", {}).get("name") == "rsc_baseline"
                 and row.get("executable")]
    assert len(artifacts) == 1
    artifact = artifacts[0]
    assert "example" in artifact["target"]["kind"] and artifact["target"]["test"] is False
    assert artifact["profile"]["test"] is False and artifact["profile"]["opt_level"] == "3"
    return artifact


def validate_baseline(baseline_host, producer, baseline_report, public):
    """Bind the frozen 2255 host to its published v2 identity and original measurements."""
    identity = public["engines"]["candidate"]["identity"]
    expected = ("source_fingerprint", "source_commit", "executable_sha256", "compiler_identity_scheme",
                "toolchain", "configuration", "program_wasm_sha256", "runtime", "inputs")
    report = read(baseline_report)
    assert report["schema"] == "scriptw-react-retained-baseline-v1" and report["status"] == "complete"
    for name in expected:
        assert report[name] == identity[name], f"raw baseline report differs from published identity: {name}"
    assert report["native_mode"] == "fast"
    assert identity["source_fingerprint"].startswith("2255a008")
    assert identity["source_commit"] == "7b98415010501ab7c8f78dbf81661c06a9cb20bf"
    assert digest(baseline_host) == identity["executable_sha256"] == producer["sha256"]
    assert producer["frozen_path"] and Path(producer["frozen_path"]).resolve() == baseline_host.resolve()
    assert digest(producer["cargo_stdout"]) == producer["cargo_stdout_sha256"]
    assert digest(baseline_host) == public["candidate"]["sha256"]
    assert digest(producer["cargo_stdout"]) == public["candidate"]["cargo_producer_sha256"]
    artifact = producer["artifact"]
    assert artifact["target"]["name"] == "rsc_baseline"
    assert artifact["fresh"] is False, "original 2255 measured producer was not a fresh build; retain that recorded fact"
    assert artifact == public["candidate"]["artifact"]
    assert producer["source_manifest_sha256"] == public["source_manifest_sha256"]

    # Validate the original measured source snapshot with its original validator.
    old_common_spec = importlib.util.spec_from_file_location("number_domains_archival_common", REFERENCE_COMMON)
    old_common = importlib.util.module_from_spec(old_common_spec)
    old_common_spec.loader.exec_module(old_common)
    prior_manifest_path = ROOT / "target/performance-levers-20261108/tools/source-outlined-1/manifest.json"
    assert digest(prior_manifest_path) == producer["source_manifest_sha256"]
    prior_manifest = old_common.validate_snapshot(prior_manifest_path)
    assert prior_manifest["runtime_abi"] == 53
    assert prior_manifest["base_git"] == "7b98415010501ab7c8f78dbf81661c06a9cb20bf"
    return report, identity

def reference_first_candidate(campaign):
    rows = [row for row in campaign["processes"]
            if row["engine"] == "candidate" and row["block"] == 0 and row["repetition"] == 0]
    assert len(rows) == 1 and rows[0]["status"] == "complete"
    return rows[0]


def external_test_path(relative):
    path = Path(relative)
    return (not path.is_absolute() and ".." not in path.parts and len(path.parts) >= 4
            and path.parts[0] == "crates" and path.parts[2] == "tests" and path.suffix == ".rs")


def candidate_reuse(receipt_path, source_manifest, producer_path, candidate_host, candidate_artifact):
    """Qualify identical product output across external integration-test-only edits."""
    receipt_path = Path(receipt_path).resolve(strict=True)
    assert receipt_path.is_relative_to(BASE.resolve())
    receipt = read(receipt_path)
    assert receipt["schema"] == "scriptw-rsc-levers-qualified-candidate-reuse-v1"
    assert receipt["complete"] is True
    assert receipt["previous_fresh"] is False and receipt["current_fresh"] is True
    assert receipt["producer_inputs_identical"] is True

    def checked_manifest_entry(name):
        item = receipt[name]
        path = Path(item["path"]).resolve(strict=True)
        assert path.is_relative_to(ROOT)
        assert digest(path) == item["sha256"], f"reuse {name} manifest hash mismatch"
        return path

    previous_path = checked_manifest_entry("previous_source")
    current_path = checked_manifest_entry("current_source")
    source_manifest = Path(source_manifest).resolve(strict=True)
    assert current_path == source_manifest, "reuse current source must be the frozen campaign source"
    previous = validate_snapshot(previous_path)
    current = check_source(current_path)
    assert previous["base_git"] == current["base_git"] == PINNED_HEAD
    assert previous["base_runtime_abi"] == current["base_runtime_abi"] == BASE_RUNTIME_ABI
    assert previous["runtime_abi"] == current["runtime_abi"] == RUNTIME_ABI

    previous_names = set(previous["files"]) | set(previous["deleted_files"])
    current_names = set(current["files"]) | set(current["deleted_files"])
    changed = []
    for name in sorted(previous_names | current_names):
        old = previous["files"].get(name)
        new = current["files"].get(name)
        old_value = None if old is None else (old["sha256"], old["origin"])
        new_value = None if new is None else (new["sha256"], new["origin"])
        if old_value != new_value:
            changed.append(name)
    assert changed and changed == receipt["allowed_changed_files"]
    assert all(external_test_path(name) for name in changed), (
        f"only external Rust integration tests are reusable; changed {changed}"
    )
    membership_changes = (set(previous["tracked_files"]) ^ set(current["tracked_files"])) | \
                         (set(previous["untracked_files"]) ^ set(current["untracked_files"]))
    assert membership_changes <= set(changed), "tracked/untracked membership changed outside allowed test files"

    previous_producer_path = Path(receipt["previous_producer"]["path"]).resolve(strict=True)
    current_producer_path = Path(receipt["current_producer"]["path"]).resolve(strict=True)
    assert previous_producer_path.is_relative_to(ROOT) and current_producer_path.is_relative_to(ROOT)
    producer_path = Path(producer_path).resolve(strict=True)
    assert digest(previous_producer_path) == receipt["previous_producer"]["sha256"]
    assert digest(current_producer_path) == receipt["current_producer"]["sha256"]
    assert producer_path == current_producer_path
    previous_artifact = recorded_cargo_artifact(previous_producer_path)
    current_artifact = recorded_cargo_artifact(current_producer_path)
    assert previous_artifact["fresh"] is False and current_artifact["fresh"] is True
    assert candidate_artifact == current_artifact
    assert {**previous_artifact, "fresh": None} == {**current_artifact, "fresh": None}
    assert receipt["previous_artifact"] == previous_artifact
    assert receipt["current_artifact"] == current_artifact
    previous_fingerprint = cargo_source_identity(previous_producer_path)
    current_fingerprint = cargo_source_identity(current_producer_path)
    assert previous_fingerprint == current_fingerprint
    assert candidate_host.is_file()
    assert digest(candidate_host) == receipt["binary"]["sha256"]
    previous_binary_path = Path(receipt["binary"]["path"]).resolve(strict=True)
    assert previous_binary_path.is_relative_to(ROOT)
    assert digest(previous_binary_path) == receipt["binary"]["sha256"]
    assert previous_artifact["executable"] == current_artifact["executable"]
    return {
        "path": str(receipt_path), "sha256": digest(receipt_path),
        "allowed_changed_files": changed,
        "previous_source": {"path": str(previous_path), "sha256": digest(previous_path)},
        "current_source": {"path": str(current_path), "sha256": digest(current_path)},
        "previous_producer": {"path": str(previous_producer_path), "sha256": digest(previous_producer_path)},
        "current_producer": {"path": str(current_producer_path), "sha256": digest(current_producer_path)},
        "binary": {"path": str(candidate_host), "sha256": digest(candidate_host)},
        "previous_artifact": previous_artifact, "current_artifact": current_artifact,
        "compiler_source_identity": {"source_fingerprint": current_fingerprint[0],
                                      "source_revision": current_fingerprint[1]},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--candidate-host", type=Path, required=True)
    parser.add_argument("--candidate-producer", type=Path, required=True,
                        help="Cargo --message-format=json-render-diagnostics stdout for the current source")
    parser.add_argument("--candidate-reuse-receipt", type=Path,
                        help="test-only identical-executable proof; required only when Cargo marks the artifact fresh")
    parser.add_argument("--candidate-build-argv", required=True,
                        help="JSON string containing the exact Cargo argv that produced candidate host")
    parser.add_argument("--baseline-host", type=Path, default=BASELINE_HOST)
    parser.add_argument("--baseline-producer", type=Path, default=BASELINE_PRODUCER)
    parser.add_argument("--baseline-report", type=Path, default=REFERENCE_REPORT)
    parser.add_argument("--node", type=Path,
                        default=Path.home() / ".local/share/fnm/node-versions/v24.12.0/installation/bin/node")
    parser.add_argument("--time", type=Path, default=ROOT / "target/performance-worker-cpu/tools/time")
    parser.add_argument("--focused-receipt", type=Path, action="append", required=True,
                        help="repeat for each root-qualified semantic/emission receipt")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    candidate_build_argv = json.loads(args.candidate_build_argv)
    assert isinstance(candidate_build_argv, list) and candidate_build_argv
    assert all(isinstance(value, str) for value in candidate_build_argv)
    assert candidate_build_argv[0] == "cargo"
    assert "build.jobs=1" in candidate_build_argv
    assert "build" in candidate_build_argv and "--release" in candidate_build_argv and "--locked" in candidate_build_argv
    assert "--example" in candidate_build_argv
    example_index = candidate_build_argv.index("--example")
    assert candidate_build_argv[example_index + 1] == "rsc_baseline"

    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1, "RSC cohort requires one pinned CPU"
    source_manifest = args.source_manifest.resolve(strict=True)
    manifest = check_source(source_manifest)
    assert manifest["runtime_abi"] == RUNTIME_ABI and manifest["base_runtime_abi"] == BASE_RUNTIME_ABI
    baseline_host = executable(args.baseline_host)
    candidate_host = executable(args.candidate_host)
    node = executable(args.node)
    timer = executable(args.time)
    baseline_producer_path = args.baseline_producer.resolve(strict=True)
    baseline_producer = read(baseline_producer_path)
    baseline_report_path = args.baseline_report.resolve(strict=True)
    public = read(source_manifest.parent / "baseline/rsc-current.json")
    checked_baseline, baseline_identity = validate_baseline(
        baseline_host, baseline_producer, baseline_report_path, public
    )
    assert baseline_identity == manifest["baseline_identity"]
    recorded_baseline_host = Path(baseline_producer["frozen_path"]).resolve(strict=True)

    reference_campaign_path = REFERENCE_CAMPAIGN.resolve(strict=True)
    reference_aggregate_path = REFERENCE_AGGREGATE.resolve(strict=True)
    reference_public_path = REFERENCE_PUBLIC.resolve(strict=True)
    reference_campaign = read(reference_campaign_path)
    reference_aggregate = read(reference_aggregate_path)
    assert reference_campaign["schema"] == "scriptw-rsc-levers-campaign-v1"
    assert reference_campaign["status"] == "complete"
    assert reference_aggregate["measurement"]["campaign_sha256"] == digest(reference_campaign_path)
    assert reference_aggregate["engines"]["candidate"]["identity"] == baseline_identity
    assert digest(reference_public_path) == manifest["published_rsc_current_sha256"]
    baseline_row = reference_first_candidate(reference_campaign)
    pinned_raw_report = (REFERENCE_DIR / baseline_row["report"]).resolve(strict=True)
    assert baseline_report_path == pinned_raw_report
    assert digest(baseline_report_path) == baseline_row["report_sha256"]
    assert reference_aggregate["engines"]["candidate"]["cases"]["rsc-sync"]

    reference_inputs = reference_campaign["inputs"]
    for path in (node, timer, DRIVER, REFERENCE_COMMON, ROOT / "scripts/benchmark_metrics.py",
                 ROOT / "scripts/limited_verification.py"):
        expected_sha = reference_inputs.get(str(path.resolve()))
        assert expected_sha is not None and digest(path) == expected_sha, (
            f"measurement input differs from published RSC campaign: {path}"
        )

    candidate_host = candidate_host.resolve(strict=True)
    candidate_producer_path = args.candidate_producer.resolve(strict=True)
    candidate_artifact = parse_cargo_producer(candidate_producer_path, candidate_host)
    reuse = None
    if args.candidate_reuse_receipt is None:
        assert candidate_artifact["fresh"] is False, "direct candidate producer must build the frozen source"
    else:
        reuse = candidate_reuse(args.candidate_reuse_receipt, source_manifest, candidate_producer_path,
                                candidate_host, candidate_artifact)
    assert candidate_artifact["package_id"].split("#", 1)[0].endswith("scriptw-cli")
    assert candidate_artifact["target"]["crate_types"] == ["bin"]
    assert candidate_artifact["features"] == []
    assert candidate_host != baseline_host and digest(candidate_host) != digest(baseline_host)
    candidate_cargo_rows = [json.loads(line) for line in candidate_producer_path.read_text().splitlines() if line]
    assert any(row.get("reason") == "build-finished" and row.get("success") for row in candidate_cargo_rows)
    candidate_source_fingerprint, candidate_source_revision = cargo_source_identity(candidate_producer_path)
    assert candidate_source_revision.removeprefix("git:") == PINNED_HEAD

    focused = []
    for path in args.focused_receipt:
        resolved = path.resolve(strict=True)
        assert resolved.is_file() and resolved.stat().st_size > 0, f"missing focused-check receipt: {resolved}"
        focused.append({"path": str(resolved), "sha256": digest(resolved), "bytes": resolved.stat().st_size})
    assert len({row["path"] for row in focused}) == len(focused)

    fixtures = FIXTURES.resolve(strict=True)
    source_path = (fixtures / "rsc.js").resolve(strict=True)
    support_path = (fixtures / "support.json").resolve(strict=True)
    support = read(support_path)
    assert support["versions"]["react"] == "19.3.1"
    assert support["versions"]["react-server-dom-webpack"] == "19.3.1"
    inputs = {name: checked_baseline["inputs"][name]
              for name in ("source_sha256", "support_sha256", "adapted_source_sha256", "wrapper")}
    assert digest(source_path) == inputs["source_sha256"]
    assert digest(support_path) == inputs["support_sha256"]
    assert digest_bytes(source_path.read_bytes() + inputs["wrapper"].encode()) == inputs["adapted_source_sha256"]
    goldens = {case: support["expected"][case] for case in CASES}
    assert all(isinstance(value, str) and value.endswith("\n") for value in goldens.values())

    tracked = {
        source_manifest, source_manifest.parent / "tracked.patch", source_manifest.parent / "baseline/rsc-current.json",
        source_path, support_path, DRIVER, Path(__file__).resolve(), Path(__file__).with_name("common.py"),
        Path(__file__).with_name("freeze_source.py"), REFERENCE_COMMON, ROOT / "scripts/benchmark_metrics.py",
        ROOT / "scripts/limited_verification.py", node, timer, baseline_host, recorded_baseline_host, candidate_host,
        baseline_producer_path, Path(baseline_producer["cargo_stdout"]).resolve(), baseline_report_path,
        candidate_producer_path, reference_campaign_path, reference_aggregate_path, reference_public_path,
        Path(candidate_artifact["executable"]).resolve(strict=True),
    }
    if reuse is not None:
        tracked.add(Path(reuse["path"]))
        for role in ("previous_source", "current_source"):
            path = Path(reuse[role]["path"])
            tracked.update((path, path.parent / "tracked.patch"))
        for role in ("previous_producer", "current_producer"):
            tracked.add(Path(reuse[role]["path"]))
    tracked.update(Path(row["path"]) for row in focused)
    fingerprints = {str(path.resolve(strict=True)): digest(path) for path in sorted(tracked)}

    output = args.output.resolve()
    assert output.is_relative_to(TARGET) and not output.exists(), (
        "campaign output must be new and under the isolated tools directory"
    )
    output.mkdir(parents=True)
    (output / "inputs").mkdir()
    shutil.copyfile(source_manifest, output / "inputs/source-manifest.json")
    shutil.copyfile(baseline_report_path, output / "inputs/baseline-first-candidate-report.json")
    shutil.copyfile(baseline_producer_path, output / "inputs/baseline-frozen-producer.json")
    shutil.copyfile(Path(baseline_producer["cargo_stdout"]), output / "inputs/baseline-original-cargo.jsonl")
    shutil.copyfile(candidate_producer_path, output / "inputs/candidate-cargo.jsonl")
    shutil.copyfile(DRIVER, output / "inputs/react-driver.cjs")
    shutil.copyfile(reference_campaign_path, output / "inputs/reference-campaign.json")
    shutil.copyfile(reference_aggregate_path, output / "inputs/reference-aggregate.json")
    shutil.copyfile(reference_public_path, output / "inputs/published-rsc-current.json")
    for index, item in enumerate(focused):
        shutil.copyfile(item["path"], output / "inputs" / f"focused-{index}.receipt")

    receipt = {
        "schema": "scriptw-rsc-levers-campaign-v1",
        "status": "incomplete",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_manifest": {"path": str(source_manifest), "sha256": digest(source_manifest)},
        "source_manifest_sha256": digest(source_manifest),
        "source_base_git": PINNED_HEAD,
        "base_runtime_abi": BASE_RUNTIME_ABI,
        "runtime_abi": RUNTIME_ABI,
        "abi_change": manifest["abi_change"],
        "focused_receipts": focused,
        "baseline": {"path": str(baseline_host), "sha256": digest(baseline_host),
                     "producer": str(baseline_producer_path), "producer_sha256": digest(baseline_producer_path),
                     "report": str(baseline_report_path), "report_sha256": digest(baseline_report_path),
                     "identity": baseline_identity,
                     "reference_campaign": str(reference_campaign_path),
                     "reference_campaign_sha256": digest(reference_campaign_path),
                     "reference_aggregate": str(reference_aggregate_path),
                     "reference_aggregate_sha256": digest(reference_aggregate_path),
                     "published_report_sha256": digest(reference_public_path)},
        "candidate": {"path": str(candidate_host), "sha256": digest(candidate_host),
                      "build_argv": candidate_build_argv,
                      "build_wrapper": ["python3", "-B", "scripts/limited_verification.py", "--"],
                      "cargo_producer": str(candidate_producer_path),
                      "cargo_producer_sha256": digest(candidate_producer_path),
                      "artifact": candidate_artifact,
                      "qualified_reuse": reuse,
                      "compiler_source_identity": {"source_fingerprint": candidate_source_fingerprint,
                                                   "source_revision": candidate_source_revision}},
        "node": {"path": str(node), "sha256": digest(node)},
        "gnu_time": {"path": str(timer), "sha256": digest(timer)},
        "inputs": fingerprints,
        "policy": {"actors": list(ENGINES), "blocks": 2,
                   "processes_per_actor_per_block": PROCESSES_PER_BLOCK,
                   "samples": SAMPLES, "warmups": WARMUPS, "case_order": list(CASES),
                   "process_order": [list(ENGINES), list(reversed(ENGINES))],
                   "checked_flight_calls": 640,
                   "clock": "retained applicationRun through complete Flight serialization and consumption; JSON encoding and exact validation outside request timing",
                   "execution": "fresh process per actor repetition; one prepared retained module/Realm per process; natural GC",
                   "memory": "GNU time runtime-child lifetime high-water RSS; not live JavaScript heap",
                   "speed_scope": "candidate-speed is a separately scored native-policy actor using the existing host's explicit Speed/Backtracking mode"},
        "resources_before": resources(),
        "processes": [],
        "limits": "Descriptive same-host cohort, not causal attribution to one source change, conformance, statistical confidence or universal application performance. The 2255 baseline is retained under its original source/runtime identity. Fast and Speed are separately scored; candidate reports must share source, host, P, R and request inputs, with only native compilation policy differing.",
    }

    def persist():
        save(output / "campaign.json", receipt)

    def check_inputs_unchanged():
        check_source(source_manifest)
        for name, expected in fingerprints.items():
            assert digest(name) == expected, f"campaign input changed: {name}"

    persist()
    environment_base = limited_environment()
    assert not any(environment_base.get(name) for name in ("NODE_OPTIONS", "LD_PRELOAD", "LD_AUDIT"))
    for name in list(environment_base):
        if name.startswith(("SCRIPTW_", "SCRIPTC_", "ZIG_")) or name == "NODE_COMPILE_CACHE":
            del environment_base[name]

    identities = {}
    fast_configuration = checked_baseline["configuration"]
    try:
        for block in range(2):
            order = ENGINES if block == 0 else tuple(reversed(ENGINES))
            for repetition in range(PROCESSES_PER_BLOCK):
                for actor in order:
                    check_inputs_unchanged()
                    label = f"block-{block}-rep-{repetition}-{actor}"
                    work = output / label
                    work.mkdir()
                    for directory in ("tmp", "cache"):
                        (work / directory).mkdir()
                    env = dict(environment_base)
                    env.update(TMPDIR=str(work / "tmp"), NODE_DISABLE_COMPILE_CACHE="1",
                               SCRIPTW_CACHE_DIR=str(work / "cache"), SCRIPTW_JOBS="1",
                               SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES="1",
                               SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64 * 1024**2))
                    raw = work / "report.json"
                    if actor == "v8":
                        command = [str(node), "--experimental-vm-modules", "--no-warnings", str(DRIVER),
                                   "retained-module", str(fixtures)]
                    else:
                        selected_host = baseline_host if actor == "baseline" else candidate_host
                        mode = "speed" if actor == "candidate-speed" else "fast"
                        command = [str(selected_host), str(source_path), str(support_path), str(raw),
                                   str(SAMPLES), str(WARMUPS), mode]
                    row = {"label": label, "block": block, "repetition": repetition,
                           "actor": actor, "engine": actor,
                           "argv": command,
                           "environment": {key: value for key, value in env.items()
                                           if key.startswith(("NODE_", "SCRIPTW_")) or key == "TMPDIR"},
                           "stdout": str((work / "stdout").relative_to(output)),
                           "stderr": str((work / "stderr").relative_to(output)),
                           "report": str(raw.relative_to(output)), "status": "incomplete",
                           "resources_before": resources()}
                    receipt["processes"].append(row)
                    persist()
                    with (work / "stdout").open("xb") as stdout, (work / "stderr").open("xb") as stderr:
                        row["resources"] = measure_process(command, cwd=ROOT, env=env, stdout=stdout,
                                                           stderr=stderr, timeout=60, time_binary=timer)
                    row["resources_after"] = resources()
                    check_resources(row["resources_before"], row["resources_after"])
                    row["stdout_sha256"] = digest(work / "stdout")
                    row["stderr_sha256"] = digest(work / "stderr")
                    assert row["resources"]["exit_code"] == 0 and not row["resources"]["timed_out"], (
                        f"child failed: {label}"
                    )
                    assert not (work / "stderr").read_bytes(), f"unexpected stderr: {label}"
                    child_report = read(work / "stdout")
                    if actor == "v8":
                        save(raw, child_report)
                        medians = checked_node(child_report, inputs, goldens)
                        identity = {"node": child_report["node"]}
                    else:
                        assert read(raw) == child_report, "Scriptw stdout and saved report differ"
                        mode = "speed" if actor == "candidate-speed" else "fast"
                        medians = checked_scriptw(child_report, baseline_host if actor == "baseline" else candidate_host,
                                                  inputs, goldens, mode, fast_configuration)
                        identity_fields = ("source_fingerprint", "source_commit", "executable_sha256",
                                           "compiler_identity_scheme", "toolchain", "configuration",
                                           "program_wasm_bytes", "program_wasm_sha256", "runtime", "inputs",
                                           "native_mode", "native_mode_scope")
                        identity = {name: child_report[name] for name in identity_fields}
                        assert identity["executable_sha256"] == digest(
                            baseline_host if actor == "baseline" else candidate_host
                        )
                        if actor in ("candidate", "candidate-speed"):
                            assert identity["source_commit"] == PINNED_HEAD
                            assert identity["source_fingerprint"] == candidate_source_fingerprint
                            assert identity["native_mode"] == mode
                        previous = identities.get(actor)
                        if previous is not None:
                            assert previous == identity, f"actor identity changed: {actor}"
                        if actor == "baseline":
                            assert identity["source_fingerprint"] == baseline_identity["source_fingerprint"]
                    previous = identities.get(actor)
                    if previous is None:
                        identities[actor] = identity
                    else:
                        assert previous == identity, f"actor identity changed: {actor}"
                    row["process_medians_ns"] = medians
                    row["identity"] = identity
                    row["report_sha256"] = digest(raw)
                    row["status"] = "complete"
                    persist()
                    check_inputs_unchanged()
                    print("CHECKED", label, flush=True)

        assert len(receipt["processes"]) == 32
        assert all(sum(row["actor"] == actor for row in receipt["processes"]) == 8 for actor in ENGINES)
        fast_identity = identities["candidate"]
        speed_identity = identities["candidate-speed"]
        for field in ("source_fingerprint", "source_commit", "executable_sha256", "compiler_identity_scheme",
                      "toolchain", "program_wasm_bytes", "program_wasm_sha256", "runtime", "inputs"):
            assert fast_identity[field] == speed_identity[field], f"candidate Fast/Speed input differs: {field}"
        normalized_speed = dict(speed_identity["configuration"])
        normalized_speed.update(cranelift_opt_level="None", register_allocation="SinglePass")
        assert normalized_speed == fast_identity["configuration"]
        assert fast_identity["native_mode"] == "fast" and speed_identity["native_mode"] == "speed"

        engine_summary = {}
        labels = {"baseline": "published Scriptw baseline Fast", "candidate": "new Scriptw source Fast",
                  "candidate-speed": "new Scriptw source Speed/Backtracking", "v8": "Node 24 / V8"}
        for actor in ENGINES:
            rows = [row for row in receipt["processes"] if row["actor"] == actor]
            assert len(rows) == 8 and all(row["status"] == "complete" for row in rows)
            result = {"label": labels[actor], "identity": identities[actor],
                      "cases": {case: [row["process_medians_ns"][case] for row in rows] for case in CASES},
                      "block_medians": []}
            if actor != "v8":
                result["phase_processes"] = [read(output / row["report"])["phases_ns"] for row in rows]
            else:
                result["phase_processes"] = [
                    {name: read(output / row["report"])[name] for name in (
                        "realm_creation_ns", "source_module_parse_ns", "module_link_and_initialization_ns"
                    )}
                    for row in rows
                ]
            for block in range(2):
                block_rows = [row for row in rows if row["block"] == block]
                assert len(block_rows) == PROCESSES_PER_BLOCK
                result["block_medians"].append({
                    "block": block,
                    "cases": {case: statistics.median(row["process_medians_ns"][case]
                                                       for row in block_rows) for case in CASES},
                })
            engine_summary[actor] = result

        check_inputs_unchanged()
        check_resources(receipt["resources_before"], resources())
        receipt["resources_after"] = resources()
        receipt["finished_at"] = datetime.now(timezone.utc).isoformat()
        receipt["status"] = "complete"
        persist()
        aggregate = {"schema": "scriptw-rsc-levers-aggregate-v1",
                     "date": datetime.now(timezone.utc).date().isoformat(),
                     "source_manifest_sha256": digest(source_manifest),
                     "runtime_abi": RUNTIME_ABI,
                     "baseline": receipt["baseline"], "candidate": receipt["candidate"],
                     "measurement": {"campaign": str((output / "campaign.json").relative_to(ROOT)),
                                     "campaign_sha256": digest(output / "campaign.json"),
                                     "blocks": 2, "processes_per_engine": 8, "samples": SAMPLES,
                                     "warmups": WARMUPS, "checked_flight_calls": 640,
                                     "case_order": list(CASES),
                                     "actors": list(ENGINES)},
                     "caveat": receipt["limits"], "engines": engine_summary}
        save(output / "aggregate.json", aggregate)
        print("RSC LEVERS COHORT READY", output / "aggregate.json", flush=True)
    except BaseException as error:
        receipt["status"] = "failed"
        receipt["failure"] = repr(error)
        persist()
        raise


if __name__ == "__main__":
    main()
