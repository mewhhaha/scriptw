"""Stage measured reports and reviewable docs; leave tracked files untouched."""
from pathlib import Path
import json,subprocess,sys
ROOT=Path.cwd();BASE=ROOT/'target/performance-predicate-transport-20261108';sys.path.insert(0,str(BASE/'tools'))
from common import check_source,read,save,digest
source=BASE/'tools/source-current/manifest.json';check_source(source)
assert read(BASE/'final-batch.json')['complete']
profiles=read(BASE/'fresh-profiles/summary.json');assert profiles['status']=='complete' and profiles['unscored']
logs=BASE/'publication-logs';logs.mkdir(exist_ok=False)
def run(name,argv):
 check_source(source);save(logs/(name+'-argv.json'),argv)
 with (logs/(name+'.stdout')).open('xb') as so,(logs/(name+'.stderr')).open('xb') as se:
  subprocess.run(argv,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,check=True,timeout=300)
 check_source(source);print('STAGED',name,flush=True)
py=[sys.executable,'-B']
run('coverage',py+[str(BASE/'summarize_acceptance.py')])
run('attribution',py+[str(BASE/'make_attribution.py'),'--source-manifest',str(source),'--campaign',str(BASE/'tools/rsc-campaign-1/campaign.json'),'--aggregate',str(BASE/'tools/rsc-campaign-1/aggregate.json'),'--diagnostics',str(BASE/'final-diagnostics'),'--output',str(BASE/'attribution-stage'),'--docs'])
attr_path=BASE/'attribution-stage/react-attribution-current.json';attr=read(attr_path)
fp=attr['candidate_identity']['source_fingerprint'];assert profiles['source_fingerprint']==fp
assert len(profiles['cohorts'])==4 and all(len(c['processes'])==3 for c in profiles['cohorts'])
attr['sampling']['fresh']=True
attr['sampling']['current']={'source_fingerprint':fp,'summary':{'path':str(BASE/'fresh-profiles/summary.json'),'sha256':digest(BASE/'fresh-profiles/summary.json')},'processes':12,'windows_per_process':100,'warmups':3,'event':'cycles:u','period':250000,'call_graph':'fp','cohorts':[dict(native_mode=r['native_mode'],request_mode=r['request_mode'],processes=r['processes'],samples=r['samples'],own_period_sum=r['own_period_sum'],unavailable_ip_or_callchain_samples=r['unavailable_ip_or_callchain_samples'],unavailable_ip_or_callchain_period_sum=r['unavailable_ip_or_callchain_period_sum'],top_own_leaf_period_weights=r['own_leaf_period_weights'][:12]) for r in profiles['summaries']],'limits':profiles['limits']}
attr['verification']['inputs'][str(BASE/'fresh-profiles/summary.json')]=digest(BASE/'fresh-profiles/summary.json')
attr['limits']=[limit for limit in attr['limits'] if limit!='No fresh leaf sampling or physical allocation census.']
attr['limits'].append('Fresh FP locations are period-weighted cycle samples, not exact calls, allocations, wall-time shares or speedup evidence. Physical allocation has not been recounted.')
save(attr_path,attr)
snippet_path=BASE/'attribution-stage/docs-snippet.json';snippet=read(snippet_path);assert snippet['source_fingerprint']==fp
snippet['markdown']=snippet['markdown'].replace('No fresh leaf sampling or physical allocation census.','Physical allocation has not been recounted.')
lines=['','Fresh caller profiles use 12 independent processes: Fast/Speed × sync/async × three repetitions, each with 3 warmups and 100 request windows. The table shows the largest disjoint leaf period weights; inclusive caller tables, host/unresolved symbols and unavailable callchains remain in the archived raw summary. These are cycle-sample locations, not wall-time shares or exact call counts.','','| Native policy / mode | Leaf owner | Sample-period weight |','| --- | --- | ---: |']
for row in profiles['summaries']:
 for leaf in row['own_leaf_period_weights'][:4]:
  owner=leaf['owner'].replace('|','\\|')
  lines.append(f"| {row['native_mode']} / {row['request_mode']} | `{owner}` | {leaf['sample_share']:.1%} |")
snippet['markdown']+='\n'.join(lines)+'\n';save(snippet_path,snippet)
evidence=[BASE/'source-checks',BASE/'source-guards',BASE/'focused',BASE/'broad',BASE/'production-cli',BASE/'final-diagnostics',BASE/'fresh-profiles',BASE/'attribution-tools',BASE/'attribution-stage',BASE/'build.stdout',BASE/'build.stderr',BASE/'build-argv.json',BASE/'build-receipt.json',BASE/'final-batch.json',BASE/'coverage-summary.json',BASE/'example-feature-comparison.json',BASE/'build_and_freeze.py',BASE/'verify_native.py',BASE/'verify_cli.py',BASE/'diagnostics.py',BASE/'make_attribution.py',BASE/'summarize_acceptance.py',BASE/'run_final.py',BASE/'run_profiles.py',Path(__file__),BASE/'publication-tools',ROOT/'target/performance-integer-projection-20261108']
argv=py+[str(BASE/'publication-tools/stage_publication.py'),'--campaign',str(BASE/'tools/rsc-campaign-1/campaign.json'),'--aggregate',str(BASE/'tools/rsc-campaign-1/aggregate.json'),'--source-manifest',str(source),'--situations-report',str(BASE/'situations-full/report.json'),'--output-dir',str(BASE/'publication-stage')]
for path in evidence:argv+=['--evidence',str(path)]
run('reports',argv)
run('docs',py+[str(BASE/'publication-tools/stage_docs.py'),'--rsc-report',str(BASE/'publication-stage/reports/rsc-current.json'),'--situations-report',str(BASE/'publication-stage/reports/situations-current.json'),'--coverage-summary',str(BASE/'coverage-summary.json'),'--attribution-summary',str(snippet_path),'--output-dir',str(BASE/'docs-stage')])
print('REVIEWABLE PUBLICATION READY',flush=True)
