"""Run source-bound frozen focused or complete native targets, serially."""
import argparse,json,re,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-predicate-transport-20261108';sys.path[:0]=[str(BASE/'tools'),str(ROOT/'scripts')]
from common import check_source,digest,read,save
from limited_verification import require_kernel_budget,limited_environment
from measure_rsc import resources,check_resources
from native_test_protocol import parse_inventory,result_summaries
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['focused','broad'],required=True);a=p.parse_args()
require_kernel_budget(4*1024**3);source=BASE/'tools/source-current/manifest.json';check_source(source)
if a.phase=='focused':
 scopes=[('emission','captured_call_regions::'),('emission','own_descriptor_predicates::'),('emission','json_enumerable_keys::'),('emission','property_read_plans::'),('emission','numeric_body::'),('emission','scalar_row_modes::'),('emission','scalar_masked_rows::'),('structure_language','shadowed_property_read_arm_absence_structure::'),('aot_language','aot_captured_call_regions::'),('aot_builtins','aot_proxy_target_descriptors::'),('aot_builtins','aot_json_stringify_preparation::'),('aot_builtins','aot_json_canonical_reviver::'),('aot_gc_entries','aot_gc_property_read_plans::')]
else:
 scopes=[(name,'') for name in ['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules','aot_gc_entries']]
out=BASE/a.phase;out.mkdir(exist_ok=False);report={'complete':False,'source_manifest_sha256':digest(source),'resources_before':resources(),'runs':[]}
def checkpoint():save(out/'receipt.json',report)
try:
 for index,(target,scope) in enumerate(scopes):
  check_source(source);binary=BASE/'frozen'/target;proof=read(binary.parent/(target+'-producer.json'));assert proof['sha256']==digest(binary) and proof['source_manifest_sha256']==digest(source)
  label=f'{index:02}-{target}-{scope.replace(":", "")}';argv=[str(binary)]
  if scope:argv.append(scope)
  argv+=['--test-threads=1'];listed=subprocess.run([*argv,'--list'],cwd=ROOT,env=limited_environment(),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);assert listed.returncode==0
  (out/(label+'.list')).write_bytes(listed.stdout);inventory=parse_inventory(listed.stdout.decode());assert inventory
  row={'target':target,'filter':scope,'argv':argv,'inventory':len(inventory),'inventory_sha256':digest(out/(label+'.list')),'binary_sha256':proof['sha256'],'resources_before':resources()};report['runs'].append(row);checkpoint();print('START',label,len(inventory),flush=True);t=time.monotonic_ns()
  with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:
   run=subprocess.run(argv,cwd=ROOT,env=limited_environment(),stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=2400)
  row.update(exit_code=run.returncode,elapsed_ns=time.monotonic_ns()-t,resources_after=resources());row['stdout_sha256']=digest(out/(label+'.stdout'));row['stderr_sha256']=digest(out/(label+'.stderr'));row['summary']=result_summaries((out/(label+'.stdout')).read_text());checkpoint()
  assert len(row['summary'])==1;status,passed,failed,ignored,measured,filtered=row['summary'][0]
  executed=[name.removesuffix(' - should panic') for name in re.findall(r'^test (.+) \.\.\. (?:ok|FAILED|ignored)$',(out/(label+'.stdout')).read_text(),re.M)]
  assert len(executed)==len(inventory) and set(executed)==set(inventory)
  assert run.returncode==0 and status=='ok' and int(passed)==len(inventory) and failed==ignored==measured=='0'
  if not scope:assert filtered=='0'
  assert digest(binary)==proof['sha256'];check_source(source);check_resources(row['resources_before'],row['resources_after']);print('END',label,passed,flush=True)
 report['complete']=True
except BaseException as e:
 report['error']=repr(e);raise
finally:
 report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after']);check_source(source);checkpoint()
print('VERIFIED',a.phase,sum(int(r['summary'][0][1]) for r in report['runs']),flush=True)
