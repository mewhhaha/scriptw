"""Authenticate the caller TID at an inherited RSC control-socket barrier."""
import os
from pathlib import Path
import platform
import time


def barrier_caller(pid, control_fd, socket_inode, thread_record):
    """Select by the exact blocked read, never by an assumed thread name/PID.

    The profiling parent withholds the ready/done acknowledgement. The child
    run thread must therefore block reading this inherited socket before its
    next request. This method does not change the guest or profiling protocol.
    """
    assert platform.system() == 'Linux' and platform.machine() == 'x86_64'
    expected_socket = f'socket:[{socket_inode}]'
    assert os.readlink(f'/proc/{pid}/fd/{control_fd}') == expected_socket
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline:
        matches = []
        for path in Path(f'/proc/{pid}/task').iterdir():
            try:
                syscall = (path / 'syscall').read_text().strip()
                fields = syscall.split()
                if len(fields) < 2 or fields[0] == 'running':
                    continue
                number, descriptor = int(fields[0], 0), int(fields[1], 0)
                # Linux x86_64: read, recvfrom (also libc recv), recvmsg.
                if number not in (0, 45, 47) or descriptor != control_fd:
                    continue
                matches.append((int(path.name), syscall))
            except FileNotFoundError:
                continue
        assert len(matches) <= 1, 'multiple threads reading the diagnostic control socket'
        if matches:
            tid, syscall = matches[0]
            record = thread_record(pid, tid)
            record['barrier_authentication'] = dict(control_fd=control_fd, socket_inode=socket_inode,
                socket_link=expected_socket, syscall=syscall,
                policy='Unique TID blocked in read/recv of the exact inherited control socket while parent withholds ACK.')
            return record
        time.sleep(0.005)
    raise RuntimeError('no unique caller TID blocked on the authenticated control socket')
