#!/usr/bin/env python3
"""Run excluded authenticated FP profiles on pinned final-candidate RSC windows."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-predicate-transport-20261108'
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'tools'))
sys.path.insert(0, str(ROOT / 'scripts'))
from common import check_source, digest
from limited_verification import kernel_group, require_kernel_budget
from measure_rsc import check_resources, resources


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--native-mode', choices=['fast', 'speed'], required=True)
    parser.add_argument('--request-mode', choices=['sync', 'async'], required=True)
    parser.add_argument('--samples', type=int, default=100)
    parser.add_argument('--processes', type=int, default=3)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert args.samples == 100 and args.processes == 3, 'keep the planned 100 windows x 3 process cohort'
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1, 'sampling requires one pinned CPU'
    campaign_path = args.campaign.resolve(strict=True)
    campaign = json.loads(campaign_path.read_text())
    assert campaign['status'] == 'complete'
    manifest = Path(campaign['source_manifest']['path']).resolve(strict=True)
    source_manifest = check_source(manifest)
    assert digest(manifest) == campaign['source_manifest_sha256']
    actor = 'candidate' if args.native_mode == 'fast' else 'candidate-speed'
    process = next(row for row in campaign['processes'] if row['actor'] == actor and row['status'] == 'complete')
    report_path = (campaign_path.parent / process['report']).resolve(strict=True)
    assert digest(report_path) == process['report_sha256']
    baseline = json.loads(report_path.read_text())
    host = Path(campaign['candidate']['path']).resolve(strict=True)
    assert digest(host) == campaign['candidate']['sha256'] == baseline['executable_sha256']
    assert baseline['source_fingerprint'] == campaign['candidate']['compiler_source_identity']['source_fingerprint']
    assert baseline['native_mode'] == args.native_mode
    for key, hash_key in (('source', 'source_sha256'), ('support', 'support_sha256')):
        input_path = Path(baseline['inputs'][key]).resolve(strict=True)
        assert digest(input_path) == baseline['inputs'][hash_key] == campaign['inputs'][str(input_path)]

    output = args.output.resolve()
    assert output.is_relative_to(BASE) and not output.exists()
    output.mkdir(parents=True)
    baseline_path = output / 'mode-anchor-report.json'
    baseline_path.write_text(json.dumps(baseline, indent=2) + '\n')
    pinned_paths = [campaign_path, report_path, manifest, host, baseline_path,
                    Path(baseline['inputs']['source']), Path(baseline['inputs']['support']),
                    *[TOOLS / name for name in ('profile_candidate.py', 'profile_rsc_fp.py',
                      'profile_thread.py', 'request_profile_support.py', 'symbolize_fp.py', 'perf-probe.json',
                      'adaptation.json', 'profile_rsc_fp.patch', 'summarize_profiles.py')]]
    adaptation = json.loads((TOOLS / 'adaptation.json').read_text())
    original_sampler = ROOT / adaptation['original_sampler_path']
    original_adaptation = ROOT / adaptation['original_adaptation_path']
    assert digest(original_sampler) == adaptation['original_sampler_sha256']
    assert digest(original_adaptation) == adaptation['original_adaptation_sha256']
    pinned_paths.extend([original_sampler, original_adaptation])
    pins = {str(path.resolve(strict=True)): digest(path) for path in pinned_paths}
    plan = {
        'schema': 'scriptw-rsc-current-candidate-profile-plan-v1', 'status': 'running', 'unscored': True,
        'native_mode': args.native_mode, 'request_mode': args.request_mode,
        'samples_per_process': args.samples, 'processes': args.processes,
        'source_fingerprint': baseline['source_fingerprint'], 'source_manifest': str(manifest),
        'source_manifest_sha256': digest(manifest),
        'host_sha256': digest(host), 'campaign_sha256': digest(campaign_path),
        'anchor_report_sha256': digest(report_path), 'pins': pins,
        'adaptation': adaptation,
        'profile_tool_sha256': digest(TOOLS / 'profile_rsc_fp.py'),
        'symbolizer_sha256': digest(TOOLS / 'symbolize_fp.py'), 'runner_sha256': digest(Path(__file__)),
        'resources_before': resources(),
        'limits': 'Excluded authenticated caller-thread FP sampling. Samples are period-weighted cycle observations, not exact calls, total execution work, allocations, wall-time shares, or speedup evidence. Each process has an independent nonce and receipt.'
    }
    (output / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    for index in range(args.processes):
        check_source(manifest)
        assert {path: digest(path) for path in pins} == pins, 'pinned source/tool/workload input changed'
        before = resources()
        folder = output / f'process-{index}'
        command = [sys.executable, str(ROOT / 'scripts/limited_verification.py'), '--', sys.executable,
                   str(TOOLS / 'profile_rsc_fp.py'), str(host), str(folder), '--mode', args.request_mode,
                   '--native-mode', args.native_mode, '--samples', str(args.samples), '--warmups', '3',
                   '--baseline-json', str(baseline_path)]
        print('RUN', index + 1, '/', args.processes, args.native_mode, args.request_mode, flush=True)
        started = time.monotonic_ns()
        subprocess.run(command, cwd=ROOT, check=True)
        elapsed = time.monotonic_ns() - started
        check_source(manifest)
        assert {path: digest(path) for path in pins} == pins, 'pinned source/tool/workload input changed'
        after = resources()
        check_resources(before, after)
        receipt_path = folder / 'receipt.json'
        receipt = json.loads(receipt_path.read_text())
        observation_path = folder / 'observations.json'
        observation = json.loads(observation_path.read_text())
        assert receipt['status'] == 'captured' and receipt['host_exit_code'] == 0
        assert receipt['mode'] == args.request_mode and receipt['samples'] == args.samples
        assert receipt['execution_target'] == 'authenticated-caller-socket' and receipt['control_edges_included'] is True
        assert receipt['source_fingerprint'] == baseline['source_fingerprint']
        assert receipt['executable_sha256'] == digest(host)
        assert receipt['nonce'] == observation['profiling']['nonce']
        assert observation['profiling']['windows'] == args.samples
        assert observation['source_fingerprint'] == baseline['source_fingerprint']
        assert observation['program_wasm_sha256'] == baseline['program_wasm_sha256']
        assert observation['runtime'] == baseline['runtime']
        assert observation['configuration'] == baseline['configuration']
        assert len(observation['cases']) == 1 and observation['cases'][0]['case'] == 'rsc-' + args.request_mode
        assert len(observation['cases'][0]['observations']) == args.samples + 3
        caller = receipt['worker_before']['barrier_authentication']
        assert caller['socket_inode'] > 0 and caller['control_fd'] >= 0 and caller['syscall']
        assert caller['socket_link'] == f"socket:[{caller['socket_inode']}]"
        assert receipt['worker_after']['tid'] == receipt['worker_before']['tid']
        assert receipt['worker_after']['starttime_ticks'] == receipt['worker_before']['starttime_ticks']
        check_resources(receipt['resources_before'], receipt['resources_after'])
        for name, metadata in receipt['raw_files'].items():
            raw = folder / name
            assert raw.is_file() and raw.stat().st_size == metadata['bytes'] and digest(raw) == metadata['sha256']
        assert observation_path.name in receipt['raw_files'] and 'samples.txt' in receipt['raw_files']
        plan.setdefault('process_receipts', []).append({
            'path': receipt_path.relative_to(output).as_posix(), 'sha256': digest(receipt_path),
            'observations_sha256': digest(observation_path), 'caller_tid': caller.get('tid', receipt['worker_before']['tid']),
            'elapsed_ns_excluded': elapsed, 'resources_before': before, 'resources_after': after,
        })
        (output / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    plan['status'] = 'complete'
    plan['receipts'] = [
        {'path': folder.name + '/receipt.json', 'sha256': digest(folder / 'receipt.json')}
        for folder in sorted(output.glob('process-*'))
    ]
    assert len(plan['receipts']) == args.processes
    check_resources(plan['resources_before'], resources())
    (output / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    print('PROFILE COHORT COMPLETE', output, flush=True)


if __name__ == '__main__':
    main()
