#!/usr/bin/env python3
"""Unscored retained Flight sampling; never replace the frozen baseline report.

Run inside limited_verification.py. Reuses the already verified perf binary and
its bounded control/ACK utilities. Caller-thread control edges surround flight(); this is an excluded diagnostic, not a scored timing boundary.
"""
import argparse
import bisect
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "scripts"))
from limited_verification import kernel_group, limited_environment, require_kernel_budget
from request_profile_support import line, perf_ack, thread_record
from profile_thread import barrier_caller

PROBE = Path(__file__).with_name("perf-probe.json")
FIELDS = ["memory.max", "memory.swap.max", "memory.oom.group", "cpu.max", "memory.events"]


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(data)
    return value.hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


from symbolize_fp import symbolize


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=["sync", "async"], required=True)
    parser.add_argument("--native-mode", choices=["fast", "speed"], default="fast")
    parser.add_argument("--samples", type=int, default=100)
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--baseline-json", type=Path, required=True)
    parser.add_argument("--capture-native", action="store_true", help="Capture same-process selected P native bytes/addressmap before counters enable")
    args = parser.parse_args()
    assert 1 <= args.samples <= 200 and 0 <= args.warmups <= 20
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    baseline_path = args.baseline_json.resolve(strict=True)
    baseline = json.loads(baseline_path.read_text())
    probe = json.loads(PROBE.read_text())
    binary, folder = args.binary.resolve(strict=True), args.output.resolve()
    assert digest(binary) == baseline["executable_sha256"]
    source, support = (Path(baseline["inputs"][key]) for key in ("source", "support"))
    assert digest(source) == baseline["inputs"]["source_sha256"]
    assert digest(support) == baseline["inputs"]["support_sha256"]
    perf_binary = ROOT / probe["unpacked_executable"]
    assert digest(perf_binary) == probe["unpacked_executable_sha256"]
    folder.mkdir(exist_ok=False)
    (folder / "tmp").mkdir()
    nonce = os.urandom(16).hex()
    env = limited_environment()
    assert not any(key.startswith("SCRIPTW_RSC_PROFILE_") for key in env)
    assert "LD_PRELOAD" not in env and "LD_AUDIT" not in env
    parent, child_socket = socket.socketpair()
    control_fd, control_inode = child_socket.fileno(), os.fstat(child_socket.fileno()).st_ino
    env.update(TMPDIR=str(folder / "tmp"), SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()),
               SCRIPTW_RSC_PROFILE_NONCE=nonce, SCRIPTW_RSC_PROFILE_MODE=args.mode)
    perf_env = limited_environment()
    perf_env.update(TMPDIR=str(folder / "tmp"), LD_LIBRARY_PATH=str(ROOT / probe["unpacked_libdir"]))
    argv = [str(binary), str(source), str(support), str(folder / "observations.json"),
            str(args.samples), str(args.warmups), args.native_mode]
    result = {
        "schema": "scriptw-rsc-fp-perf-v2", "status": "incomplete", "unscored": True,
        "argv": argv, "mode": args.mode, "samples": args.samples, "warmups": args.warmups,
        "event": "cycles:u", "period": 250000, "nonce": nonce, "call_graph": "fp", "callchain_scope": "user-only",
        "base_profiler_sha256": digest(ROOT / "target/performance-v8-climb-20261104/fiber-only/profile_rsc_fp.py"),
        "symbolizer_sha256": digest(Path(__file__).with_name("symbolize_fp.py")),
        "thread_authenticator_sha256": digest(Path(__file__).with_name("profile_thread.py")),
        "execution_target": "authenticated-caller-socket", "control_edges_included": True,
        "executable_sha256": digest(binary), "baseline_report_sha256": digest(baseline_path),
        "source_sha256": digest(source), "support_sha256": digest(support),
        "perf_sha256": digest(perf_binary), "sampler_sha256": digest(Path(__file__)),
        "limits": "Excluded diagnostic. Compile, module initialization, warmups, JSON serialization and output checks are outside sampling windows. The execution caller also owns the control socket, so its wakeup/read/write edges are included. Historical worker-only samples have a different boundary. No timing, allocation or speedup verdict.",
        "resources_before": {name: (kernel_group() / name).read_text() for name in FIELDS},
        "events": [],
    }
    save(folder / "plan.json", result)
    preexec = None
    if args.capture_native:
        sys.path.insert(0, str(ROOT / "target/react-native-attribution-20261103"))
        from dump_rsc_native import allow_debugger
        preexec = allow_debugger
    child = perf = None
    fds = []
    deadline = time.monotonic() + 180
    try:
        with (folder / "host.stdout").open("xb") as stdout, (folder / "host.stderr").open("xb") as stderr, \
             (folder / "perf.stdout").open("xb") as perf_stdout, (folder / "perf.stderr").open("xb") as perf_stderr:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, pass_fds=(child_socket.fileno(),), preexec_fn=preexec)
            child_socket.close()
            result["pid"] = child.pid
            for index in range(args.warmups, args.warmups + args.samples):
                for phase in ("ready", "done"):
                    timeout = 30
                    if index == args.warmups and phase == "ready":
                        timeout = 60
                    event = line(parent.fileno(), min(timeout, deadline - time.monotonic()))
                    expected = f"SWRSC1 {nonce} {phase} {args.mode} {index}\n"
                    assert event == expected, (event, expected)
                    result["events"].append({"phase": phase, "index": index, "monotonic_ns": time.monotonic_ns()})
                    if perf is None:
                        if args.capture_native:
                            capture = folder / "native-capture"
                            capture.mkdir()
                            payload = ROOT / "target/react-native-attribution-20261103/dump_payload.py"
                            script = "set pagination off\nset confirm off\nset debuginfod enabled off\nattach " + str(child.pid) + "\npython\nexec(compile(open(" + repr(str(payload)) + ").read(), \"dump_payload.py\", \"exec\"))\nend\ndetach\nquit\n"
                            (capture / "capture.gdb").write_text(script)
                            with (capture / "gdb.stdout").open("xb") as gout, (capture / "gdb.stderr").open("xb") as gerr:
                                captured = subprocess.run(["/usr/bin/timeout", "-k", "3", "20", "/usr/bin/gdb", "-q", "-nx", "-batch", "-x", str(capture / "capture.gdb")], cwd=ROOT, env=env | {"SCRIPTW_DUMP_OUTPUT": str(capture)}, stdout=gout, stderr=gerr, stdin=subprocess.DEVNULL, timeout=25)
                            assert captured.returncode == 0 and (capture / "native.json").exists()
                            native = json.loads((capture / "native.json").read_text())
                            assert native["pid"] == child.pid
                            result["native_capture"] = {"pid": child.pid, "payload_sha256": digest(payload), "launcher_sha256": digest(ROOT / "target/react-native-attribution-20261103/dump_rsc_native.py"), "files": {path.name: {"sha256": digest(path), "bytes": path.stat().st_size} for path in capture.iterdir() if path.is_file()}}
                        worker = barrier_caller(child.pid, control_fd, control_inode, thread_record)
                        result["worker_before"] = worker
                        (folder / "maps-before.txt").write_text(Path(f"/proc/{child.pid}/maps").read_text())
                        (folder / "perf-before.map").write_bytes(Path(f"/tmp/perf-{child.pid}.map").read_bytes())
                        ctl_r, ctl_w = os.pipe()
                        ack_r, ack_w = os.pipe()
                        fds += [ctl_r, ctl_w, ack_r, ack_w]
                        perf_argv = [str(perf_binary), "record", "--no-buildid", "-e", result["event"],
                                     "-c", str(result["period"]), "-t", str(worker["tid"]), "--delay=-1", "--call-graph", "fp", "--user-callchains",
                                     f"--control=fd:{ctl_r},{ack_w}", "-o", str(folder / "perf.data")]
                        result["perf_argv"] = perf_argv
                        perf = subprocess.Popen(perf_argv, cwd=ROOT, env=perf_env, stdin=subprocess.DEVNULL,
                                                stdout=perf_stdout, stderr=perf_stderr, pass_fds=(ctl_r, ack_w))
                    command = b"disable\n"
                    if phase == "ready":
                        command = b"enable\n"
                    os.write(ctl_w, command)
                    perf_ack(ack_r, result)
                    if phase == "done" and index + 1 == args.warmups + args.samples:
                        result["worker_after"] = barrier_caller(child.pid, control_fd, control_inode, thread_record)
                        assert result["worker_after"]["tid"] == worker["tid"]
                        assert result["worker_after"]["starttime_ticks"] == worker["starttime_ticks"]
                        (folder / "maps-after.txt").write_text(Path(f"/proc/{child.pid}/maps").read_text())
                        (folder / "perf.map").write_bytes(Path(f"/tmp/perf-{child.pid}.map").read_bytes())
                        perf.send_signal(signal.SIGINT)
                        result["perf_exit_code"] = perf.wait(timeout=5)
                        assert result["perf_exit_code"] in (0, -signal.SIGINT)
                    parent.sendall(expected.replace("SWRSC1", "SWACK1", 1).encode())
            result["host_exit_code"] = child.wait(timeout=30)
        assert result["host_exit_code"] == 0
        report = json.loads((folder / "observations.json").read_text())
        assert report["profiling"]["nonce"] == nonce and report["profiling"]["windows"] == args.samples
        assert report["profiling"]["excluded_from_scored_cohorts"] is True
        assert report["program_wasm_sha256"] == baseline["program_wasm_sha256"]
        assert report["runtime"] == baseline["runtime"]
        assert report["configuration"] == baseline["configuration"]
        assert len(report["cases"]) == 1 and report["cases"][0]["exact_node_output_checked"] is True
        assert len(report["cases"][0]["observations"]) == args.samples + args.warmups
        assert report["cases"][0]["case"] == "rsc-" + args.mode
        result["source_fingerprint"] = report["source_fingerprint"]
        argv = [str(perf_binary), "script", "-i", str(folder / "perf.data"), "-F", "period,ip,sym,dso", "--no-inline", "--max-stack", "128"]
        with (folder / "samples.txt").open("xb") as out, (folder / "samples.stderr").open("xb") as err:
            parsed = subprocess.run(argv, cwd=ROOT, env=perf_env, stdin=subprocess.DEVNULL,
                                    stdout=out, stderr=err, timeout=20)
        assert parsed.returncode == 0
        symbolize(folder)
        result["status"] = "captured"
    except Exception as error:
        result["status"] = "failed"
        result["error"] = repr(error)
        raise
    finally:
        for process in (perf, child):
            if process is not None and process.poll() is None:
                process.kill()
                process.wait(timeout=5)
        parent.close()
        child_socket.close()
        for fd in fds:
            os.close(fd)
        result["resources_after"] = {name: (kernel_group() / name).read_text() for name in FIELDS}
        result["raw_files"] = {path.name: {"sha256": digest(path), "bytes": path.stat().st_size}
                               for path in folder.iterdir() if path.is_file()}
        save(folder / "receipt.json", result)
    print(json.dumps({"status": result["status"], "output": str(folder)}))


if __name__ == "__main__":
    main()
