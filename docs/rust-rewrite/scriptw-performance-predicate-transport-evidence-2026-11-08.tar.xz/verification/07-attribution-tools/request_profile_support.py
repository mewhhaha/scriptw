"""Bounded protocol helpers extracted unchanged from the archived diagnostic."""
import os
from pathlib import Path
import select
import time

def line(fd, timeout=15):
    result = b""
    deadline = time.monotonic() + timeout
    while not result.endswith(b"\n"):
        remaining = deadline - time.monotonic()
        if remaining <= 0 or not select.select([fd], [], [], remaining)[0]:
            raise RuntimeError("bounded control read timed out")
        byte = os.read(fd, 1)
        if not byte or len(result) >= 256:
            raise RuntimeError("invalid or closed control stream")
        result += byte
    return result.decode("ascii")

def thread_record(pid, tid):
    task = Path(f"/proc/{pid}/task/{tid}")
    stat = (task / "stat").read_text()
    return {"tid": tid, "comm": (task / "comm").read_text().strip(), "stat": stat,
            "starttime_ticks": int(stat[stat.rfind(")") + 2:].split()[19]),
            "status": (task / "status").read_text()}

def perf_ack(fd, result):
    # Some perf builds write the C string terminator after the documented line.
    # The first line reader leaves that terminator before the following ACK.
    raw = line(fd)
    result["events"].append({"kind": "perf_ack_raw", "hex": raw.encode().hex(), "monotonic_ns": time.monotonic_ns()})
    assert raw in ("ack\n", "\0ack\n"), repr(raw)
