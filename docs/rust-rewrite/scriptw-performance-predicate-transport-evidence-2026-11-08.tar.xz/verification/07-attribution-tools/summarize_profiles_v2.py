#!/usr/bin/env python3
"""Verify raw authenticated FP profiles and aggregate their period-weighted owners."""
import argparse
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-predicate-transport-20261108'
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'tools'))
from common import check_source


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def symbolize_again(folder):
    with tempfile.TemporaryDirectory(prefix='fp-symbolize-') as temp_name:
        temp = Path(temp_name)
        shutil.copyfile(folder / 'samples.txt', temp / 'samples.txt')
        shutil.copyfile(folder / 'perf.map', temp / 'perf.map')
        spec = importlib.util.spec_from_file_location('current_fp_symbolizer', TOOLS / 'symbolize_fp.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.symbolize(temp)
        return load(temp / 'callchains.json')


def merge_tables(rows, denominator=None):
    totals = collections.Counter()
    for row in rows:
        for item in row:
            totals[item['owner']] += item['period_sum']
    if denominator is None:
        denominator = sum(totals.values())
    return [{'owner': key, 'period_sum': value, 'sample_share': value / denominator if denominator else 0}
            for key, value in totals.most_common()]


def normalized_aggregates(value):
    # Inclusive/helper updates traverse sets. Equal-weight table order is not
    # deterministic across Python hash seeds; preserve every count and raw row.
    result = dict(value)
    for name in ['own', 'inclusive']:
        result[name] = sorted(value[name], key=lambda row: (-row['period_sum'], row['owner']))
    result['helper_immediate_callers'] = {
        owner: sorted(rows, key=lambda row: (-row['period_sum'], row['owner']))
        for owner, rows in value['helper_immediate_callers'].items()
    }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort', type=Path, action='append', required=True,
                        help='Fast/Speed and sync/async profile output directory; repeat four times')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert len(args.cohort) == 4
    cohorts = []
    fingerprint = None
    for source_path in args.cohort:
        source_path = source_path.resolve(strict=True)
        assert source_path.is_relative_to(BASE)
        plan = load(source_path / 'plan.json')
        assert plan['schema'] == 'scriptw-rsc-current-candidate-profile-plan-v1'
        assert plan['status'] == 'complete' and plan['unscored'] is True
        assert plan['samples_per_process'] == 100 and plan['processes'] == 3
        anchor = load(source_path / 'mode-anchor-report.json')
        assert sha(source_path / 'mode-anchor-report.json') == plan['anchor_report_sha256']
        assert anchor['source_fingerprint'] == plan['source_fingerprint']
        assert anchor['native_mode'] == plan['native_mode']
        source_manifest = Path(plan['source_manifest']).resolve(strict=True)
        check_source(source_manifest)
        assert sha(source_manifest) == plan['source_manifest_sha256']
        for pinned_path, expected_hash in plan['pins'].items():
            assert sha(pinned_path) == expected_hash, f'profile input changed: {pinned_path}'
        adaptation = plan['adaptation']
        assert adaptation['schema'] == 'scriptw-rsc-fp-candidate-adaptation-v1'
        assert adaptation['patch_sha256'] == sha(TOOLS / adaptation['patch_path'])
        assert adaptation['adapted_sampler_sha256'] == sha(TOOLS / 'profile_rsc_fp.py')
        assert adaptation['original_sampler_sha256'] == sha(ROOT / adaptation['original_sampler_path'])
        assert adaptation['original_adaptation_sha256'] == sha(ROOT / adaptation['original_adaptation_path'])
        if fingerprint is None:
            fingerprint = plan['source_fingerprint']
        assert plan['source_fingerprint'] == fingerprint
        planned_receipts = {row['path']: row for row in plan['process_receipts']}
        assert len(planned_receipts) == 3
        process_rows = []
        for profile in sorted(source_path.glob('process-*')):
            receipt_path = profile / 'receipt.json'
            receipt = load(receipt_path)
            report_path = profile / 'observations.json'
            report = load(report_path)
            relative_receipt = receipt_path.relative_to(source_path).as_posix()
            pinned_receipt = planned_receipts[relative_receipt]
            assert sha(receipt_path) == pinned_receipt['sha256']
            assert sha(report_path) == pinned_receipt['observations_sha256']
            assert receipt['status'] == 'captured' and receipt['host_exit_code'] == 0
            assert receipt['executable_sha256'] == plan['host_sha256']
            assert receipt['source_fingerprint'] == fingerprint == report['source_fingerprint']
            assert receipt['mode'] == plan['request_mode'] and receipt['samples'] == 100
            assert report['program_wasm_sha256'] == anchor['program_wasm_sha256']
            assert report['runtime'] == anchor['runtime'] and report['configuration'] == anchor['configuration']
            assert len(report['cases']) == 1 and report['cases'][0]['case'] == 'rsc-' + plan['request_mode']
            assert report['cases'][0]['exact_node_output_checked'] is True
            assert report['profiling']['windows'] == 100 and report['profiling']['nonce'] == receipt['nonce']
            auth = receipt['worker_before']['barrier_authentication']
            assert receipt['execution_target'] == 'authenticated-caller-socket'
            assert receipt['control_edges_included'] is True
            assert auth['socket_inode'] > 0 and auth['syscall']
            assert auth['socket_link'] == f"socket:[{auth['socket_inode']}]"
            assert receipt['worker_after']['tid'] == receipt['worker_before']['tid']
            assert receipt['worker_after']['starttime_ticks'] == receipt['worker_before']['starttime_ticks']
            for name, record in receipt['raw_files'].items():
                raw = profile / name
                assert raw.is_file() and raw.stat().st_size == record['bytes'] and sha(raw) == record['sha256']
            assert 'samples.txt' in receipt['raw_files'] and 'perf.map' in receipt['raw_files']
            recalculated = symbolize_again(profile)
            saved = load(profile / 'callchains.json')
            assert normalized_aggregates(recalculated) == normalized_aggregates(saved), 'stored counts or raw sample rows differ from replay'
            recalculated = normalized_aggregates(recalculated)
            assert recalculated['samples'] > 0 and recalculated['period_sum'] > 0
            process_rows.append({'path': profile.relative_to(BASE).as_posix(),
                                 'receipt_sha256': sha(receipt_path),
                                 'observations_sha256': sha(report_path),
                                 'samples_sha256': sha(profile / 'samples.txt'),
                                 'perf_map_sha256': sha(profile / 'perf.map'),
                                 'callchains_recomputed_from_raw': True,
                                 'aggregate_table_order_normalized': True,
                                 'callchains': {key: value for key, value in recalculated.items() if key != 'rows'}})
        assert len(process_rows) == 3
        cohorts.append({'native_mode': plan['native_mode'], 'request_mode': plan['request_mode'],
                        'plan_path': source_path.relative_to(BASE).as_posix(),
                        'plan_sha256': sha(source_path / 'plan.json'), 'processes': process_rows})

    summaries = []
    for cohort in cohorts:
        calls = [process['callchains'] for process in cohort['processes']]
        total_period = sum(item['period_sum'] for item in calls)
        own = merge_tables([item['own'] for item in calls], total_period)
        inclusive = merge_tables([item['inclusive'] for item in calls], total_period)
        helper_owners = sorted({owner for item in calls for owner in item['helper_immediate_callers']})
        callers = {}
        for owner in helper_owners:
            callers[owner] = merge_tables([
                item['helper_immediate_callers'].get(owner, []) for item in calls
            ], total_period)
        total_period = sum(item['period_sum'] for item in calls)
        summaries.append({'native_mode': cohort['native_mode'], 'request_mode': cohort['request_mode'],
                          'processes': len(calls), 'samples': sum(item['samples'] for item in calls),
                          'own_period_sum': total_period, 'own_leaf_period_weights': own,
                          'inclusive_caller_period_weights': inclusive,
                          'helper_immediate_caller_period_weights': callers,
                          'unavailable_ip_or_callchain_samples': sum(item['unavailable_ip_or_callchain_samples'] for item in calls),
                          'unavailable_ip_or_callchain_period_sum': sum(item['unavailable_ip_or_callchain_period_sum'] for item in calls)})
    assert {(item['native_mode'], item['request_mode']) for item in cohorts} == {
        ('fast', 'sync'), ('fast', 'async'), ('speed', 'sync'), ('speed', 'async')
    }
    output = args.output.resolve()
    assert output.is_relative_to(BASE) and not output.exists()
    output.parent.mkdir(parents=True, exist_ok=True)
    result = {'schema': 'scriptw-rsc-current-candidate-profile-summary-v1', 'status': 'complete',
              'unscored': True, 'source_fingerprint': fingerprint,
              'replay_order_policy': 'Sort only owner aggregate tables by period and owner before exact replay comparison; every raw sample, frame, count and other field stays unchanged.',
              'summarizer': {'path': str(Path(__file__)), 'sha256': sha(Path(__file__))},
              'cohorts': cohorts, 'summaries': summaries,
              'limits': 'Period-weighted user cycle samples, not exact calls, wall time, allocations, or speedup. Own leaf owners are disjoint; inclusive owners and helper caller rows overlap. Unresolved host symbols and unavailable callchains remain explicit and in the own-period denominator.'}
    output.write_text(json.dumps(result, indent=2) + '\n')
    print('PROFILE SUMMARY VERIFIED', output)


if __name__ == '__main__':
    main()
