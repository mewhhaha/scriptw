"""Fresh excluded caller profiles, after the serial scored/acceptance batch."""
from pathlib import Path
import subprocess,sys
ROOT=Path.cwd();BASE=ROOT/'target/performance-predicate-transport-20261108';sys.path.insert(0,str(BASE/'tools'))
from common import check_source,read
assert read(BASE/'final-batch.json')['complete'];check_source(BASE/'tools/source-current/manifest.json')
cohorts=[]
for native in ['fast','speed']:
 for request in ['sync','async']:
  out=BASE/'fresh-profiles'/(native+'-'+request);cohorts.append(out)
  subprocess.run([sys.executable,'-B',str(BASE/'attribution-tools/profile_candidate.py'),'--campaign',str(BASE/'tools/rsc-campaign-1/campaign.json'),'--native-mode',native,'--request-mode',request,'--output',str(out)],check=True)
argv=[sys.executable,'-B',str(BASE/'attribution-tools/summarize_profiles.py')]
for cohort in cohorts:argv+=['--cohort',str(cohort)]
argv+=['--output',str(BASE/'fresh-profiles/summary.json')]
subprocess.run(argv,check=True)
