"""Run the final measurement/acceptance batch in a single serial capped tree."""
import json,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-predicate-transport-20261108';py=[sys.executable,'-B']
sys.path[:0]=[str(BASE/'tools'),str(ROOT/'scripts')]
from common import check_source,digest,save
from limited_verification import require_kernel_budget,limited_environment
from measure_rsc import resources,check_resources
require_kernel_budget(4*1024**3);source=BASE/'tools/source-current/manifest.json';check_source(source)
phases=[
 ('focused',py+[str(BASE/'verify_native.py'),'--phase','focused']),
 ('rsc',py+[str(BASE/'run_rsc.py')]),
 ('broad',py+[str(BASE/'verify_native.py'),'--phase','broad']),
 ('situations',py+['scripts/benchmark-situations.py','--host',str(BASE/'frozen/compiler_precompiled_baseline'),'--producer-log',str(BASE/'build.stdout'),'--producer-receipt',str(BASE/'frozen/compiler_precompiled_baseline-producer.json'),'--fixtures','target/performance-levers-20261108/situations-full-1/sources','--output',str(BASE/'situations-full'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--time','target/performance-worker-cpu/tools/time']),
 ('diagnostics',py+[str(BASE/'diagnostics.py'),'--phase','all','--source',str(source),'--campaign',str(BASE/'tools/rsc-campaign-1/campaign.json'),'--output',str(BASE/'final-diagnostics')]),
 ('cli',py+[str(BASE/'verify_cli.py')]),
 ('features',py+[str(BASE/'audit_example_features.py')]),
]
report={'complete':False,'source_manifest_sha256':digest(source),'phases':[],'resources_before':resources()};save(BASE/'final-batch.json',report)
try:
 for name,argv in phases:
  print('START',name,flush=True);check_source(source);row={'name':name,'argv':argv,'resources_before':resources()};report['phases'].append(row);save(BASE/'final-batch.json',report);started=time.monotonic_ns()
  with (BASE/(name+'.stdout')).open('xb') as so,(BASE/(name+'.stderr')).open('xb') as se:
   run=subprocess.run(argv,env=limited_environment(),cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=5400)
  row.update(exit_code=run.returncode,elapsed_ns=time.monotonic_ns()-started,resources_after=resources());row.update({suffix+'_sha256':digest(BASE/(name+'.'+suffix)) for suffix in ['stdout','stderr']});save(BASE/'final-batch.json',report);check_resources(row['resources_before'],row['resources_after']);check_source(source);assert run.returncode==0,name;print('END',name,flush=True)
 report['complete']=True
finally:
 report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after']);check_source(source);save(BASE/'final-batch.json',report)
