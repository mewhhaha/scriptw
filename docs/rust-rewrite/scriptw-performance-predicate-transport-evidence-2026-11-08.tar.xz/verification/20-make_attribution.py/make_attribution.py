"""Stage fresh v6 request diagnostics; keep historical leaf sampling under its original compiler identity."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path[:0] = [str(BASE / 'tools'), str(ROOT / 'scripts')]
from common import digest, read, save, validate_snapshot
from limited_verification import require_kernel_budget

EVENTS = ['cycles:u', 'instructions:u', 'branches:u', 'branch-misses:u']
TARGETS = ['builtin::Object.prototype.hasOwnProperty', 'helper::ordinary_own_descriptor', 'helper::value_to_property_key', 'helper::dynamic_property_read']
CONTROLS = [('direct', [37, 0]), ('indirect', [17, 0]), ('recursive', [66, 0]),
            ('tail', [13, 13]), ('two_addresses', [24, 17]), ('zero', [0, 0]),
            ('disabled', [0, 0]), ('burst', [4096, 0])]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--aggregate', type=Path, required=True)
    parser.add_argument('--diagnostics', type=Path, required=True, help='combined baseline/candidate census and 18-process PMU campaign')
    parser.add_argument('--historical-attribution', type=Path, default=ROOT / 'docs/rust-rewrite/react-attribution-current.json')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--docs', action='store_true', help='also stage source_fingerprint/markdown JSON')
    args = parser.parse_args()
    require_kernel_budget(4 * 1024**3)
    bound = {}

    def bind(path, expected=None):
        path = Path(path).resolve(strict=True)
        actual = digest(path)
        if expected is not None:
            assert actual == expected, f'changed input: {path}'
        assert str(path) not in bound or bound[str(path)] == actual, f'input changed during read: {path}'
        bound[str(path)] = actual
        return {'path': str(path), 'sha256': actual}

    def load(path, expected=None):
        bind(path, expected)
        return read(path)

    def resources(receipt):
        before, after = receipt['resources_before'], receipt['resources_after']
        assert 0 < int(before['memory.max']) <= 4 * 1024**3
        assert before['memory.swap.max'].strip() == '0' and before['memory.oom.group'].strip() == '1'
        for key in ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max']:
            if key in after:
                assert before[key].strip() == after[key].strip(), key
        events = [dict(line.split() for line in value['memory.events'].splitlines()) for value in [before, after]]
        assert all(events[0].get(key) == events[1].get(key) for key in ['oom', 'oom_kill', 'oom_group_kill'])

    def identity_matches(observed, identity):
        for key, expected in identity.items():
            assert observed[key] == expected, key

    source_path = args.source_manifest.resolve(strict=True)
    manifest = validate_snapshot(source_path)
    source_record = bind(source_path)
    campaign_path = args.campaign.resolve(strict=True)
    campaign = load(campaign_path)
    aggregate = load(args.aggregate)
    assert campaign['status'] == 'complete'
    assert aggregate['measurement']['campaign_sha256'] == digest(campaign_path)
    assert aggregate['source_manifest_sha256'] == campaign['source_manifest_sha256'] == digest(source_path)
    assert manifest['runtime_abi'] == campaign['runtime_abi'] == aggregate['runtime_abi']
    policy = campaign['policy']
    assert len(campaign['processes']) == len(policy['actors']) * policy['blocks'] * policy['processes_per_actor_per_block']
    assert all(row['status'] == 'complete' for row in campaign['processes'])
    identities = {actor: aggregate['engines'][actor]['identity'] for actor in ['baseline', 'candidate', 'candidate-speed']}
    current = identities['candidate']
    fingerprint = current['source_fingerprint']
    assert current['executable_sha256'] == campaign['candidate']['sha256']
    assert current['native_mode'] == 'fast' and identities['candidate-speed']['native_mode'] == 'speed'
    for field in ['source_fingerprint', 'executable_sha256', 'inputs', 'program_wasm_sha256', 'runtime']:
        assert current[field] == identities['candidate-speed'][field], field
    assert identities['candidate-speed']['configuration'] == dict(
        current['configuration'], cranelift_opt_level='Speed', register_allocation='Backtracking')
    bind(campaign['candidate']['path'], current['executable_sha256'])
    bind(campaign['node']['path'], campaign['node']['sha256'])
    references = {}
    for actor in ['baseline', 'candidate', 'candidate-speed']:
        row = next(row for row in campaign['processes'] if row['engine'] == actor)
        path = campaign_path.parent / row['report']
        expected = row['report_sha256']
        reference = load(path, expected)
        identity_matches(reference, identities[actor])
        references[actor] = (path, reference)
    for field in ['source', 'support']:
        bind(current['inputs'][field], current['inputs'][field + '_sha256'])
    assert identities['baseline']['inputs'] == current['inputs']
    support = load(current['inputs']['support'], current['inputs']['support_sha256'])

    def diagnostic(folder, expected_fingerprint):
        folder = Path(folder).resolve(strict=True)
        value = load(folder / 'campaign.json')
        assert value['complete'] and value['status'] == 'complete' and value['unscored']
        assert value['source_fingerprint'] == expected_fingerprint
        for path, expected in value['pins'].items():
            bind(path, expected)
        assert value['pins'][str(source_path)] == digest(source_path)
        resources(value)
        return folder, value

    diagnostics_dir, diagnostics_campaign = diagnostic(args.diagnostics, fingerprint)
    assert diagnostics_campaign['phase'] == 'all'
    census_campaign = diagnostics_campaign
    pmu_campaign = diagnostics_campaign

    def receipt(folder, row, diagnostics):
        assert row['status'] == 'complete' and row['exit_code'] == 0
        path = (folder / row['name'] / 'receipt.json').resolve(strict=True)
        # Current orchestrators pin receipt hashes in pins, not in run rows.
        value = load(path, diagnostics['pins'][str(path)])
        assert value['status'] in ['complete', 'captured']
        assert value.get('host_exit_code', value.get('exit_code')) == 0
        resources(value)
        for name, record in value['raw_files'].items():
            bind(path.parent / name, record['sha256'])
        return path, value

    def controls(path, expected_driver):
        value = load(path)
        assert value['complete'] and value['status'] == 'complete' and value['known_count_windows'] == 8
        assert value['driver_sha256'] == expected_driver
        assert len(value['windows']) == 8
        for index, (name, expected) in enumerate(CONTROLS):
            window = value['windows'][index]
            assert window['index'] == index and window['name'] == name
            assert [event['count'] for event in window['events']] == expected
            assert all(event['time_enabled_ns'] == event['time_running_ns'] for event in window['events'])
        resources(value)
        for name, record in value['raw_files'].items():
            bind(Path(path).parent / name, record['sha256'])
        assert load(Path(path).parent / 'observations.json') == {'complete': True, 'windows': 8, 'checksums_checked': 8}
        return value

    def observations(path, count, mode, identity=None):
        value = load(path)
        assert value['profiling']['excluded_from_scored_cohorts'] and value['profiling']['windows'] == count
        assert len(value['cases']) == 1
        case = value['cases'][0]
        assert case['case'] == 'rsc-' + mode and case['exact_node_output_checked']
        assert case['samples'] == count and case['warmups'] == 3
        assert len(case['observations']) == count + 3
        for index, observation in enumerate(case['observations']):
            assert observation['index'] == index and observation['warmup'] == (index < 3)
        golden = next(case for case in references['candidate'][1]['cases'] if case['case'] == 'rsc-' + mode)
        if identity is not None:
            assert all(case[key] == golden[key] for key in ['expected_json_sha256', 'expected_json_bytes'])
            identity_matches(value, identity)
        else:
            expected = support['expected']['rsc-' + mode].encode()
            assert expected.endswith(b'\n')
            assert hashlib.sha256(expected[:-1]).hexdigest() == golden['expected_json_sha256']
            assert len(expected) - 1 == golden['expected_json_bytes']
            for observation in case['observations']:
                assert observation['kind'] == 'flight' and observation['exact_golden_output_checked']
                assert observation['output_sha256'] == hashlib.sha256(expected).hexdigest()
                assert observation['output_bytes'] == len(expected)
        return value

    pmu_rows = [row for row in pmu_campaign['runs'] if row['kind'] == 'pmu']
    assert len(pmu_rows) == 18
    assert {(row['actor'], row['mode'], row['repetition']) for row in pmu_rows} == {
        (actor, mode, repetition) for actor in ['fast', 'speed', 'v8'] for mode in ['sync', 'async'] for repetition in range(3)}
    pmu = {actor: {mode: {'process_medians': []} for mode in ['sync', 'async']} for actor in ['fast', 'speed', 'v8']}
    for row in pmu_rows:
        path, value = receipt(diagnostics_dir, row, pmu_campaign)
        actor, mode = row['actor'], row['mode']
        reference_actor = 'candidate'
        if actor == 'speed':
            reference_actor = 'candidate-speed'
        reference_path, reference = references[reference_actor]
        assert value['baseline_report_sha256'] == digest(reference_path)
        assert value['samples'] == 100 and value['warmups'] == 3 and not value['empty_window_calibration']
        assert value['mode'] == mode and value['control_edges_included']
        assert value['source_sha256'] == current['inputs']['source_sha256']
        assert value['support_sha256'] == current['inputs']['support_sha256']
        if actor == 'v8':
            assert value['engine'] == 'node' and value['executable_sha256'] == campaign['node']['sha256']
            observed = observations(path.parent / 'observations.json', 100, mode)
            assert observed['main_thread_pid'] == value['pid']
            assert all(observed['inputs'][key] == current['inputs'][key]
                       for key in ['source_sha256', 'support_sha256', 'adapted_source_sha256'])
        else:
            assert value['engine'] == 'scriptw' and value['executable_sha256'] == current['executable_sha256']
            assert value['actual_configuration'] == reference['configuration']
            observations(path.parent / 'observations.json', 100, mode, identities[reference_actor])
        assert len(value['windows']) == 100
        for index, window in enumerate(value['windows'], 3):
            assert window['index'] == index and window['time_enabled_ns'] == window['time_running_ns'] > 0
            assert set(window['raw_counts']) == set(EVENTS)
            assert all(type(number) is int and number >= 0 for number in window['raw_counts'].values())
        pmu[actor][mode]['process_medians'].append({'repetition': row['repetition'], 'receipt': bind(path),
            'median_raw_counts_per_request': {event: statistics.median(window['raw_counts'][event] for window in value['windows']) for event in EVENTS}})
    for actor in pmu.values():
        for result in actor.values():
            result['process_medians'].sort(key=lambda row: row['repetition'])
            result['median_raw_counts_per_request'] = {event: statistics.median(
                row['median_raw_counts_per_request'][event] for row in result['process_medians']) for event in EVENTS}

    control_rows = [row for row in census_campaign['runs'] if row['kind'] == 'control']
    assert {(row['actor'], row['mode']) for row in control_rows} == {('baseline', 'control'), ('candidate', 'control')}
    controls_by_actor = {}
    for row in control_rows:
        path, value = receipt(diagnostics_dir, row, census_campaign)
        assert value['driver_sha256']
        controls(path, value['driver_sha256'])
        controls_by_actor[row['actor']] = (path, value)
    old_control_path, old_control = controls_by_actor['baseline']
    new_control_path, new_control = controls_by_actor['candidate']
    assert new_control['driver_sha256'] == old_control['driver_sha256']
    assert new_control['kernel_boot_id'] == old_control['kernel_boot_id']

    counts = {}
    for mode in ['sync', 'async']:
        old_rows = [row for row in census_campaign['runs']
                    if row['kind'] == 'census' and row['actor'] == 'baseline' and row['mode'] == mode]
        new_rows = [row for row in census_campaign['runs']
                    if row['kind'] == 'census' and row['actor'] == 'candidate' and row['mode'] == mode]
        assert len(old_rows) == len(new_rows) == 1
        old_path, old = receipt(diagnostics_dir, old_rows[0], census_campaign)
        new_path, new = receipt(diagnostics_dir, new_rows[0], census_campaign)
        for path, value, identity, reference_actor, control_path in [
            (old_path, old, identities['baseline'], 'baseline', old_control_path),
            (new_path, new, current, 'candidate', new_control_path)]:
            assert value['complete'] and value['status'] == 'complete' and value['targets'] == TARGETS
            assert value['exit_code'] == 0 and value['mode'] == mode
            assert [entry['name'] for entry in value['entries']] == TARGETS
            assert value['source_fingerprint'] == identity['source_fingerprint']
            assert value['binary_sha256'] == identity['executable_sha256']
            assert value['program_wasm_sha256'] == identity['program_wasm_sha256']
            assert value['runtime'] == identity['runtime']
            assert value['baseline_sha256'] == digest(references[reference_actor][0])
            assert value['controls_receipt_sha256'] == digest(control_path)
            assert value['driver_sha256'] == old_control['driver_sha256']
            assert value['execution_target'] == 'authenticated-caller-socket' and len(value['windows']) == 7
            resources(value)
            for name, record in value['raw_files'].items():
                bind(path.parent / name, record['sha256'])
            observed = observations(path.parent / 'observations.json', 7, mode, identity)
            assert observed['profiling']['nonce'] == value['nonce']
            for index, window in enumerate(value['windows'], 3):
                assert window['index'] == index and len(window['events']) == len(TARGETS)
                assert all(event['time_enabled_ns'] == event['time_running_ns'] > 0 for event in window['events'])
                assert all(type(event['count']) is int and event['count'] >= 0 for event in window['events'])
        counts[mode] = []
        for index, target in enumerate(TARGETS):
            before = [window['events'][index]['count'] for window in old['windows']]
            after = [window['events'][index]['count'] for window in new['windows']]
            prior, present = statistics.median(before), statistics.median(after)
            counts[mode].append({'name': target, 'baseline_2255_per_request': prior,
                                 'candidate_per_request': present, 'delta': present - prior,
                                 'baseline_windows': before, 'candidate_windows': after,
                                 'baseline_receipt': bind(old_path), 'candidate_receipt': bind(new_path)})

    historical_path = args.historical_attribution.resolve(strict=True)
    historical = load(historical_path)
    old_fingerprint = historical['sampling']['historical']['source_fingerprint']
    assert old_fingerprint.startswith('5aa48ad8') and old_fingerprint != fingerprint
    historical_leaf = historical['sampling']['historical']
    archive = historical_leaf['archive']
    archive_record = bind(archive['path'], archive['sha256'])
    historical_member = 'reports/react-attribution-current.json'
    with tarfile.open(archive['path'], 'r:xz') as packed:
        index = json.load(packed.extractfile('INDEX.json'))
        member_hashes = {row['path']: row['sha256'] for row in index['members']}
        assert historical_member in member_hashes
        raw_historical = packed.extractfile(historical_member).read()
        assert hashlib.sha256(raw_historical).hexdigest() == member_hashes[historical_member]
        archived_historical = json.loads(raw_historical)
    assert archived_historical['schema'] == 'scriptw-react-attribution-current-v4'
    assert archived_historical['candidate_identity']['source_fingerprint'] == old_fingerprint
    historical_report = {'archive': archive_record, 'member': historical_member,
                         'sha256': member_hashes[historical_member],
                         'source_fingerprint': old_fingerprint}
    report = {'schema': 'scriptw-react-attribution-current-v6', 'date': aggregate['date'], 'status': 'captured',
              'excluded_from_scored_cohorts': True, 'source_manifest': source_record,
              'candidate_identity': current, 'baseline_identity': identities['baseline'],
              'scored_rsc_evidence': {'campaign': bind(campaign_path), 'aggregate': bind(args.aggregate)},
              'diagnostic_campaign': bind(diagnostics_dir / 'campaign.json'),
              'pmu': {'processes': 18, 'processes_per_actor_mode': 3, 'samples_per_process': 100, 'warmups': 3,
                      'events': EVENTS, 'minimum_running_fraction': 1, 'actors': pmu,
                      'policy': 'Median of three process medians of raw user-only kernel counts. No multiplex scaling. Caller/main TID only; control edges included; setup, warmups, encoding and exact checks excluded. Speed changes optimization and register allocation together.'},
              'helper_entry_counts': {'targets': TARGETS, 'baseline_source_fingerprint': identities['baseline']['source_fingerprint'],
                      'candidate_source_fingerprint': fingerprint, 'processes': 4, 'processes_per_compiler_mode': 1,
                      'windows_per_process': 7, 'warmups': 3, 'known_entry_control_windows': 16, 'modes': counts,
                      'policy': 'Same-driver authenticated hardware entry counters with fresh controls for the 2255 baseline and current candidate. Target populations overlap; report each target separately and do not sum them into source entries, calls, allocations or extents.'},
              'sampling': {'fresh': False, 'historical': {'source_fingerprint': old_fingerprint,
                      'report': historical_report, 'archive': archive_record,
                      'scope': 'Archived 5aa compiler leaf sampling only; not refreshed or relabelled for the current compiler.'}},
              'physical_allocation_census': {'fresh': False},
              'limits': ['No fresh leaf sampling or physical allocation census.',
                         'Counters and entry instrumentation perturb execution; profiled timings are not scored.',
                         'Per-target instrumentation overlaps; these counts do not identify allocation origins or causal removable time.',
                         'No fresh old-compiler PMU cohort is claimed; Fast/Speed/V8 PMU data all come from the final diagnostic campaign.'],
              'verification': {'inputs': bound, 'created_at': datetime.now(timezone.utc).isoformat()}}
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists(), 'stage to a new ignored target directory'
    validate_snapshot(source_path)
    for path, expected in list(bound.items()):
        assert digest(path) == expected, f'input changed before staging: {path}'
    output.mkdir(parents=True)
    save(output / 'react-attribution-current.json', report)
    if args.docs:
        lines = [f'Fresh request counters for compiler `{fingerprint[:12]}`. Values are unscored diagnostics.', '',
                 '| Mode | Actor | Cycles/request | Instructions/request | Branches/request | Branch misses/request |',
                 '| --- | --- | ---: | ---: | ---: | ---: |']
        for mode in ['sync', 'async']:
            for actor in ['fast', 'speed', 'v8']:
                values = pmu[actor][mode]['median_raw_counts_per_request']
                lines.append('| ' + mode + ' | ' + actor + ' | ' + ' | '.join(f'{values[event]:,.1f}' for event in EVENTS) + ' |')
        lines += ['', '| Mode | Instrumented target | Baseline 2255/request | Candidate/request |',
                  '| --- | --- | ---: | ---: |']
        for mode, rows in counts.items():
            for row in rows:
                lines.append(f"| {mode} | `{row['name']}` | {row['baseline_2255_per_request']:,.0f} | {row['candidate_per_request']:,.0f} |")
        lines += ['', 'Per-target builtin/helper populations overlap. Do not add them into a total source-entry, call, allocation, or extent count.', '',
                  'The older leaf samples remain historical source `' + old_fingerprint[:12] + '` evidence in archived member `' + historical_member + '` from `' + Path(archive['path']).name + '`. They do not describe the current candidate or 2255 baseline.', '',
                  'Fast/Speed/V8 PMU windows use raw nonmultiplexed caller/main-thread counters. Speed combines optimization and register allocation changes. No fresh leaf sampling or physical allocation census.']
        save(output / 'docs-snippet.json', {'source_fingerprint': fingerprint, 'markdown': '\n'.join(lines) + '\n'})
    print('STAGED FRESH V6 ATTRIBUTION', output, flush=True)


if __name__ == '__main__':
    main()
