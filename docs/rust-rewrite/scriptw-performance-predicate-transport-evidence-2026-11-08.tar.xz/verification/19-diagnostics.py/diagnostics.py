"""Excluded source-entry census and raw PMU windows for the measured candidate."""
import argparse
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
TOOLS = ROOT / 'target/rsc-attribution-20261107/tools'
sys.path[:0] = [str(BASE / 'tools'), str(ROOT / 'scripts')]
from common import check_source, digest, read, save
from limited_verification import limited_environment, require_kernel_budget
from measure_rsc import resources, check_resources

TARGETS = ['builtin::Object.prototype.hasOwnProperty', 'helper::ordinary_own_descriptor', 'helper::value_to_property_key', 'helper::dynamic_property_read']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=['all', 'census', 'pmu'], default='census')
    parser.add_argument('--source', type=Path, default=BASE / 'tools/source-current/manifest.json')
    parser.add_argument('--campaign', type=Path, default=BASE / 'tools/rsc-campaign-1/campaign.json')
    parser.add_argument('--fingerprint', help='optional exact candidate compiler fingerprint assertion')
    parser.add_argument('--output', type=Path, default=BASE / 'candidate-diagnostics-1')
    args = parser.parse_args()
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    source = args.source.resolve(strict=True)
    check_source(source)
    campaign_path = args.campaign.resolve(strict=True)
    campaign = read(campaign_path)
    assert campaign['status'] == 'complete', 'finish the scored cohort first'
    policy = campaign['policy']
    expected_processes = len(policy['actors']) * policy['blocks'] * policy['processes_per_actor_per_block']
    assert len(campaign['processes']) == expected_processes
    assert all(row['status'] == 'complete' for row in campaign['processes'])
    assert digest(source) == campaign['source_manifest_sha256']
    binary = Path(campaign['candidate']['path']).resolve(strict=True)
    assert digest(binary) == campaign['candidate']['sha256']
    node = Path(campaign['node']['path'])
    assert digest(node) == campaign['node']['sha256']
    references = {}
    selected_actors = ['candidate']
    if args.phase in ['all', 'census']:
        selected_actors.append('baseline')
    if args.phase in ['all', 'pmu']:
        selected_actors.append('candidate-speed')
    for actor in selected_actors:
        row = next(row for row in campaign['processes'] if row['engine'] == actor and row['status'] == 'complete')
        reference = campaign_path.parent / row['report']
        assert digest(reference) == row['report_sha256']
        value = read(reference)
        assert value['source_fingerprint'] == row['identity']['source_fingerprint']
        expected_host = binary
        if actor == 'baseline':
            expected_host = Path(campaign['baseline']['path'])
        assert value['executable_sha256'] == digest(expected_host)
        references[actor] = reference
    fast = read(references['candidate'])
    fingerprint = fast['source_fingerprint']
    assert len(fingerprint) == 64 and all(character in '0123456789abcdef' for character in fingerprint)
    if args.fingerprint is not None:
        assert fingerprint == args.fingerprint
    assert fast['native_mode'] == 'fast'
    if 'candidate-speed' in references:
        speed = read(references['candidate-speed'])
        assert speed['native_mode'] == 'speed'
        for field in ['inputs', 'program_wasm_sha256', 'runtime', 'source_fingerprint', 'executable_sha256']:
            assert fast[field] == speed[field], field
        expected_speed = dict(fast['configuration'], cranelift_opt_level='Speed', register_allocation='Backtracking')
        assert speed['configuration'] == expected_speed
    original = ROOT / 'target/performance-v8-climb-20261104/entry-breakpoints-staged'
    paths = [Path(__file__), source, campaign_path, campaign_path.parent / 'aggregate.json', binary, node,
             Path(campaign['candidate']['cargo_producer']),
             BASE / 'tools/common.py', BASE / 'tools/measure_rsc.py', ROOT / 'scripts/limited_verification.py',
             *references.values(), *(Path(fast['inputs'][key]) for key in ['source', 'support'])]
    assert digest(campaign['candidate']['cargo_producer']) == campaign['candidate']['cargo_producer_sha256']
    reuse = campaign['candidate'].get('qualified_reuse')
    if reuse is not None:
        assert digest(reuse['path']) == reuse['sha256']
        paths.append(Path(reuse['path']))
    paths.append(Path(campaign['baseline']['path']))
    paths += [TOOLS / name for name in ['count_source_entries.py', 'count_source_entries.adaptation.json',
              'count_request_pmu.py', 'request_profile_support.py', 'profile_thread.py', 'node_request_profile.v2.cjs']]
    paths += [original / name for name in ['prepared.json', 'control-producer.json', 'controls',
              'controls.rs', 'build_controls.py', 'count_entries.py']]
    pins = {str(path.resolve(strict=True)): digest(path) for path in paths}
    output = args.output.resolve()
    assert output.is_relative_to(BASE)
    output.mkdir(exist_ok=False)
    report = {'schema': 'scriptw-levers-candidate-diagnostics-v1', 'complete': False, 'status': 'running',
              'unscored': True, 'phase': args.phase, 'source_fingerprint': fingerprint,
              'pins': pins, 'targets': TARGETS, 'references': {actor: str(path) for actor, path in references.items()},
              'runs': [], 'resources_before': resources(),
              'limits': 'Separate excluded diagnostics, never profiled timings as scores. Source-entry counts '
              'are attempted canonical native entries, include tail entries and overlap helper counts; no allocation inference. '
              'PMU covers only authenticated caller/Node main TID including control edges, excluding background threads. '
              'Fast and Speed use identical source/P/R; Speed combines OptLevel::Speed and Backtracking. '
              'Raw kernel counts only; multiplexed windows fail admission.'}

    def checkpoint():
        save(output / 'campaign.json', report)

    def unchanged():
        check_source(source)
        for path, expected in pins.items():
            assert digest(path) == expected, 'changed diagnostic input: ' + path

    def invoke(kind, name, argv, **metadata):
        row = dict(kind=kind, name=name, argv=argv, status='running', **metadata)
        report['runs'].append(row)
        checkpoint()
        started = time.monotonic_ns()
        print('START', name, flush=True)
        try:
            unchanged()
            row['resources_before'] = resources()
            with (output / (name + '.stdout')).open('xb') as stdout, (output / (name + '.stderr')).open('xb') as stderr:
                child = subprocess.run(argv, cwd=ROOT, env=limited_environment(), stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, timeout=650)
            row['exit_code'] = child.returncode
            assert child.returncode == 0, name
            receipt = read(output / name / 'receipt.json')
            assert receipt['status'] in ['complete', 'captured'], name
            if kind == 'control':
                assert receipt['complete'] and receipt['known_count_windows'] == 8
            elif kind == 'census':
                assert receipt['complete'] and len(receipt['windows']) == 7 and receipt['targets'] == TARGETS
                assert receipt['source_fingerprint'] == metadata['source_fingerprint']
                row['median_entries'] = {target: statistics.median(w['events'][index]['count'] for w in receipt['windows'])
                                         for index, target in enumerate(TARGETS)}
            else:
                windows = receipt['windows']
                assert len(windows) == 100
                assert all(w['time_enabled_ns'] == w['time_running_ns'] > 0 for w in windows)
                row['raw_kernel_median_counts'] = {event: statistics.median(w['raw_counts'][event] for w in windows)
                                                   for event in windows[0]['raw_counts']}
            row['status'] = 'complete'
        except BaseException as error:
            row.update(status='failed', error=repr(error))
            raise
        finally:
            row['elapsed_ns'] = time.monotonic_ns() - started
            row['resources_after'] = resources()
            try:
                unchanged()
                if 'resources_before' in row:
                    check_resources(row['resources_before'], row['resources_after'])
            except BaseException as error:
                row.update(status='failed', terminal_verification_error=repr(error))
                raise
            finally:
                for path in [output / name / 'receipt.json', output / name / 'observations.json',
                             output / (name + '.stdout'), output / (name + '.stderr')]:
                    if path.exists():
                        pins[str(path)] = digest(path)
                checkpoint()
        print('END', name, flush=True)

    checkpoint()
    try:
        if args.phase in ['all', 'census']:
            for actor in ['baseline', 'candidate']:
                host = binary
                if actor == 'baseline':
                    host = Path(campaign['baseline']['path'])
                reference = references[actor]
                expected_fingerprint = read(reference)['source_fingerprint']
                for mode in ['control', 'sync', 'async']:
                    name = 'entries-' + actor + '-' + mode
                    argv = [sys.executable, '-B', str(TOOLS / 'count_source_entries.py'), '--mode', mode,
                            '--binary', str(host), '--baseline-json', str(reference), '--output', str(output / name)]
                    kind = 'control'
                    if mode != 'control':
                        kind = 'census'
                        argv += ['--samples', '7', '--controls-receipt', str(output / ('entries-' + actor + '-control') / 'receipt.json')]
                        for target in TARGETS:
                            argv += ['--target', target]
                    invoke(kind, name, argv, mode=mode, actor=actor, source_fingerprint=expected_fingerprint)

        if args.phase in ['all', 'pmu']:
            for repetition in range(3):
                actors = ['fast', 'speed', 'v8']
                actors = actors[repetition:] + actors[:repetition]
                for mode in ['sync', 'async']:
                    for actor in actors:
                        name = f'pmu-{actor}-{mode}-{repetition}'
                        reference = references['candidate']
                        engine = 'scriptw'
                        if actor == 'speed':
                            reference = references['candidate-speed']
                        if actor == 'v8':
                            engine = 'node'
                        argv = [sys.executable, '-B', str(TOOLS / 'count_request_pmu.py'), str(output / name),
                                '--engine', engine, '--mode', mode, '--binary', str(binary), '--node', str(node),
                                '--baseline-json', str(reference), '--samples', '100', '--warmups', '3']
                        if actor == 'speed':
                            argv += ['--native-mode', 'speed']
                        invoke('pmu', name, argv, actor=actor, mode=mode, repetition=repetition)
            report['raw_kernel_process_medians'] = {
                mode: {actor: {event: statistics.median(row['raw_kernel_median_counts'][event]
                    for row in report['runs'] if row['kind'] == 'pmu' and row['mode'] == mode and row['actor'] == actor)
                    for event in ['cycles:u', 'instructions:u', 'branches:u', 'branch-misses:u']}
                    for actor in ['fast', 'speed', 'v8']} for mode in ['sync', 'async']}
        unchanged()
        check_resources(report['resources_before'], resources())
        report.update(complete=True, status='complete')
    except BaseException as error:
        report.update(status='failed', error=repr(error))
        raise
    finally:
        report['resources_after'] = resources()
        checkpoint()
    print('CANDIDATE DIAGNOSTICS COMPLETE', output, flush=True)


if __name__ == '__main__':
    main()
