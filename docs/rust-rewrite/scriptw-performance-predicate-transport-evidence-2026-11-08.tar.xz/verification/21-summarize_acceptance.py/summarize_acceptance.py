"""Summarize completed receipts for the existing documentation renderer."""
import json,sys
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-predicate-transport-20261108'
sys.path[:0]=[str(BASE/'tools')]
from common import check_source,digest,read,save
source=BASE/'tools/source-current/manifest.json';check_source(source)
batch=read(BASE/'final-batch.json');assert batch['complete']
broad=read(BASE/'broad/receipt.json');assert broad['complete'] and len(broad['runs'])==13
passed=0
for row in broad['runs']:
 assert row['exit_code']==0 and len(row['summary'])==1
 status,count,failed,ignored,measured,filtered=row['summary'][0]
 assert status=='ok' and failed==ignored==measured==filtered=='0' and int(count)==row['inventory']
 passed+=int(count)
guards=read(BASE/'source-guards/receipt.json');assert guards['finished'] and guards['passed'];guard_count=0
for row in guards['targets']:
 receipt=read(BASE/'source-guards'/row['receipt']);assert receipt['passed'] and receipt['exit_code']==0
 status,count,failed,ignored,measured,filtered=receipt['result_summaries'][0]
 assert status=='ok' and failed==ignored==measured==filtered=='0' and int(count)==len(receipt['test_inventory'])
 guard_count+=int(count)
cli=read(BASE/'production-cli/receipt.json');assert cli['complete'] and cli['passed'] and cli['cli_smoke_passed'] and cli['passed_smokes']==9
cheap=read(BASE/'source-checks/receipt.json');assert cheap['complete'] and len(cheap['format_files'])==11 and len(cheap['stale_intl_recipes'])==14
rsc=read(BASE/'tools/rsc-campaign-1/aggregate.json');situations=read(BASE/'situations-full/report.json');assert situations['complete']
fp=rsc['engines']['candidate']['identity']['source_fingerprint'];assert fp==situations['source_identity']['source_fingerprint']
result={'schema':'scriptw-performance-predicate-transport-coverage-v1','date':rsc['date'],'source_fingerprint':fp,'source_manifest_sha256':digest(source),'private_unit_suites_rerun':False,'full_workspace_ci_rerun':False,'full_test262_rerun':False,'scopes':{'broad':{'passed':passed,'scopes':13,'scope_names':[row['target'] for row in broad['runs']]},'source_guards':{'passed':guard_count},'production_cli':{'passed':9}},'owned_existing_failures':{'format_files':cheap['format_files'],'stale_intl_recipes':cheap['stale_intl_recipes'],'aot_private_unit_assertions':4,'aot_units_rerun':False},'receipts':{str(p.relative_to(ROOT)):digest(p) for p in [BASE/'final-batch.json',BASE/'broad/receipt.json',BASE/'source-guards/receipt.json',BASE/'production-cli/receipt.json',BASE/'source-checks/receipt.json',BASE/'example-feature-comparison.json']}}
save(BASE/'coverage-summary.json',result);print('COVERAGE',passed,guard_count,9)
