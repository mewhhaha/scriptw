# Read-only diagnostic over already validated frozen P, not a Wasm validator.
from pathlib import Path
import hashlib,json,struct
class R:
 def __init__(self,b): self.b=b; self.p=0
 def byte(self): x=self.b[self.p]; self.p+=1; return x
 def leb(self):
  x=0;s=0
  while True:
   n=self.byte();x|=(n&127)<<s;s+=7
   if n<128:return x
 def data(self,n): x=self.b[self.p:self.p+n];self.p+=n;return x
 def text(self): return self.data(self.leb()).decode()
 def val(self):
  n=self.byte()
  if n in (0x63,0x64):self.leb()
 def limit(self):
  n=self.leb();self.leb()
  if n&1:self.leb()
def module(b):
 r=R(b);assert r.data(8)==b'\0asm\x01\0\0\0';imports=0;names={};bodies=[]
 while r.p<len(b):
  sec=r.byte();p=R(r.data(r.leb()))
  if sec==2:
   for _ in range(p.leb()):
    p.text();p.text();kind=p.byte()
    if kind in (0,5): p.leb();imports+=1
    elif kind==3:p.val();p.byte()
    elif kind==1:p.val();p.limit()
    elif kind==2:p.limit()
    elif kind==4:p.byte();p.leb()
    else:raise ValueError(('import kind',kind))
  elif sec==10:
   for _ in range(p.leb()): bodies.append(p.data(p.leb()))
  elif sec==0 and p.text()=='name':
   while p.p<len(p.b):
    sub=p.byte();q=R(p.data(p.leb()))
    if sub==1:
     for _ in range(q.leb()):
      index=q.leb();names[index]=q.text()
 return [(names.get(i+imports,''),v) for i,v in enumerate(bodies)]
def ops(b):
 r=R(b)
 for _ in range(r.leb()):r.leb();r.val()
 out=[]
 while r.p<len(b):
  pos=r.p;op=r.byte();sub=None
  if op in (2,3,4,6):r.leb()
  elif op==0x1f:
   r.leb()
   for _ in range(r.leb()):
    kind=r.byte()
    if kind in (0,1):r.leb()
    r.leb()
  elif op in (7,8,9,0xc,0xd,0x10,0x12,0x14,0x15,0x18,0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x41,0x42,0xd0,0xd2,0xd5,0xd6):r.leb()
  elif op in (0x11,0x13):r.leb();r.leb()
  elif op==0xe:
   for _ in range(r.leb()+1):r.leb()
  elif op==0x1c:
   for _ in range(r.leb()):r.val()
  elif 0x28<=op<=0x3e:r.leb();r.leb()
  elif op in (0x3f,0x40):r.leb()
  elif op==0x43:r.data(4)
  elif op==0x44:r.data(8)
  elif op==0xfb:
   sub=r.leb()
   if sub in (0,1,6,7,11,12,13,14,16,20,21,22,23):r.leb()
   elif sub in (2,3,4,5,8,9,10,17,18,19):r.leb();r.leb()
   elif sub in (24,25):r.byte();r.leb();r.leb();r.leb()
   elif sub not in (15,26,27,28,29,30):raise ValueError(('gc',sub,pos))
  elif op==0xfc:
   sub=r.leb()
   if sub in (8,10,12,14):r.leb();r.leb()
   elif sub in (9,11,13,15,16,17):r.leb()
   elif sub>7:raise ValueError(('misc',sub,pos))
  elif not (op in (0,1,5,0xa,0xb,0xf,0x19,0x1a,0x1b,0xd1,0xd3,0xd4) or 0x45<=op<=0xc4):raise ValueError(('opcode',hex(op),pos))
  out.append((op,sub,pos,r.p))
 return out
def scan(b):
 parsed=ops(b);stack=[];loops=[]
 bad=lambda op,sub: op in (0x10,0x11,0x12,0x13,0x14,0x15,0x24) or (op==0xfb and sub in (0,1,5,6,7,8,9,10,14))
 for i,(op,sub,pos,end) in enumerate(parsed):
  if op in (2,3,4,6,0x1f):stack.append((i,op))
  elif op==0xb and stack:
   start,kind=stack.pop()
   region=parsed[start+1:i]
   if kind==3 and any(x[0]==0xa0 for x in region) and any(x[:2]==(0xfb,11) for x in region) and not any(bad(*x[:2]) for x in region):
    loops.append(dict(byte_start=region[0][2],byte_end=region[-1][3],operators=len(region),floor=sum(x[0]==0x9c for x in region),trunc=sum(x[0]==0x9d for x in region),f64_add=sum(x[0]==0xa0 for x in region),if_count=sum(x[0]==4 for x in region),instructions=[(hex(x[0]),x[1],x[2]) for x in region]))
 return loops
root=Path('target/performance-number-domains-20261108/screen/images/prepare-fast')
result=[]
for name in ['args-unused','frame-compact']:
 meta=json.loads((root/(name+'.js.retained.json')).read_text());envelope=(root/(name+'.js.retained.swpc')).read_bytes()
 n=int.from_bytes(envelope[74:82],'little');facts=int.from_bytes(envelope[90:94],'little');p=envelope[94+facts:94+facts+n]
 assert hashlib.sha256(p).hexdigest()==meta['program_wasm_sha256']
 body=next(v for k,v in module(p) if k.startswith('js::run#'))
 loops=scan(body)
 result.append(dict(name=name,source_fingerprint=meta['source_fingerprint'],program_sha256=meta['program_wasm_sha256'],program_bytes=n,run_bytes=len(body),loops=loops))
 Path('target/performance-integer-projection-20261108/'+name+'.wasm').write_bytes(p)
Path('target/performance-integer-projection-20261108/frozen-counts.json').write_text(json.dumps(result,indent=2)+'\n')
for row in result:
 print({k:v for k,v in row.items() if k!='loops'})
 print([{k:v for k,v in loop.items() if k!='instructions'} for loop in row['loops']])
