"""Run compact-row-focused and remaining selected native test scopes."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
FOLDER = OUT / "native"
sys.path.insert(0, str(ROOT / "scripts"))
from benchmark_metrics import digest
from limited_verification import require_kernel_budget
from native_test_protocol import parse_inventory, result_summaries

FOCUSED = [
    ("scriptw_aot_wasm", "tests::scalar_regions::"),
    ("aot_language", "aot_compact_row_regions::"),
    ("aot_gc_entries", "aot_gc_compact_data_storage::"),
]
FULL_SCOPES = [
    ("scriptw_aot_wasm", None),
    ("scriptw_engine", "memory_module_cache::"),
    ("scriptw_engine", "wasm_runtime_link::tests::"),
    ("scriptw_engine", "runtime_profile::"),
    ("structure_language", None),
    ("emission", None),
    ("aot_language", None),
    ("aot_gc_entries", None),
]


def artifact_rows():
    rows = {}
    for line in (OUT / "native-build.jsonl").read_text().splitlines():
        row = json.loads(line)
        if row.get("reason") == "compiler-artifact" and row.get("executable") and row["profile"]["test"]:
            rows[row["target"]["name"]] = row
    return rows


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("focus", "remaining"), required=True)
    args = parser.parse_args()
    require_kernel_budget(4 * 1024 * 1024 * 1024)
    assert len(os.sched_getaffinity(0)) == 1, "run serially under limited_verification"
    FOLDER.mkdir(exist_ok=True)
    artifacts = artifact_rows()
    frozen = json.loads((OUT / "candidate/identity.json").read_text())
    skips = {}
    prior_focus = FOLDER / "focus-receipt.json"
    if args.stage == "focus":
        scopes = FOCUSED
        receipt_path = prior_focus
    else:
        assert prior_focus.is_file(), "focused scopes must finish first"
        focus = json.loads(prior_focus.read_text())
        assert focus["status"] == "complete", "review focus failures before remaining scopes"
        assert focus["candidate_source_fingerprint"] == frozen["source_fingerprint"]
        for row in focus["scopes"]:
            skips.setdefault(row["target"], set()).update(row["selected_inventory"])
        scopes = FULL_SCOPES
        receipt_path = FOLDER / "remaining-receipt.json"

    rows = []
    for target, filter_text in scopes:
        producer = artifacts[target]
        executable = Path(producer["executable"])
        executable_sha256 = digest(executable)
        listing = subprocess.check_output([executable, "--list"], text=True)
        inventory = parse_inventory(listing)
        skipped = skips.get(target, set())
        selected = [name for name in inventory
            if (filter_text is None or filter_text in name) and name not in skipped]
        assert selected, f"empty native scope: {target} {filter_text}"
        stem = target + ("-" + filter_text.replace("::", "_").strip("_") if filter_text else "")
        (FOLDER / f"{stem}.inventory").write_text(listing)
        argv = [str(executable), "--test-threads=1"]
        if filter_text is not None:
            argv.extend([filter_text, "--nocapture"])
        for name in sorted(skipped):
            argv.extend(["--skip", name])
        stdout_path = FOLDER / f"{args.stage}-{stem}.stdout"
        stderr_path = FOLDER / f"{args.stage}-{stem}.stderr"
        started = time.monotonic()
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            try:
                result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr,
                    timeout=3600, check=False)
                timed_out = False
                exit_code = result.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
                exit_code = 124
        summaries = result_summaries(stdout_path.read_text())
        passed = (exit_code == 0 and not timed_out and len(summaries) == 1
            and summaries[0][0] == "ok" and int(summaries[0][1]) == len(selected)
            and int(summaries[0][2]) == int(summaries[0][3]) == 0)
        row = dict(target=target, filter=filter_text, producer=producer,
            executable=str(executable), executable_sha256=executable_sha256,
            candidate_source_fingerprint=frozen["source_fingerprint"],
            selected_inventory=selected, skipped_inventory=sorted(skipped), argv=argv,
            exit_code=exit_code, timed_out=timed_out, summaries=summaries,
            stdout=stdout_path.name, stderr=stderr_path.name,
            elapsed_seconds=time.monotonic() - started, passed=passed)
        (FOLDER / f"{args.stage}-{stem}.json").write_text(json.dumps(row, indent=2) + "\n")
        rows.append(row)
        receipt = dict(status="running", stage=args.stage,
            candidate_source_fingerprint=frozen["source_fingerprint"], scopes=rows)
        save(receipt_path, receipt)
        print(stem, len(selected), "PASS" if passed else "FAIL", summaries, flush=True)
        assert digest(executable) == executable_sha256, f"test binary changed: {target}"
    receipt["status"] = "complete" if all(row["passed"] for row in rows) else "failed"
    save(receipt_path, receipt)
    if receipt["status"] != "complete":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
