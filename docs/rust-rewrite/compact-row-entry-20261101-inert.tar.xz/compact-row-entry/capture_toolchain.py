"""Capture installed Rust tool versions and compare them with the prior baseline."""
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
BASELINE = ROOT / "target/performance-compact-rows/toolchain.json"


def capture(label, argv):
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True, check=False)
    return dict(argv=argv, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)


def main():
    baseline = json.loads(BASELINE.read_text())
    commands = {
        "rustc": capture("rustc", ["rustc", "-Vv"]),
        "cargo": capture("cargo", ["cargo", "-Vv"]),
        "rustfmt": capture("rustfmt", ["rustfmt", "--version"]),
    }
    for label, result in commands.items():
        assert result["exit_code"] == 0 and result["stderr"] == "", (label, result)
    rustc_lines = dict(line.split(": ", 1) for line in commands["rustc"]["stdout"].splitlines()
        if ": " in line)
    cargo_lines = dict(line.split(": ", 1) for line in commands["cargo"]["stdout"].splitlines()
        if ": " in line)
    current = dict(
        rustc=commands["rustc"]["stdout"].splitlines()[0].removeprefix("rustc "),
        llvm=rustc_lines["LLVM version"],
        cargo=commands["cargo"]["stdout"].splitlines()[0].removeprefix("cargo ").split(" ", 1)[0],
        rustfmt=commands["rustfmt"]["stdout"].strip())
    prior_commands = baseline["commands"]
    prior_rustfmt = prior_commands["rustfmt"]["stdout"].strip()
    comparisons = dict(
        rustc=current["rustc"] == baseline["baseline_toolchain"]["rustc"],
        llvm=current["llvm"] == baseline["baseline_toolchain"]["llvm"],
        cargo=current["cargo"] == baseline["baseline_toolchain"]["cargo"],
        rustfmt=current["rustfmt"] == prior_rustfmt)
    record = dict(status="captured", baseline_source=str(BASELINE.relative_to(ROOT)),
        baseline_toolchain=baseline["baseline_toolchain"], current_toolchain=current,
        matches_baseline=comparisons, commands=commands)
    (OUT / "toolchain.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
