"""Inspect six existing, identity-bound P modules after all campaigns finish.

No compilation, measurements, runtime replay, or native-image loading occurs.
The exact named source fragments include guards and generic continuations;
encoded tests, not textual marker counts, establish compiler admission.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
CASES = ["objects.js", "retained-objects.js", "numeric-loop-50000.js"]
MAX_WAT, MAX_FRAGMENT = 64 << 20, 8 << 20


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def rotated_loops(lines, first, case):
    """Bounded WAT evidence; native encoded tests remain the typed authority."""
    if case == "numeric-loop-50000.js":
        return []
    ops = [line.strip() for line in lines]
    frames, active, loops_at = [], [], []
    for offset, op in enumerate(ops):
        word = op.split(" ", 1)[0]
        loops_at.append(next((i for i in reversed(active) if frames[i]["kind"] == "loop"), None))
        if word in {"block", "loop", "if", "try_table"}:
            frames.append(dict(kind=word, start=offset, parent=active[-1] if active else None))
            active.append(len(frames) - 1)
        elif word == "end":
            assert active, "balanced actual Wasm control frames"
            frames[active.pop()]["end"] = offset
    assert not active

    def bound_at(offset, depth):
        return (ops[offset].startswith("local.get ") and ops[offset + 1].startswith("local.get ")
            and ops[offset + 2:offset + 5] == ["i32.wrap_i64", "i32.lt_u", "i32.eqz"]
            and ops[offset + 5].split()[:2] == ["br_if", str(depth)])

    def captures(begin, end):
        return [ops[i + 1].split()[1] for i in range(begin, end - 1)
            if ops[i] == "f64.reinterpret_i64" and ops[i + 1].startswith("local.set ")]

    records = []
    for index, frame in enumerate(frames):
        if frame["kind"] != "loop" or frame["parent"] is None:
            continue
        done = frames[frame["parent"]]
        if done["kind"] != "block" or not bound_at(done["start"] + 1, 0):
            continue
        hot_start, hot_end = frame["start"] + 1, frame["end"]
        hot = ops[hot_start:hot_end]
        # Purity participates in selection, so generic fallback inline caches
        # cannot be mistaken for the closed compact loop.
        forbidden = ("call", "return_call", "struct.set", "array.set", "struct.new", "array.new", "global.get", "global.set")
        if any(op.startswith(forbidden) or op == "ref.is_null" for op in hot):
            continue
        bounds = [i for i in range(hot_start, hot_end - 5)
            if loops_at[i] == index and bound_at(i, 1)]
        if len(bounds) != 1:
            continue
        bound = bounds[0]
        expected_adds, expected_leaves = 2, 1
        if case == "objects.js":
            expected_adds, expected_leaves = 3, 2
        if hot.count("f64.add") != expected_adds:
            continue
        pre_start, pre_end = done["start"] + 1, frame["start"]
        assert "f64.add" not in ops[pre_start:pre_end], "first row executes no duplicate body/update"
        assert any(op.startswith("call ") for op in ops[pre_start:pre_end]), "key equality stays in first-row setup"
        assert ops[pre_end - 3].startswith("local.get ") and ops[pre_end - 2] == "i32.eqz"
        assert ops[pre_end - 1].split()[:2] == ["br_if", "0"]
        assert hot[-1].split()[:2] == ["br", "0"]
        assert hot[-2].split()[:2] == ["br_if", "1"] and hot[-3] == "i32.eqz"
        assert hot[-4].startswith("local.get ")
        assert ops[hot_start:bound].count("f64.add") == expected_adds
        assert "f64.add" not in ops[bound:hot_end], "next footprint precedes next iteration arithmetic"
        first_captures, next_captures = captures(pre_start, pre_end), captures(bound + 6, hot_end)
        assert first_captures == next_captures and len(first_captures) == expected_leaves
        assert not any(f["kind"] == "loop" and hot_start <= f["start"] < hot_end for f in frames)
        mirror = ops[pre_start:pre_start + 2]
        continuation = next(i for i in range(done["end"] + 1, len(ops) - 4)
            if ops[i:i + 2] == mirror and ops[i + 2:i + 4] == ["i32.wrap_i64", "i32.lt_u"]
            and ops[i + 4].startswith("local.set "))
        needed = ops[continuation + 4].split()[1]
        decision = next(i for i in range(continuation + 5, len(ops)) if ops[i] == "local.get " + needed)
        generic = next(f for f in frames if f["kind"] == "loop" and f["start"] > decision)
        assert any(op.startswith("ref.null ") for op in ops[decision:generic["start"]])
        records.append(dict(done_block_line=first + done["start"], first_bound_line=first + pre_start,
            preheader_last_line=first + pre_end - 1, loop_line=first + frame["start"],
            next_bound_line=first + bound, next_ready_line=first + hot_end - 4,
            loop_end_line=first + hot_end, continuation_line=first + continuation,
            generic_loop_line=first + generic["start"], body_update_f64_adds=expected_adds,
            first_and_next_capture_locals=first_captures, hot_calls=0,
            hot_ref_is_null=0, hot_global_reads=0,
            preheader_only_null_root_types=sorted({op for op in ops[pre_start:pre_end] if op.startswith("ref.null ")}
                - {op for op in hot if op.startswith("ref.null ")}),
            boundary="Exact bounded rotated source loop. Typed key/String-root identities are additionally checked by native encoded tests."))
    assert len(records) == 1, (case, "one actual rotated compact loop per source variant", len(records))
    return records


def source_fragments(wat, destination, case):
    lines = wat.read_text(encoding="utf-8").splitlines(keepends=True)
    records, current, first = [], [], None
    for index, line in enumerate(lines, 1):
        if line.startswith("  (func $js::workload#"):
            assert first is None
            first, current = index, []
        if first is None:
            continue
        current.append(line)
        if line.rstrip() != "  )":
            continue
        text = "".join(current)
        assert len(text.encode()) <= MAX_FRAGMENT
        path = destination / (wat.stem + f"-workload-{len(records)}.wat-fragment")
        path.write_text(text, encoding="utf-8")
        instructions = [line.strip() for line in current]
        bounds = [first + offset for offset in range(len(instructions) - 3)
            if instructions[offset:offset + 3] == ["i32.wrap_i64", "i32.lt_u", "i32.eqz"]
            and instructions[offset + 3].startswith("br_if ")]
        records.append(dict(path=path.name, sha256=sha(path), bytes=path.stat().st_size,
            function_header=current[0].strip(), wat_first_line=first, wat_last_line=index,
            indexed_bound_marker_lines=bounds,
            rotated_loops=rotated_loops(current, first, case),
            scope="Exact complete named source body, including guard/publication/fallback instructions. "
                "Marker lines locate indexed bounds only; they are not a semantic admission proof."))
        first = None
    assert first is None and records, "actual workload function bodies must be named"
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--finalize", action="store_true", required=True)
    parser.add_argument("--ordinary", type=Path, required=True)
    parser.add_argument("--wasm-tools", type=Path,
        default=ROOT / "target/performance-fresh-sort/tools/wasm-tools")
    args = parser.parse_args()
    run = args.ordinary.resolve()
    assert run.is_relative_to(BASE)
    analysis, reference = load(run / "analysis.json"), load(BASE / "reference-analysis.json")
    identity, products = load(BASE / "candidate/identity.json"), load(BASE / "candidate/products.json")
    assert identity["source_commit"] == "1b6f516548a75de849ddaa8f4431b7402c336697"
    assert identity["source_fingerprint"] != "9dc76f3d8a7986758a02f2eeee27d5d2947369868c8dc24f166bfe300b00bff6"
    assert analysis["status"] == "complete"
    assert reference["samples"] == 21 and reference["warmups"] == 10
    invariance = load(BASE / "runtime-invariance.json")
    assert invariance["status"] == "verified" and invariance["candidate_source_fingerprint"] == identity["source_fingerprint"]
    assert all(row["runtime_abi"] == 42 and row["runtime_wasm_identical"] and row["native_identical"]
        for row in invariance["profiles"].values())
    folder = BASE / "program-inspection"
    folder.mkdir(exist_ok=False)
    records = []
    for case in CASES:
        source = BASE / "sources" / case
        source_hash = sha(source)
        assert source_hash == sha(ROOT / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths" / case)
        row = next(row for row in analysis["rows"] if row["case"] == case and row["product"] == "candidate")
        report = load(run / "raw" / (row["raw"] + ".stdout"))
        assert report["source_fingerprint"] == identity["source_fingerprint"]
        assert report["executable_sha256"] == products["runtime_baseline"]["sha256"]
        actual = report["cases"][0]
        assert actual["file"] == case and actual["source_sha256"] == source_hash
        scriptw = run / "artifacts" / row["raw"] / (case + ".wasm")
        scriptc = BASE / "scriptc-wasm" / (case + ".wasm")
        for label, path, expected in [("scriptw", scriptw, actual["wasm_sha256"]),
            ("scriptc", scriptc, reference["compilation"][case]["wasm_sha256"])]:
            assert path.is_file() and not path.is_symlink() and sha(path) == expected
            assert path.read_bytes()[:8] == b"\0asm\x01\0\0\0"
            wat = folder / (label + "-" + case + ".wat")
            with wat.open("xb") as stdout:
                subprocess.run([str(args.wasm_tools), "print", str(path)], stdout=stdout,
                    check=True, timeout=120)
            assert wat.stat().st_size <= MAX_WAT
            wat.read_text(encoding="utf-8")
            record = dict(product=label, case=case, original_source_sha256=source_hash,
                source_wasm=str(path.relative_to(BASE)), wasm_sha256=expected, wasm_bytes=path.stat().st_size,
                wat=wat.name, wat_sha256=sha(wat), wat_bytes=wat.stat().st_size)
            if label == "scriptw":
                record.update(source_commit=identity["source_commit"], source_fingerprint=identity["source_fingerprint"],
                    measured_raw=row["raw"], source_compilation_profile=actual["source_compilation_profile"],
                    source_functions=source_fragments(wat, folder, case))
            else:
                record.update(adapted_source_sha256=sha(BASE / "adapted-scriptc" / case),
                    compiler=reference["tools"]["scriptc"], compilation_receipt=reference["compilation"][case])
            records.append(record)
    assert len(records) == 6
    result = dict(schema="scriptw-compact-row-entry-wasm-inspection-v1", source_commit=identity["source_commit"],
        source_fingerprint=identity["source_fingerprint"], ordinary_run=str(run.relative_to(BASE)),
        tool_version=subprocess.check_output([str(args.wasm_tools), "--version"], text=True).strip(),
        tool_sha256=sha(args.wasm_tools), products=records,
        runtime_invariance=dict(path="runtime-invariance.json", sha256=sha(BASE / "runtime-invariance.json"),
            record=invariance),
        scope="Six actual P modules. R byte equality comes from its separate checked producer record; "
            "no R/native image was printed, loaded, or recompiled by this helper.")
    (folder / "identity.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("Inspected six frozen P modules and exact named Scriptw workload bodies.")


if __name__ == "__main__":
    main()
