"""Unscored frozen-product semantic checks; never enters an ordinary score."""
from pathlib import Path
import json
import sys

ROOT = Path.cwd()
OUT = ROOT / "target/performance-compact-row-entry"
DEST = OUT / "product-semantics"
SOURCES = DEST / "sources"
sys.path.insert(0, str(OUT))
import run

FIXTURE = "prefix-type-transitions.js"
EXPECTED = "true\n"
SAMPLES, WARMUPS = 3, 1
EXPECTED_FP = "51ce1e39064e5b53e6c42b96d64517e884ab44690f230cc3b216ce177a072c97"
EXPECTED_COMMIT = "1b6f516548a75de849ddaa8f4431b7402c336697"


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    assert not (DEST / "receipt.json").exists() and not (DEST / "raw").exists(), "preserve any prior unscored product-semantic run"
    manifest = run.load(SOURCES / "manifest.json")
    assert manifest["execution"] == [dict(file=FIXTURE, stdout=EXPECTED)]
    source = SOURCES / FIXTURE
    source_sha = run.digest(source)
    identity = run.load(OUT / "candidate/identity.json")
    products = run.load(OUT / "candidate/products.json")
    assert identity["source_fingerprint"] == EXPECTED_FP
    assert identity["source_commit"] == EXPECTED_COMMIT
    identity_record = run.check_product("candidate")
    assert identity_record["source_fingerprint"] == EXPECTED_FP
    run.check_runtime_invariance()
    cli = OUT / "candidate/scriptw"
    cli_sha = run.digest(cli)
    assert products["scriptw"]["sha256"] == cli_sha
    artifacts = DEST / "artifacts"
    artifacts.mkdir()

    commands = [
        ("node", ["node", ROOT / "crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs",
            SOURCES, str(SAMPLES), str(WARMUPS), FIXTURE]),
        ("cli-nativehost", [cli, "--jobs", "1", "--host-surface", "test262", "run", source]),
        ("portable-host", [OUT / "candidate/runtime_baseline", SOURCES,
            str(SAMPLES), str(WARMUPS), FIXTURE, artifacts]),
        ("no-interpreter-graph", ["sh", "scripts/check-no-interpreter-in-product-graph.sh"]),
    ]
    records = []
    for label, argv in commands:
        event = run.invoke(DEST, label, argv)
        raw_path = DEST / "raw" / f"{label}.stdout"
        stdout = raw_path.read_text()
        record = dict(label=label, argv=list(map(str, argv)), exit_code=event["exit_code"],
            timed_out=event["timed_out"], raw_stdout=f"raw/{label}.stdout",
            raw_stderr=f"raw/{label}.stderr", command_receipt=f"raw/{label}.command.json",
            source_sha256=source_sha, source_fingerprint=EXPECTED_FP,
            purpose="unscored semantic and product-delivery control")
        if label == "node":
            report = json.loads(stdout)
            case = report["cases"][0]
            observations = case["observations"]
            assert report["schema"] == "scriptw-v8-baseline-v2"
            assert case["file"] == FIXTURE and case["source_sha256"] == source_sha
            assert len(observations) == SAMPLES + WARMUPS
            assert [row["warmup"] for row in observations] == [True, False, False, False]
            assert all(row["stdout"] == EXPECTED for row in observations)
            record.update(node=report["node"], v8=report["v8"], observation_count=len(observations),
                all_stdout_match=True)
        elif label == "cli-nativehost":
            assert stdout.startswith(EXPECTED) and "boolean(true)" in stdout
            record.update(exact_prefix=EXPECTED, contains_wasm_aot_boolean_true=True,
                actual_stdout=stdout)
        elif label == "portable-host":
            report = json.loads(stdout)
            case = report["cases"][0]
            observations = case["observations"]
            assert report["schema"] == "scriptw-wasmtime-baseline-v2"
            assert report["source_fingerprint"] == EXPECTED_FP
            assert report["source_commit"] == EXPECTED_COMMIT
            assert report["executable_sha256"] == products["runtime_baseline"]["sha256"]
            assert report["requested_native_policy"] is None
            assert case["file"] == FIXTURE and case["source_sha256"] == source_sha
            assert case["source_compilation_profile"] == "portable"
            assert len(observations) == SAMPLES + WARMUPS
            assert [row["warmup"] for row in observations] == [True, False, False, False]
            assert all(row["stdout"] == EXPECTED for row in observations)
            record.update(host_executable_sha256=report["executable_sha256"],
                observation_count=len(observations), all_stdout_match=True,
                source_compilation_profile=case["source_compilation_profile"])
        records.append(record)
        save(DEST / "receipt.json", dict(status="running", scored=False,
            fixture=FIXTURE, source_sha256=source_sha, source_fingerprint=EXPECTED_FP,
            sample_count=SAMPLES, warmup_count=WARMUPS, records=records))
        print(label, "PASS", flush=True)

    unchanged = run.verify_frozen_products(["candidate"])
    receipt = dict(status="pass", scored=False,
        purpose="unscored system Node oracle, frozen CLI NativeHost, Portable-host report and no-interpreter graph check",
        candidate_source_commit=EXPECTED_COMMIT, candidate_source_fingerprint=EXPECTED_FP,
        candidate_cli_sha256=cli_sha, fixture=FIXTURE, fixture_source_sha256=source_sha,
        exact_expected_stdout=EXPECTED, samples=SAMPLES, warmups=WARMUPS,
        product_hashes_after=unchanged, records=records)
    save(DEST / "receipt.json", receipt)
    print(json.dumps(dict(status="pass", scored=False, records=len(records), fixture=FIXTURE), indent=2))


if __name__ == "__main__":
    main()
