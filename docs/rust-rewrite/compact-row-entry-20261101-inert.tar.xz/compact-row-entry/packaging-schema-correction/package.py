"""Finalize first-row entry evidence only after campaigns/audits finish.

Prepare-only until explicitly invoked with --finalize --status accepted|rejected
under limited_verification. No build/test/measurement/reference replay occurs.
"""
import argparse
import collections
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import statistics
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DOCS = ROOT / "docs/rust-rewrite"
STEM = "compact-row-entry-20261101"
BASELINE_FP = "9dc76f3d8a7986758a02f2eeee27d5d2947369868c8dc24f166bfe300b00bff6"
ACCEPTED_BASELINE = "1b6f516548a75de849ddaa8f4431b7402c336697"
COMPILED_BASELINE = "d1bf33a43bb2dc65afcc2d017a0e3633630d161e"
SOURCE_PARENT = "1b6f516548a75de849ddaa8f4431b7402c336697"
COUNTS = dict(aa=432, ordinary=432, cp_control=432)
TEXT_SUFFIXES = {
    ".json", ".jsonl", ".py", ".log", ".stdout", ".stderr", ".inventory",
    ".rs", ".patch", ".wat", ".wat-fragment", ".script", ".map",
    ".identity", ".js", ".md", ".txt", ".toml", ".lock", ".csv",
}
TEXT_DIRS = {
    "baseline", "baseline-aa", "candidate", "native", "runs", "cp-control",
    "test262-compact-rows", "fixture-output-diagnostic", "program-inspection",
    "product-semantics", "raw", "sources", "retained-sources", "adapted-scriptc", "expected",
    "setup-metadata-correction", "reference-audit-preparation-correction",
    "audit-preparation-input-correction", "inspection-first-attempt",
}
FORBIDDEN_DIRS = {"tools", "toolchain", "node_modules", ".git", "__pycache__", "cache", ".cache"}
MAX_FILE, MAX_TOTAL, MAX_MEMBERS, MAX_ARCHIVE = 64 << 20, 512 << 20, 20000, 128 << 20


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def file_hash(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def native_coverage(audit, fingerprint):
    unions, binaries, scopes, stages = collections.defaultdict(set), {}, [], collections.Counter()
    for stage in ["focus", "remaining"]:
        receipt = load(BASE / "native" / (stage + "-receipt.json"))
        assert receipt["status"] == "complete" and receipt["stage"] == stage
        assert receipt["candidate_source_fingerprint"] == fingerprint
        for row in receipt["scopes"]:
            assert row["passed"] and row["exit_code"] == 0 and not row["timed_out"]
            assert row["candidate_source_fingerprint"] == fingerprint and len(row["summaries"]) == 1
            result, names = row["summaries"][0], set(row["selected_inventory"])
            assert result[0] == "ok" and int(result[1]) == len(names) and int(result[2]) == int(result[3]) == 0
            assert len(names) == len(row["selected_inventory"]) and not names.intersection(unions[row["target"]])
            unions[row["target"]].update(names)
            assert binaries.setdefault(row["target"], row["executable_sha256"]) == row["executable_sha256"]
            stages[stage] += len(names)
            scopes.append(dict(stage=stage, target=row["target"], filter=row["filter"], passed=len(names),
                executable_sha256=row["executable_sha256"]))
    counts, audited = {target: len(names) for target, names in unions.items()}, audit["native_coverage"]
    assert counts == audited["selected_counts"]
    assert {target: sorted(names) for target, names in unions.items()} == audited["selected_tests"]
    assert sum(counts.values()) == audited["unique_selected_total"] == 1491
    assert dict(stages) == audited["stage_pass_counts"] == dict(focus=46, remaining=1445)
    assert binaries == audited["binaries_sha256"]
    assert {stage: file_hash(BASE / "native" / (stage + "-receipt.json"))
        for stage in ["focus", "remaining"]} == audited["receipts_sha256"]
    assert counts["scriptw_engine"] == 38, "selected Engine coverage is not the full Engine suite"
    assert not audited.get("test_only_correction"), "new failure chains require explicit preservation/review"
    guards = (BASE / "guards.stdout").read_text(encoding="utf-8")
    totals = re.findall(r"test result: ok\. (\d+) passed; 0 failed; 0 ignored;", guards)
    assert sum(map(int, totals)) == 359
    return dict(native_distinct=sum(counts.values()), native_by_target=counts, native_scopes=scopes,
        native_audit=audited, source_guards=359, test_correction_chains=[], full_engine_suite=False,
        boundary="Disjoint 46 focused + 1445 remaining named passes; 38 selected Engine tests, not the full Engine suite. "
            "Source-only guards are separate. No predecessor correction chains are inherited.")


def references(analysis, audit, fingerprint):
    assert audit["status"] == "audited" and audit["attempts"] == 136
    assert {label: row["source_fingerprint"] for label, row in audit["hosts"].items()} == dict(baseline=BASELINE_FP, candidate=fingerprint)
    groups = collections.defaultdict(list)
    seen = set()
    for row in analysis["attempts"]:
        key = (row["file"], row["runtime"], row["round"])
        assert row["status"] == "ok" and key not in seen and len(row["times_ns"]) == 21
        seen.add(key)
        groups[key[:2]].append(row["times_ns"])
    assert len(seen) == 136 and len(groups) == 68 and all(len(v) == 2 for v in groups.values())
    cases = sorted({name for name, _ in groups})
    assert len(cases) == len(analysis["compilation"]) == audit["scriptc_compilations"] == 17
    primary, median_wins, mean_wins = [], dict(v8=[], scriptc=[]), dict(v8=[], scriptc=[])
    for name in cases:
        stats = {runtime: dict(median_ns=statistics.median(statistics.median(v) for v in groups[name, runtime]),
            mean_ns=statistics.mean(statistics.mean(v) for v in groups[name, runtime]))
            for runtime in ["baseline", "candidate", "v8", "scriptc"]}
        for runtime in median_wins:
            if stats["candidate"]["median_ns"] < stats[runtime]["median_ns"]:
                median_wins[runtime].append(name)
            if stats["candidate"]["mean_ns"] < stats[runtime]["mean_ns"]:
                mean_wins[runtime].append(name)
        primary.append(dict(case=name, runtimes=stats))
    assert {k: sorted(v) for k, v in audit["median_wins"].items()} == median_wins
    assert {k: sorted(v) for k, v in audit["mean_wins"].items()} == mean_wins
    return dict(scope=analysis["policy"], tools=analysis["tools"], attempts=len(seen),
        measured_observations=len(seen) * 21, warmups=len(seen) * 10,
        scriptc_compilations=len(analysis["compilation"]), median_wins=median_wins, mean_wins=mean_wins,
        experimental_unit="Independent process; median of two process medians and mean of two process means.",
        process_statistics=primary, pooled_statistics_descriptive=analysis["summary"],
        boundary="V8 context creation is outside execution timing; Scriptw Realm/bootstrap/completion remains inside. "
            "Scriptc Store/instantiation is outside, _start/output extraction inside. "
            "Descriptive existing boundaries, not equal end-to-end Realm costs. Endpoint RSS is not peak/live JS memory.")

def conformance(receipt, fingerprint):
    assert receipt["status"] in {"complete", "failed"} and receipt["source_fingerprint"] == fingerprint
    assert receipt["cli_sha256"] == load(BASE / "candidate/products.json")["scriptw"]["sha256"]
    assert receipt["source_commit"] == load(BASE / "candidate/identity.json")["source_commit"]
    rows = []
    for scope in receipt["scopes"]:
        assert not scope["timed_out"] and scope["launch_error"] is None and len(scope["snapshots"]) == 1
        snapshot = scope["snapshots"][0]
        assert snapshot["source_fingerprint_matches"] and snapshot["total"] > 0
        rows.append(dict(selection=scope["selection"], scope_pass=scope["scope_pass"], exit_code=scope["exit_code"],
            passed=snapshot["passed"], total=snapshot["total"], pinned_revisions=snapshot["pinned_revisions"],
            completed_test_ids_sha256=snapshot["completed_test_ids_sha256"],
            failures=snapshot["failures"], timeout_test_ids=snapshot["timeout_test_ids"]))
    assert len(rows) == 3 and len({r["selection"] for r in rows}) == 3
    if receipt["status"] == "complete":
        assert all(r["scope_pass"] and r["exit_code"] == 0 and r["passed"] == r["total"] for r in rows)
    return dict(status=receipt["status"], passed=sum(r["passed"] for r in rows),
        total=sum(r["total"] for r in rows), scopes=rows, full_Test262_or_release_acceptance=False)

def text_members():
    total, selected, excluded = 0, [], []
    for folder, dirs, names in os.walk(BASE, followlinks=False):
        folder = Path(folder)
        kept = []
        for name in sorted(dirs):
            path = folder / name
            if path.is_symlink() or name in FORBIDDEN_DIRS or name.endswith("-cache") or name.startswith("cache-"):
                excluded.append(str(path.relative_to(BASE)))
            elif folder != BASE or name in TEXT_DIRS:
                kept.append(name)
            else:
                excluded.append(str(path.relative_to(BASE)))
        dirs[:] = kept
        for name in sorted(names):
            path = folder / name
            relative = path.relative_to(BASE)
            if path.is_symlink() or not path.is_file() or path.suffix not in TEXT_SUFFIXES:
                excluded.append(str(relative))
                continue
            size = path.stat().st_size
            assert size <= MAX_FILE, f"oversized allowlisted text: {relative}"
            total += size
            assert total <= MAX_TOTAL and len(selected) + 2 < MAX_MEMBERS
            raw = path.read_bytes()
            raw.decode("utf-8")  # Unexpected binary under a text suffix fails closed.
            assert not raw.startswith((b"\0asm", b"\x7fELF", b"SCRWRB01")), f"binary magic in text member: {relative}"
            member = "compact-row-entry/" + relative.as_posix()
            assert not PurePosixPath(member).is_absolute() and ".." not in PurePosixPath(member).parts
            selected.append((member, raw))
    return selected, excluded

def archive_text(destination):
    selected, excluded = text_members()
    notice = ("Inert UTF-8 evidence only. No binary executables, Wasm modules, native images, toolchains, "
        "caches or symlinks. Scripts are recorded workflow text, not an archive execution interface. "
        "Hashes of producer outputs do not authorize loading native code.\n").encode()
    inventory = dict(members=[dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        for name, raw in selected], excluded=excluded,
        limits=dict(file_bytes=MAX_FILE, total_bytes=MAX_TOTAL, members=MAX_MEMBERS, archive_bytes=MAX_ARCHIVE))
    members = [("EVIDENCE.txt", notice), ("EVIDENCE.json", (json.dumps(inventory, indent=2) + "\n").encode())] + selected
    assert len(members) <= MAX_MEMBERS and sum(len(raw) for _, raw in members) <= MAX_TOTAL
    temporary = destination.with_name(destination.name + ".tmp")
    assert not destination.exists() and not temporary.exists(), "preserve previous packages"
    with tarfile.open(temporary, "w:xz", preset=6) as archive:
        for name, raw in members:
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
    assert temporary.stat().st_size <= MAX_ARCHIVE
    with tarfile.open(temporary, "r:xz") as archive:
        actual = archive.getmembers()
        assert [m.name for m in actual] == [name for name, _ in members]
        for member, (_, expected) in zip(actual, members):
            assert member.isfile() and member.mode == 0o644 and not member.issym() and not member.islnk()
            raw = archive.extractfile(member).read()
            raw.decode("utf-8")
            assert raw == expected
    temporary.replace(destination)
    return dict(path=destination.name, sha256=file_hash(destination), bytes=destination.stat().st_size,
        utf8_members=len(members), expanded_utf8_bytes=sum(len(raw) for _, raw in members),
        contains_native_or_wasm_binaries=False, excluded_path_count=len(excluded))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--finalize", action="store_true", required=True)
    parser.add_argument("--status", choices=["accepted", "rejected"], required=True)
    parser.add_argument("--audit", type=Path, default=BASE / "independent-audit.json")
    parser.add_argument("--reference-analysis", type=Path, default=BASE / "reference-analysis.json")
    parser.add_argument("--reference-audit", type=Path, default=BASE / "reference-audit.json")
    args = parser.parse_args()
    audit, study = load(args.audit), load(BASE / "study-plan.json")
    baseline, candidate = load(BASE / "baseline/identity.json"), load(BASE / "candidate/identity.json")
    fingerprint = candidate["source_fingerprint"]
    assert len(fingerprint) == 64 and all(c in "0123456789abcdef" for c in fingerprint)
    assert fingerprint != BASELINE_FP and candidate["source_commit"] == SOURCE_PARENT
    assert baseline["source_fingerprint"] == BASELINE_FP and baseline["source_commit"] == COMPILED_BASELINE
    assert audit["status"] == "audited" and audit["baseline_accepted_commit"] == ACCEPTED_BASELINE
    assert audit["products"]["candidate"]["identity"] == candidate
    assert audit["total_raw_invocations"] == 1296
    assert {k: v["raw_invocations"] for k, v in audit["cohorts"].items()} == COUNTS
    assert audit["measured_observations"] == 27216 and audit["warmup_observations"] == 12960
    manifest = load(BASE / "sources/manifest.json")
    assert len(manifest["execution"]) == 27 and set(study["targets"]) == {"objects.js", "retained-objects.js"}
    assert len({row["file"] for row in manifest["execution"]} - set(study["targets"])) == 25
    assert file_hash(BASE / "sources/manifest.json") == study["corpus"]["manifest_sha256"] == audit["corpus_sha256"]
    assert len(audit["P_footprints"]) == 27
    original_controls = [row for row in audit["P_footprints"] if row["original"] and row["case"] not in study["targets"]]
    assert len(original_controls) == 15 and all(row["P_bytes_equal"] and row["exact_code_section_equal"] for row in original_controls)
    runtime = load(BASE / "runtime-invariance.json")
    assert runtime["status"] == "verified" and runtime["candidate_source_fingerprint"] == fingerprint
    assert runtime["baseline_source_fingerprint"] == BASELINE_FP and len(runtime["profiles"]) == 2
    for row in runtime["profiles"].values():
        assert row["runtime_abi"] == 42 and row["runtime_wasm_identical"]
        assert row["baseline_wasm_sha256"] == row["candidate_wasm_sha256"]
        assert row["native_identical"] and row["baseline_native_sha256"] == row["candidate_native_sha256"]
    verification = native_coverage(audit, fingerprint)
    verification["full_Test262_or_release_acceptance"] = False
    verification["toolchain"] = load(BASE / "toolchain.json")
    verification["setup_metadata_correction"] = audit["setup_metadata_correction"]
    semantic_path = BASE / "product-semantics/receipt.json"
    if semantic_path.is_file():
        semantics = load(semantic_path)
        assert all(row["exit_code"] == 0 and row["source_fingerprint"] == fingerprint for row in semantics)
        verification["product_semantics"] = dict(receipt=semantics, scope="Unscored product-semantic controls; separate from all performance gates.")
    else:
        verification["product_semantics"] = dict(status="not separately run", scope="Actual12 compact-row engine tests are included in the named native union.")
    conformance_receipt = BASE / "test262-compact-rows/test262-compact-row-entry-receipt.json"
    inspection_path = BASE / "program-inspection/identity.json"
    if args.status == "accepted":
        assert all(audit["cohorts"][name]["gate_pass"] for name in ["ordinary", "cp_control"])
        verification["pinned_test262"] = conformance(load(conformance_receipt), fingerprint)
        assert verification["pinned_test262"]["status"] == "complete"
        reference = references(load(args.reference_analysis), load(args.reference_audit), fingerprint)
        inspection = load(inspection_path)
        assert inspection["schema"] == "scriptw-compact-row-entry-wasm-inspection-v1"
        assert inspection["source_fingerprint"] == fingerprint and len(inspection["products"]) == 6
        reference_boundary = "136 direct-reference processes are separate from the 1296 gated cohort processes."
    else:
        assert any(not audit["cohorts"][name]["gate_pass"] for name in ["ordinary", "cp_control"])
        assert not conformance_receipt.exists() and not args.reference_analysis.exists() and not args.reference_audit.exists()
        reason = "not run: predeclared performance gate vetoed candidate"
        verification["pinned_test262"] = dict(status=reason, scopes_run=0, planned_scopes=3,
            full_Test262_or_release_acceptance=False)
        reference = dict(status=reason, attempts=0, planned_attempts=136, planned_scriptc_compilations=17)
        inspection = dict(status=reason, planned_P_modules=6)
        if inspection_path.is_file():
            inspection = load(inspection_path)
            assert inspection["source_fingerprint"] == fingerprint
        reference_boundary = "The planned 136 reference processes, 17 Scriptc compilations and three selected Test262 scopes were not run after the performance veto."
    summary = dict(schema="scriptw-compact-row-entry-checkpoint-v1", date="2026-11-01", status=args.status,
        source_parent_commit=SOURCE_PARENT, candidate_source_fingerprint=fingerprint,
        baseline_accepted_commit=ACCEPTED_BASELINE, baseline_binary_source_commit=COMPILED_BASELINE,
        baseline_source_fingerprint=BASELINE_FP, products=load(BASE / "candidate/products.json"),
        candidate_changes=["Compact-only positive-trip preheader prepares/captures the complete first row and key slots once.",
            "The rotated loop emits one exact body/update, checks the same induction bound, then validates/captures the next row against the established shape.",
            "First-only name/cache/key roots and StringEquality are absent from the hot loop. Prefix publication/fallback is unchanged; zero trips skip all row/key work.",
            "Dense/join/whole-trip P topology and both ABI42 R/native profiles remain unchanged; no new runtime helpers/schema/heap."],
        runtime_abi=42, runtime_invariance=runtime,
        cohort_counts=COUNTS, cohorts=audit["cohorts"],
        corpus=dict(manifest_sha256=file_hash(BASE / "sources/manifest.json"), predeclared=study["corpus"],
            original_cases=17, added_controls=10, cases=27, targets=study["targets"], controls=25),
        audit=dict(total_raw_invocations=1296, measured_observations=27216, warmups=12960,
            maximum_statistical_discrepancy=audit["maximum_recomputed_statistic_discrepancy"],
            P_footprints=audit["P_footprints"]),
        reference=reference, verification=verification, wasm_inspection=inspection,
        limitations=["Full release/Test262 acceptance and every-case V8/Scriptc parity remain open.",
            "Reference medians and means retain both process rounds and are distinct from the paired gate blocks. No previous checkpoint reference results are reused.",
            "The reference lane includes material slower candidate processes: retained objects18.62/16.58ms median/mean versus14.53/14.56ms baseline; reverse512sort2.169/2.040ms versus0.525/0.531ms; mixedjoin2.760/2.723ms versus1.246/1.441ms. "
            "Matching unchanged code/configuration and RSS/timing correlations do not establish the cause. No processes or samples are excluded.",
            "A/A 432 + ordinary 432 + CP 432 = 1296 process inputs over 27 cases, each 21 measured samples and 10 warmups. Pooled observations are descriptive.",
            reference_boundary,
            "Both ABI42 R Wasm modules AND native images are required byte-identical; fingerprint-bound package metadata is recorded separately.",
            "Hot-R compiler-disabled SizeOptimized/backtracking differs from ordinary Fast execution; do not subtract lanes for attribution.",
            "Slower control blocks and A/A outliers are retained; no samples trimmed or gates relaxed.",
            "Cache/RSS endpoints do not identify GC, page faults or scheduler causes."] + audit["limitations"])
    if args.status == "rejected":
        summary["production_retained"] = dict(accepted_commit=ACCEPTED_BASELINE, source_fingerprint=BASELINE_FP, runtime_abi=42)
        summary["rejection"] = {name: audit["cohorts"][name] for name in ["ordinary", "cp_control"]
            if not audit["cohorts"][name]["gate_pass"]}
    for name in ["format-classification.json", "runtime-invariance-recheck.json", "product-semantics/cache-proof.json", "post-audit-docs.json", "producer-graph-equality.json", "reference-variation-review.json"]:
        path = BASE / name
        if path.is_file():
            summary.setdefault("additional_receipts", {})[name] = load(path)
    destination, summary_path = DOCS / (STEM + "-inert.tar.xz"), DOCS / (STEM + ".json")
    assert not summary_path.exists(), "preserve prior summary"
    summary["evidence"] = archive_text(destination)
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary["evidence"], indent=2))


if __name__ == "__main__":
    main()

