function makeRow(x) { return {x:x, y:1}; }
function sum(rows) { 'use strict'; var total=0; for (var i=0; i<rows.length; i++) total += rows[i].x + rows[i].y; return total; }
var rows=[]; for (var i=0; i<512; i++) rows.push(makeRow(i)); var reads=0;
rows[0]=new Proxy(makeRow(0), {get:function(target,key){ if(key==='x'||key==='y') reads++; return target[key]; }});
print(sum(rows) === 131328 && reads === 2);
