function makeRow(x) { return {x:x, y:1}; }
function sum(rows) { 'use strict'; var total=0; for (var i=0; i<rows.length; i++) total += rows[i].x + rows[i].y; return total; }
var rows=[]; for (var i=0; i<512; i++) rows.push(makeRow(i)); var reads=0;
Object.defineProperty(rows[0], 'x', {get:function(){ reads++; return 0; }});
print(sum(rows) === 131328 && reads === 1);
