"""Independently audit compact-row references and their ordinary Wasm outputs."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
from benchmark_metrics import digest


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return digest(Path(path))


def verify_resources(command):
    assert command["exit_code"] == 0 and not command["timed_out"]
    assert command["affinity"] == [0]
    for phase in ("resources_before", "resources_after"):
        resources = command[phase]
        assert resources["memory.max"].strip() == "4294967296"
        assert resources["memory.swap.max"].strip() == "0"
        assert resources["memory.oom.group"].strip() == "1"
        assert all(int(line.split()[1]) == 0 for line in resources["memory.events"].splitlines())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("ordinary", type=Path,
        help="analysis.json from this cohort's full 25-case ordinary run")
    args = parser.parse_args()
    ordinary_path = args.ordinary.resolve()
    ordinary_root = ordinary_path.parent
    analysis = load(OUT / "reference-analysis.json")
    retained_manifest = load(OUT / "retained-sources/manifest.json")
    full_manifest = load(OUT / "sources/manifest.json")
    expected = {row["file"]: row["stdout"] for row in retained_manifest["execution"]}
    full_expected = {row["file"]: row["stdout"] for row in full_manifest["execution"]}
    assert len(expected) == 17 and len(full_expected) == 25
    assert all(full_expected[name] == output for name, output in expected.items())

    ordinary = load(ordinary_path)
    ordinary_rows = ordinary["rows"]
    ordinary_hashes = {}
    ordinary_linked_runtime = {}
    for row in ordinary_rows:
        if row["case"] not in expected or row["product"] not in ("baseline", "candidate"):
            continue
        raw = load(ordinary_root / "raw" / (row["raw"] + ".stdout"))
        case = raw["cases"][0]
        assert case["file"] == row["case"]
        identity = load(OUT / (row["product"] + "/identity.json"))
        assert raw["source_fingerprint"] == identity["source_fingerprint"]
        products = load(OUT / (row["product"] + "/host-products.json"))
        assert raw["executable_sha256"] == products["runtime_baseline"]["sha256"]
        assert case["source_compilation_profile"] == "portable"
        key = (row["product"], row["case"])
        value = case["wasm_sha256"]
        assert key not in ordinary_hashes or ordinary_hashes[key] == value
        ordinary_hashes[key] = value
        ordinary_linked_runtime[key] = case["linked_runtime"]["wasm_sha256"]
    assert len(ordinary_hashes) == 34, "ordinary run must contain baseline and candidate for all 17 originals"

    invariance = load(OUT / "runtime-invariance.json")
    assert invariance["status"] == "verified"
    runtime_hashes = {}
    for profile in ("standard", "portable"):
        record = invariance["profiles"][profile]
        assert record["runtime_abi"] == 42 and record["runtime_wasm_identical"]
        assert record["native_identical"], f"R native image changed in {profile} profile"
        assert record["baseline_wasm_sha256"] == record["candidate_wasm_sha256"]
        runtime_hashes[profile] = record["baseline_wasm_sha256"]
    assert all(value == runtime_hashes["portable"] for value in ordinary_linked_runtime.values())

    baseline_identity = load(OUT / "baseline/identity.json")
    candidate_identity = load(OUT / "candidate/identity.json")
    hosts = {}
    for product, identity in (("baseline", baseline_identity), ("candidate", candidate_identity)):
        product_metadata = load(OUT / product / "host-products.json")
        executable = OUT / product / "runtime_baseline"
        runtime_host_sha256 = product_metadata["runtime_baseline"]["sha256"]
        assert sha(executable) == runtime_host_sha256
        hosts[product] = dict(source_fingerprint=identity["source_fingerprint"],
            executable_sha256=runtime_host_sha256)
    for product in ("baseline", "candidate"):
        assert ordinary["frozen_product_hash_check"]["hashes"][product + "/runtime_baseline"] == sha(OUT / product / "runtime_baseline")
        for name in expected:
            assert (product, name) in ordinary_hashes
    
    scriptc_hashes = {}
    source_hashes = {}
    adapter = b"function print(value) { console.log(String(value)); }\n"
    scriptc = OUT / "tools/scriptc/node_modules/.bin/scriptc"
    wasi_host = OUT / "candidate/wasi_baseline"
    tools = analysis["tools"]
    assert sha(wasi_host) == tools["wasi_host_sha256"]
    assert sha(OUT / "tools/scriptc/package-lock.json") == tools["scriptc_package_lock_sha256"]
    for package in ("scriptc", "@scriptc/runtime-wasm32-wasi", "@scriptc/cli-linux-x64-gnu"):
        assert load(OUT / "tools/scriptc/node_modules" / package / "package.json")["version"] == "0.4.5"
    assert subprocess.check_output(["node", "--version"], text=True).strip() == tools["node"]
    assert subprocess.check_output(["node", "-p", "process.versions.v8"], text=True).strip() == tools["v8"]
    assert subprocess.check_output([str(OUT / "tools/zig-x86_64-linux-0.16.0/zig"), "version"],
        text=True).strip() == tools["zig"]

    scriptc_compilations = analysis["compilation"]
    assert set(scriptc_compilations) == set(expected)
    for name, compilation in scriptc_compilations.items():
        compile_record = compilation["compile"]
        verify_resources(compile_record)
        command_path = OUT / "raw" / ("reference-compile-" + name + ".command.json")
        assert compile_record == load(command_path)
        original = (OUT / "retained-sources" / name).read_bytes()
        canonical = ROOT / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths" / name
        assert original == canonical.read_bytes()
        assert (OUT / "adapted-scriptc" / name).read_bytes() == adapter + original
        source_hashes[name] = hashlib.sha256(original).hexdigest()
        assert (OUT / "expected" / name).read_text() == expected[name]
        wasm = OUT / "scriptc-wasm" / (name + ".wasm")
        scriptc_hashes[name] = sha(wasm)
        assert scriptc_hashes[name] == compilation["wasm_sha256"]
        assert compile_record["argv"][-1] == str(wasm.resolve())

    groups = collections.defaultdict(list)
    seen = set()
    ordinary_module_checks = 0
    for attempt in analysis["attempts"]:
        assert attempt["status"] == "ok"
        key = (attempt["file"], attempt["runtime"], attempt["round"])
        assert key not in seen
        seen.add(key)
        name, runtime = attempt["file"], attempt["runtime"]
        raw_path = OUT / "raw" / attempt["raw"]
        report = load(raw_path)
        command = load(raw_path.with_name(raw_path.name.removesuffix(".stdout") + ".command.json"))
        verify_resources(command)
        assert report["samples"] == 21 and report["warmups"] == 10
        if runtime == "scriptc":
            assert report["schema"] == "scriptw-wasi-baseline-v1"
            assert report["wasmtime_version"] == "47.0.0"
            assert report["wasm_sha256"] == scriptc_hashes[name]
            observations = report["observations"]
            assert all(row["matched"] and row["completion"] == "normal" and row["stderr"] == "" for row in observations)
        else:
            assert len(report["cases"]) == 1
            case = report["cases"][0]
            assert case["file"] == name and case["source_sha256"] == source_hashes[name]
            observations = case["observations"]
            if runtime == "v8":
                assert report["schema"] == "scriptw-v8-baseline-v2"
                assert report["node"] == tools["node"] and report["v8"] == tools["v8"]
            else:
                assert report["schema"] == "scriptw-wasmtime-baseline-v2"
                assert report["source_fingerprint"] == hosts[runtime]["source_fingerprint"]
                assert report["executable_sha256"] == hosts[runtime]["executable_sha256"]
                assert report["requested_native_policy"] is None
                assert case["source_compilation_profile"] == "portable"
                assert case["linked_runtime"]["wasm_sha256"] == runtime_hashes["portable"]
                assert case["wasm_sha256"] == ordinary_hashes[(runtime, name)]
                ordinary_module_checks += 1
        assert len(observations) == 31
        assert [row["warmup"] for row in observations] == [True] * 10 + [False] * 21
        assert all(row["stdout"] == expected[name] for row in observations)
        values = [row["execution_ns"] for row in observations if not row["warmup"]]
        assert values == attempt["times_ns"]
        rss = [row["rss_after_bytes"] if runtime == "scriptc" else
            row["memory"]["after"]["rss"] if runtime == "v8" else
            row["memory"]["process_rss"]["final_rss_bytes"]
            for row in observations if not row["warmup"]]
        assert rss == attempt["rss_bytes"]
        groups[(name, runtime)].append(dict(round=attempt["round"],
            median=statistics.median(values), mean=statistics.mean(values), values=values))

    assert len(seen) == 136 and all(len(rows) == 2 for rows in groups.values())
    assert len(groups) == 68 and ordinary_module_checks == 68
    primary = {}
    median_wins = {"v8": [], "scriptc": []}
    mean_wins = {"v8": [], "scriptc": []}
    for row in analysis["summary"]:
        name = row["file"]
        primary[name] = {}
        for runtime in ("baseline", "candidate", "v8", "scriptc"):
            invocations = groups[(name, runtime)]
            flat = [value for invocation in invocations for value in invocation["values"]]
            summary = row["runtimes"][runtime]
            assert statistics.median(flat) == summary["median_ns"]
            assert abs(statistics.mean(flat) - summary["mean_ns"]) < 1e-7
            primary[name][runtime] = dict(
                median_of_process_medians=statistics.median(item["median"] for item in invocations),
                mean_of_process_means=statistics.mean(item["mean"] for item in invocations))
        for runtime in median_wins:
            if primary[name]["candidate"]["median_of_process_medians"] < primary[name][runtime]["median_of_process_medians"]:
                median_wins[runtime].append(name)
            if primary[name]["candidate"]["mean_of_process_means"] < primary[name][runtime]["mean_of_process_means"]:
                mean_wins[runtime].append(name)

    output = dict(status="audited", attempts=len(seen), measured_observations=len(seen) * 21,
        warmup_observations=len(seen) * 10, scriptc_compilations=len(scriptc_compilations),
        original_sources=17, ordinary_original_product_artifacts_checked=ordinary_module_checks,
        tools=tools, hosts=hosts, runtime_wasm_hashes=runtime_hashes,
        process_primary=primary, median_wins=median_wins, mean_wins=mean_wins,
        ordinary_analysis=str(ordinary_path))
    (OUT / "reference-audit.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
